using System;
using System.Collections.Generic;

namespace ADGlobalService.Models
{
    public sealed class DirectorySyncPage
    {
        public Guid SyncRunId { get; set; }
        public DateTime SyncStartedAtUtc { get; set; }
        public DateTime ExpiresAtUtc { get; set; }
        public List<DirectorySyncUser> Items { get; set; }
        public string NextPageToken { get; set; }
        public bool HasMore => NextPageToken != null;
    }

    public sealed class DirectorySyncUser
    {
        public Guid AdObjectGuid { get; set; }
        public string DistinguishedName { get; set; }
        public bool IsEnabled { get; set; }
        public DateTime? AdLastModifiedAtUtc { get; set; }
        public ActiveDirectoryMember Profile { get; set; }
    }
}
