using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace ADGlobalService.Models
{
    public sealed class DirectoryIncrementalSyncPage
    {
        [JsonProperty("syncRunId")]
        public Guid SyncRunId { get; set; }
        [JsonProperty("syncStartedAtUtc")]
        public DateTime SyncStartedAtUtc { get; set; }
        [JsonProperty("expiresAtUtc")]
        public DateTime ExpiresAtUtc { get; set; }
        [JsonProperty("items")]
        public List<DirectoryIncrementalSyncUser> Items { get; set; }
        [JsonProperty("nextPageToken")]
        public string NextPageToken { get; set; }
        [JsonProperty("hasMore")]
        public bool HasMore { get { return NextPageToken != null; } }
        [JsonProperty("completedSyncToken")]
        public string CompletedSyncToken { get; set; }
    }

    public sealed class DirectoryIncrementalSyncUser
    {
        [JsonProperty("directoryObjectId")]
        public Guid DirectoryObjectId { get; set; }
        [JsonProperty("userName")]
        public string UserName { get; set; }
        [JsonProperty("userPrincipalName")]
        public string UserPrincipalName { get; set; }
        [JsonProperty("email")]
        public string Email { get; set; }
        [JsonProperty("displayName")]
        public string DisplayName { get; set; }
        [JsonProperty("adFullName")]
        public string AdFullName { get; set; }
        [JsonProperty("department")]
        public string Department { get; set; }
        [JsonProperty("jobTitle")]
        public string JobTitle { get; set; }
        [JsonProperty("mobile")]
        public string Mobile { get; set; }
        [JsonProperty("staffId")]
        public string StaffId { get; set; }
        [JsonProperty("sapId")]
        public string SapId { get; set; }
        [JsonProperty("employmentType")]
        public string EmploymentType { get; set; }
        [JsonProperty("isInternalUser")]
        public bool IsInternalUser { get; set; }
        [JsonProperty("isEnabled")]
        public bool IsEnabled { get; set; }
        [JsonProperty("modifiedAt")]
        public DateTime? ModifiedAt { get; set; }
    }
}
