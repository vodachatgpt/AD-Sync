﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADGlobalService.Models
{
    public class AdUsnInfoDto
    {
        public string DomainControllerName { get; set; }

        public string DefaultNamingContext { get; set; }

        public long HighestCommittedUsn { get; set; }

        public Guid InvocationId { get; set; }

        public DateTime RetrievedAtUtc { get; set; }
    }
}