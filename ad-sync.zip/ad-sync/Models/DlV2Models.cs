﻿using System;
using System.Collections.Generic;

namespace ADGlobalService.Models
{
    public class DlGroupDto
    {
        public string GroupName { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
    }

    public class DlMemberDto
    {
        public string NTAccount { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
    }

    public class DlOwnerDto
    {
        public string NTAccount { get; set; }
        public string DisplayName { get; set; }
        public string Email { get; set; }
    }

    public class DlMemberRequest
    {
        public string GroupIdentifier { get; set; }

        // Supports NT Account, Email, UPN or StaffId.
        public string UserIdentifier { get; set; }

        public string CurrentUserEmail { get; set; }
    }

    public enum DlOperationStatus
    {
        Success = 1,
        InvalidRequest = 2,
        GroupNotFound = 3,
        UserNotFound = 4,
        Unauthorized = 5,
        Failed = 6
    }

    public class DlOperationResult
    {
        public bool Success { get; set; }
        public DlOperationStatus Status { get; set; }
        public string Message { get; set; }
    }

    public class DlAuditLogDto
    {
        public string Action { get; set; }
        public string GroupName { get; set; }
        public string UserAffectedByAction { get; set; }
        public string ActionTaker { get; set; }
        public DateTime? CreationDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
    }

    public class DlAuditLogPagedResult
    {
        public List<DlAuditLogDto> Data { get; set; }
        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
    }
}