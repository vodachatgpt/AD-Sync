﻿using System;
using System.Collections.Generic;

namespace ADGlobalService.Models
{
    public class ActiveDirectoryMemberV2 : ActiveDirectoryMember
    {
        public List<string> DLEmails { get; set; }
    }
    public class ActiveDirectoryMember
    {
        public string Email { get; set; }
        public string UserPrincipalName { get; set; }
        public string NTAccount { get; set; }
        public string DisplayName { get; set; }
        public string FullName { get; set; }
        public string Mobile { get; set; }
        public string Company { get; set; }
        public string Office { get; set; }
        public string Gender { get; set; }
        public string CostCenter { get; set; }
        public string SapId { get; set; }
        public string HiringDate { get; set; }
        public string Department { get; set; }
        public string SubDepartment { get; set; }
        public string ManagerNT { get; set; }
        public string HodNT { get; set; }
        public List<string> DLs { get; set; }
        public bool? IsManager { get; set; }
        public string Manager { get; set; }
        public string JobTitle { get; set; }
        public string ReportTo { get; set; }
        public string StaffId { get; set; }
        public string EmploymentType { get; set; }
        public bool IsInternalUser { get; set; }
        public bool HasPhoto { get; set; }
        public string PhotoBase64 { get; set; }
        public List<string> SubordinateEmails { get; set; }

    }
    public enum FilterType { Email, NtAccount, CommonName }
    public enum IdentifierType
    {
        NtAccount,
        Email,
        GroupName
    }
    public class ActiveDirectoryGroup
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Description { get; set; }
        public string DistinguishedName { get; set; }

        /// <summary>"Security" or "Distribution"</summary>
        public string GroupType { get; set; }

        /// <summary>
        /// Direct member count only (not recursive).
        /// AD caps the member attribute at 1500 entries without range retrieval,
        /// so treat this as an estimate for large groups.
        /// </summary>
        public int MemberCount { get; set; }
    }
    public class ServiceBody
    {
        public string DlName { get; set; }
        public string NTAccount { get; set; }
        public string Email { get; set; }
        public string Path { get; set; }
    }
    public class AccountStatusInfo
    {
        public string Email { get; set; }
        public bool IsEnabled { get; set; }
        public bool IsLocked { get; set; }
        public bool IsPasswordExpired { get; set; }
        public DateTime? PasswordLastSet { get; set; }
        public DateTime? LockoutTime { get; set; }
    }
    public enum EmploymentType
    {
        Internal,
        Outsource,
        Vendor,
        Unknown
    }

    public class GroupMembershipRequest
    {
        public string UserIdentifier { get; set; } = string.Empty;
        public string GroupIdentifier { get; set; } = string.Empty;
    }
    public class HodFilter
    {
        public string Department { get; set; }
        public string SubDepartment { get; set; }
        public string Company { get; set; }
        public string Office { get; set; }
        public string CostCenter { get; set; }
        public string JobTitle { get; set; }

        public string NTAccount { get; set; }
        public string Email { get; set; }

        /// <summary>
        /// General search against DisplayName, NTAccount, Mail and UPN.
        /// Partial search.
        /// </summary>
        public string Search { get; set; }

        /// <summary>
        /// null = don't filter.
        /// true = internal only.
        /// false = outsource only.
        /// </summary>
        public bool? IsInternalUser { get; set; }

        /// <summary>
        /// Disabled AD accounts are excluded by default.
        /// </summary>
        public bool IncludeDisabledUsers { get; set; } = false;
    }
}