﻿using ADGlobalService.Services.SyncAdDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class GroupsPagedResponseDto
    {
        public object Items { get; set; }

        public int TotalCount { get; set; }

        public int Page { get; set; }

        public int PageSize { get; set; }

        public List<NestedGroupDto> NestedGroups { get; set; }
        public int TotalNestedGroups { get; set; }
    }

}