﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class MembershipSyncSummaryDto
    {
        public int GroupsChecked { get; set; }
        public int Inserted { get; set; }
        public int Removed { get; set; }
    }

    public class MembershipDeltaDto
    {
        public int Inserted { get; set; }
        public int Removed { get; set; }
    }
}