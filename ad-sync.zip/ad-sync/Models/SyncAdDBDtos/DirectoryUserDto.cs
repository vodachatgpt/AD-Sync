﻿using System;
using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DirectoryUserDto
    {
        public long UserId { get; set; }
        public Guid ActiveDirectoryObjectGuid { get; set; }

        public string FullName { get; set; }
        public string DisplyName { get; set; }
        public string NT { get; set; }
        public string Email { get; set; }
        public string MobileNumber { get; set; }

        public string StaffId { get; set; }
        public string SapId { get; set; }

        public string Department { get; set; }
        public string JobTitle { get; set; }
        public string Company { get; set; }

        public string CostCenter { get; set; }
        public string Office { get; set; }
        public string Gender { get; set; }
        public long? ManagerUserId { get; set; }
        public bool? IsEnabled { get; set; }
        public string HiringDate { get; set; }
        public string ReportTo { get; set; }

        public string MangerNT { get; set; }
        public string HoDNT { get; set; }

        public string IsInternal { get; set; }
        public string SubDepartment { get; set; }
        public DirectoryUserDto Parent { get; set; }
        public List<DirectoryUserDto> Children { get; set; }

    }
}