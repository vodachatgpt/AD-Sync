﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos
{

    public class AdChangedUsersResponseDto
    {
        public string DomainControllerName { get; set; }

        public Guid InvocationId { get; set; }

        public long FromUsn { get; set; }

        public long ToUsn { get; set; }

        public int ChangedUsersCount { get; set; }

        public List<Dictionary<string, object>> Users { get; set; }
            = new List<Dictionary<string, object>>();
    }

}