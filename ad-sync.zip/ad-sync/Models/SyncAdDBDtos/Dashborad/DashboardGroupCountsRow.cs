﻿using System.Linq;
using System.Web;

namespace ADGlobalService.Models.SyncAdDBDtos.Dashborad
{
    public sealed class DashboardGroupCountsRow
    {
        public int GroupsCount { get; set; }
        public int UserGroupMembershipsCount { get; set; }
        public int NestedGroupMembershipsCount { get; set; }
    }

}