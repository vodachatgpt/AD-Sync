﻿namespace ADGlobalService.Models.SyncAdDBDtos.Dashborad
{
    public sealed class DashboardManagerDto
    {
        public long UserId { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public int DirectReports { get; set; }
    }

}