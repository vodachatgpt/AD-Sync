﻿using System;

namespace ADGlobalService.Models.SyncAdDBDtos.Dashborad
{
    public sealed class DashboardSyncStateDto
    {
        public string SyncName { get; set; }
        public string TrackingMethod { get; set; }
        public long? UsnWatermark { get; set; }
        public DateTime? LastSuccessfulSyncUtc { get; set; }
        public string DomainControllerName { get; set; }
    }

}