﻿namespace ADGlobalService.Models.SyncAdDBDtos.Dashborad
{
    public sealed class DashboardBreakdownDto
    {
        public string Name { get; set; }
        public int Count { get; set; }
    }
}