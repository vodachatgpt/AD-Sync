﻿namespace ADGlobalService.Models.SyncAdDBDtos.Dashborad
{
    public sealed class DashboardSubDepartmentDto
    {
        public string Department { get; set; }
        public string Name { get; set; }
        public int Count { get; set; }
    }

}