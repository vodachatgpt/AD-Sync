﻿namespace ADGlobalService.Models.SyncAdDBDtos.Dashborad
{
    public sealed class DashboardDepartmentStaffingDto
    {
        public string Department { get; set; }
        public int InternalCount { get; set; }
        public int OutsourceCount { get; set; }
        public int UnknownCount { get; set; }
    }

}