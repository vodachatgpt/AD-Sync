﻿using System;
using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos.Dashborad
{
    public sealed class DashboardSummaryDto
    {
        // All users = including soft-deleted; other employee distributions exclude soft-deleted.
        public int TotalUsers { get; set; }
        public int CurrentUsers { get; set; }
        public int ActiveUsers { get; set; }
        public int DisabledUsers { get; set; }
        public int UnknownStatusUsers { get; set; }
        public int DeletedUsers { get; set; }

        // IsInternal is stored as an AD string; unrecognized or missing is Unknown.
        public int InternalUsersCount { get; set; }
        public int OutsourceUsersCount { get; set; }
        public int UnknownInternalStatusCount { get; set; }

        public int DepartmentsCount { get; set; }
        public int SubDepartmentsCount { get; set; }
        public int ManagersCount { get; set; }
        public int LinkedUsers { get; set; }
        public int MissingManagerCount { get; set; }
        public int UnresolvedManagerCount { get; set; }

        public int WithEmailCount { get; set; }
        public int MissingEmailCount { get; set; }
        public int MissingNtCount { get; set; }
        public int MissingDisplayNameCount { get; set; }
        public int MissingDepartmentCount { get; set; }
        public int MissingSubDepartmentCount { get; set; }
        public int MissingStaffIdCount { get; set; }
        public int MissingOfficeCount { get; set; }
        public int MissingJobTitleCount { get; set; }
        public int MissingGenderCount { get; set; }
        public int MissingManagerDnCount { get; set; }
        public int CreatedInAdLast30Days { get; set; }
        public int ModifiedInAdLast30Days { get; set; }

        public int AccountMetadataRecords { get; set; }
        public int MustChangePasswordCount { get; set; }
        public int NeverExpiresCount { get; set; }
        public int AccountsWithLockoutTimeCount { get; set; }
        public int AttributeValueRows { get; set; }
        public int AttributeTypesCount { get; set; }

        // These can be zero when group synchronization is not implemented.
        public int GroupsCount { get; set; }
        public int UserGroupMembershipsCount { get; set; }
        public int NestedGroupMembershipsCount { get; set; }

        public DateTime? LastSyncUtc { get; set; }
        public long? UsnWatermark { get; set; }
        public string DomainControllerName { get; set; }

        public List<DashboardDepartmentStaffingDto> StaffingByDepartment { get; set; } = new List<DashboardDepartmentStaffingDto>();
        public List<DashboardBreakdownDto> UsersByDepartment { get; set; } = new List<DashboardBreakdownDto>();
        public List<DashboardSubDepartmentDto> UsersBySubDepartment { get; set; } = new List<DashboardSubDepartmentDto>();
        public List<DashboardBreakdownDto> UsersByJobTitle { get; set; } = new List<DashboardBreakdownDto>();
        public List<DashboardBreakdownDto> UsersByOffice { get; set; } = new List<DashboardBreakdownDto>();
        public List<DashboardBreakdownDto> UsersByCompany { get; set; } = new List<DashboardBreakdownDto>();
        public List<DashboardBreakdownDto> UsersByCountry { get; set; } = new List<DashboardBreakdownDto>();
        public List<DashboardBreakdownDto> UsersByGender { get; set; } = new List<DashboardBreakdownDto>();
        public List<DashboardBreakdownDto> UsersByInternalStatus { get; set; } = new List<DashboardBreakdownDto>();
        public List<DashboardBreakdownDto> AttributeTypes { get; set; } = new List<DashboardBreakdownDto>();
        public List<DashboardManagerDto> TopManagers { get; set; } = new List<DashboardManagerDto>();
        //public List<DashboardSyncStateDto> SyncStates { get; set; } = new List<DashboardSyncStateDto>();
    }

}