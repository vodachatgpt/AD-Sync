﻿using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DirectoryUserHierarchyNode
    {
        // Identity
        //public Guid ActiveDirectoryObjectGuid { get; set; }
        public long UserId { get; set; }
        public string NT { get; set; }
        public string UserPrincipalName { get; set; }

        // Personal
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        // Contact
        public string Email { get; set; }
        public string MobileNumber { get; set; }

        // Organization
        public string Department { get; set; }
        public string JobTitle { get; set; }
        //public string AlternateJobTitle { get; set; }
        public string Company { get; set; }
        public string StaffId { get; set; }
        public string Office { get; set; }
        public string CostCenter { get; set; }
        public string Description { get; set; }

        // Additional Information
        public string CountryName { get; set; }
        public string HiringDate { get; set; }
        public string ReportTo { get; set; }
        public bool? IsInternalUser { get; set; }

        // Hierarchy
        public long? ManagerUserId { get; set; }
        public string ManagerFullName { get; set; }
        public string ManagerDistinguishedName { get; set; }


        [Newtonsoft.Json.JsonIgnore]
        public string GweInternalUserRaw { get; set; }
        // Dates
        //public DateTime? CreatedInAdAtUtc { get; set; }
        //public DateTime? ModifiedInAdAtUtc { get; set; }

        // Tree
        public List<DirectoryUserHierarchyNode> Children { get; set; }
            = new List<DirectoryUserHierarchyNode>();
    }
}