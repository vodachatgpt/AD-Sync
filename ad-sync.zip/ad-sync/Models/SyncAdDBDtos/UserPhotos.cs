﻿using System;
using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public sealed class PhotoSyncErrorDto
    {
        public long UserId { get; set; }
        public string Resolution { get; set; }
        public string Message { get; set; }
    }

    public sealed class PhotoSyncSummaryDto
    {
        public int TotalEligibleUsers { get; set; }
        public int ProcessedUsers { get; set; }
        public int InsertedPhotos { get; set; }
        public int UpdatedPhotos { get; set; }
        public int UnchangedPhotos { get; set; }
        public int MissingPhotos { get; set; }
        public int FailedPhotos { get; set; }
        public List<PhotoSyncErrorDto> Errors { get; set; } = new List<PhotoSyncErrorDto>();
    }

    public sealed class StoredUserPhotoDto
    {
        public byte[] Photo { get; set; }
        public string ContentType { get; set; }
        public string Resolution { get; set; }
        public DateTime LastSyncedAt { get; set; }
    }
    public sealed class PhotoSyncBatchProgressDto
    {
        public long LastUserId { get; set; }
        public int FetchedUsers { get; set; }
        public PhotoSyncSummaryDto Summary { get; set; }
    }

    public sealed class PhotoSyncRunDto
    {
        public Guid RunId { get; set; }
        public string Status { get; set; }
        public int PageSize { get; set; }
        public long LastProcessedUserId { get; set; }
        public int TotalEligibleUsers { get; set; }
        public int ProcessedUsers { get; set; }
        public int InsertedPhotos { get; set; }
        public int UpdatedPhotos { get; set; }
        public int UnchangedPhotos { get; set; }
        public int MissingPhotos { get; set; }
        public int FailedPhotos { get; set; }
        public DateTime StartedAtUtc { get; set; }
        public DateTime UpdatedAtUtc { get; set; }
        public DateTime? FinishedAtUtc { get; set; }
        public string ErrorMessage { get; set; }
    }


}