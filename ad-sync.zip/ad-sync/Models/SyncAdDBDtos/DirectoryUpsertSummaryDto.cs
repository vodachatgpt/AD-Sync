﻿namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DirectoryUpsertSummaryDto
    {
        public int ReceivedCount { get; set; }
        public int InsertedCount { get; set; }
        public int UpdatedCount { get; set; }
        public int UnchangedCount { get; set; }
        public int ManagersLinkedCount { get; set; }
    }


}