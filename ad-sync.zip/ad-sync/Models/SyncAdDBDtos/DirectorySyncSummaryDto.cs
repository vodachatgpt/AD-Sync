﻿namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DirectorySyncSummaryDto
    {
        public bool IsInitialSync { get; set; }

        public int ProcessedUsers { get; set; }

        public long FromUsn { get; set; }
        public long ToUsn { get; set; }

        public string DomainControllerName { get; set; }
    }


}