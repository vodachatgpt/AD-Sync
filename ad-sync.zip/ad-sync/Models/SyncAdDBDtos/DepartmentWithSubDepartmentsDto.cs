﻿using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DepartmentWithSubDepartmentsDto
    {
        public string Department { get; set; }

        public int TotalEmployees { get; set; }

        public List<SubDepartmentDto> SubDepartments { get; set; }
    }
}