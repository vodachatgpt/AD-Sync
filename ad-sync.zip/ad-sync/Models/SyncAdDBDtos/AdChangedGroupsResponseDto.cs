﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class AdChangedGroupsResponseDto
    {
        public List<Dictionary<string, object>> Groups { get; set; }
        public long FromUsn { get; set; }
        public long ToUsn { get; set; }
        public string DomainControllerName { get; set; }
        public Guid InvocationId { get; set; }
    }
}