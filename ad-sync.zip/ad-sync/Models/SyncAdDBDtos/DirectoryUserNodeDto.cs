﻿using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DirectoryUserNodeDto
    {
        public DirectoryUserDto User { get; set; }

        public List<DirectoryUserNodeDto> Children { get; set; }
            = new List<DirectoryUserNodeDto>();
    }
}