﻿namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DirectoryUserItemDto
    {
        public long UserId { get; set; }

        public string FullName { get; set; }
        public string Email { get; set; }

        public string JobTitle { get; set; }
        public string Department { get; set; }
        public string Company { get; set; }

        public long? ManagerUserId { get; set; }
        public string ManagerFullName { get; set; }

        public int DirectReportsCount { get; set; }

        // 0 = selected employee, 1 = manager, etc.
        // Used by the ancestors endpoint.
        public int HierarchyLevel { get; set; }


        public string NT { get; set; }
        public string DisplyName { get; set; }
        public string MobileNumber { get; set; }

        public string StaffId { get; set; }
        public string SapId { get; set; }

        public string CostCenter { get; set; }
        public string Office { get; set; }
        public string Gender { get; set; }
        public bool? IsEnabled { get; set; }
        public string HiringDate { get; set; }
        public string ReportTo { get; set; }

        public string MangerNT { get; set; }
        public string HoDNT { get; set; }

        public string IsInternal { get; set; }
        public string SubDepartment { get; set; }
    }


}