﻿using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ActiveDirectory.DTOs
{
    public class DirectoryDepartmentDto
    {
        public string Name { get; set; }
        public int EmployeesCount { get; set; }
    }

}