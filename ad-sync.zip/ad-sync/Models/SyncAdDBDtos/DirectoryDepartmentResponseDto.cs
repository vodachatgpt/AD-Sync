﻿using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DirectoryDepartmentResponseDto
    {
        public string Department { get; set; }
        public bool Hierarchical { get; set; }
        public string Direction { get; set; }
        public int TotalCount { get; set; }

        public List<DirectoryUserDto> Users { get; set; }
        public List<DirectoryUserNodeDto> Hierarchy { get; set; }
    }
}