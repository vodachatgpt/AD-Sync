﻿using System;
using System.Collections.Generic;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class DirectoryUserDetailsDto : DirectoryUserItemDto
    {
        public Guid ActiveDirectoryObjectGuid { get; set; }

        public string UserPrincipalName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string MobileNumber { get; set; }

        public string EmployeeCode { get; set; }
        public string OfficeName { get; set; }
        public string CostCenterCode { get; set; }

        public string Description { get; set; }
        public string CountryName { get; set; }
        public string HiringDate { get; set; }

        public string ManagerDistinguishedName { get; set; }
        public string ReportTo { get; set; }
        public string GweInternalUserRaw { get; set; }

        public bool? IsEnabled { get; set; }

        public DateTime? CreatedInAdAtUtc { get; set; }
        public DateTime? ModifiedInAdAtUtc { get; set; }

        public List<DistributionListDto> DistributionLists { get; set; }
                = new List<DistributionListDto>();
    }

    public class DistributionListDto
    {
        public string Name { get; set; }
        public string Email { get; set; }
    }


}