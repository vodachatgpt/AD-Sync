﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class AdExistingGuidsDto
    {
        public HashSet<Guid> UserGuids { get; set; }
            = new HashSet<Guid>();

        public HashSet<Guid> GroupGuids { get; set; }
            = new HashSet<Guid>();
    }

    public class SoftDeleteSyncDto
    {
        public bool DryRun { get; set; }

        public int UsersChecked { get; set; }
        public int GroupsChecked { get; set; }

        public List<Guid> MissingUserGuids { get; set; }
        public List<Guid> MissingGroupGuids { get; set; }

        public int SoftDeletedUsers { get; set; }
        public int SoftDeletedGroups { get; set; }
    }
}