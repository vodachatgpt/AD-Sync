﻿namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class GroupsUpsertSummaryDto
    {
        public int TotalReceived { get; set; }
        public int Inserted { get; set; }
        public int Updated { get; set; }
    }
}