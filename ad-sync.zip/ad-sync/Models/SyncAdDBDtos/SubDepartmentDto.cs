﻿namespace ADGlobalService.Models.SyncAdDBDtos
{
    public class SubDepartmentDto
    {
        public string Name { get; set; }

        public int EmployeeCount { get; set; }
    }
}