﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ADGlobalService.Models
{
    public enum UserField
    {
        NTAccount,
        Email,
        UserPrincipalName,
        DisplayName,
        JobTitle,
        IsInternalUser,
        EmploymentType,

        Department,
        Manager,
        ManagerNT,
        SubDepartment,
        ReportTo,

        StaffId,
        SapId,
        FullName,
        Mobile,

        Company,
        Office,
        CostCenter,
        HiringDate,
        Gender
    }

    public enum UserInclude
    {
        Band,
        Dls,
        DlEmails,
        Subordinates,
        ProfileImage
    }

    public class UserQueryOptions
    {
        public HashSet<UserField> Fields { get; private set; }

        public HashSet<UserInclude> Includes { get; private set; }

        public string ImageResolution { get; set; }

        public UserQueryOptions()
        {
            Fields = new HashSet<UserField>();
            Includes = new HashSet<UserInclude>();
        }

        /// <summary>
        /// Default behavior when caller does not specify fields/include.
        /// Returns all AD fields and preserves current-like behavior
        /// for DLs and subordinate information.
        /// </summary>
        public static UserQueryOptions CreateDefault()
        {
            var options = new UserQueryOptions();

            foreach (UserField field in Enum.GetValues(typeof(UserField)))
            {
                options.Fields.Add(field);
            }

            options.Includes.Add(UserInclude.Dls);
            options.Includes.Add(UserInclude.Subordinates);

            return options;
        }

        public UserQueryOptions Clone()
        {
            var result = new UserQueryOptions
            {
                ImageResolution = ImageResolution
            };

            foreach (var field in Fields)
            {
                result.Fields.Add(field);
            }

            foreach (var include in Includes)
            {
                result.Includes.Add(include);
            }

            return result;
        }

        public static bool TryCreate(
            string fields,
            string include,
            string imageResolution,
            out UserQueryOptions options,
            out string error)
        {
            error = null;

            bool noFields = string.IsNullOrWhiteSpace(fields);
            bool noIncludes = string.IsNullOrWhiteSpace(include);

            // Nothing specified => preserve current-like full behavior.
            if (noFields && noIncludes)
            {
                options = CreateDefault();
                options.ImageResolution = imageResolution;
                return true;
            }

            options = new UserQueryOptions
            {
                ImageResolution = imageResolution
            };

            // If fields are not specified, return all scalar AD fields.
            if (noFields)
            {
                foreach (UserField field in Enum.GetValues(typeof(UserField)))
                {
                    options.Fields.Add(field);
                }
            }
            else
            {
                var fieldTokens = fields
                    .Split(',')
                    .Select(x => x.Trim())
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .ToList();

                if (fieldTokens.Any(x =>
                    string.Equals(x, "all", StringComparison.OrdinalIgnoreCase)))
                {
                    foreach (UserField field in Enum.GetValues(typeof(UserField)))
                    {
                        options.Fields.Add(field);
                    }
                }
                else
                {
                    foreach (var token in fieldTokens)
                    {
                        UserField field;

                        if (!Enum.TryParse(token, true, out field) ||
                            !Enum.IsDefined(typeof(UserField), field))
                        {
                            error = "Invalid field: " + token;
                            return false;
                        }

                        options.Fields.Add(field);
                    }
                }
            }

            if (!noIncludes)
            {
                var includeTokens = include
                    .Split(',')
                    .Select(x => x.Trim())
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .ToList();

                foreach (var token in includeTokens)
                {
                    // Allows:
                    // include=none
                    if (string.Equals(
                        token,
                        "none",
                        StringComparison.OrdinalIgnoreCase))
                    {
                        continue;
                    }

                    UserInclude includeValue;

                    if (!Enum.TryParse(token, true, out includeValue) ||
                        !Enum.IsDefined(typeof(UserInclude), includeValue))
                    {
                        error = "Invalid include: " + token;
                        return false;
                    }

                    options.Includes.Add(includeValue);
                }
            }

            return true;
        }
    }

    public class EmployeeBandInfo
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public long ID { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string EmployeeNumber { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string SapNumber { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string EmailAddress { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string FullName { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Grade { get; set; }
    }

    public class UserV2Dto
    {
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string NTAccount { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string UserPrincipalName { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string DisplayName { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string JobTitle { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsInternalUser { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string EmploymentType { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Department { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Manager { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ManagerNT { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string SubDepartment { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string ReportTo { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string StaffId { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string SapId { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string FullName { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Mobile { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Company { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Office { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string CostCenter { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string HiringDate { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Gender { get; set; }

        // ---------- Optional enrichments ----------

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public EmployeeBandInfo Band { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<string> DLs { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<string> DLEmails { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public List<string> SubordinateEmails { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool? IsManager { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string PhotoBase64 { get; set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public bool? HasPhoto { get; set; }
    }
    public enum UserIdentifierType
    {
        Auto = 0,
        Email = 1,
        NTAccount = 2,
        StaffId = 3,
        SapId = 4,
        DistinguishedName = 5,
        FullName = 6,
        DisplayName = 7,
        Mobile = 8
    }
}