﻿<%@ Application Codebehind="Global.asax.cs" Inherits="ADGlobalService.WebApiApplication" Language="C#" %>
