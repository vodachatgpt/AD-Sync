using Serilog;
using System.Diagnostics;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace ADGlobalService.Filters
{
    public class PerformanceHandler : DelegatingHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request, CancellationToken cancellationToken)
        {
            var stopwatch = Stopwatch.StartNew();

            var response = await base.SendAsync(request, cancellationToken);

            stopwatch.Stop();

            double elapsedSeconds = stopwatch.ElapsedMilliseconds / 1000.0;
            var uri = IsSynchronizationEndpoint(request.RequestUri.AbsolutePath)
                ? request.RequestUri.AbsolutePath
                : request.RequestUri.PathAndQuery;

            var (level, emoji, action) = GetPerformanceStats(elapsedSeconds);
            var logEntry = $"[{level}] {emoji} Path: {uri} | " + $"Time: {elapsedSeconds:F2}s | Action Required: {action}";
            Log.Information(logEntry);

            return response;
        }
        private static bool IsSynchronizationEndpoint(string path)
        {
            return path.EndsWith("/api/AD/GetUsersForSync", System.StringComparison.OrdinalIgnoreCase)
                || path.EndsWith("/api/v2/AD/GetUsersForSync", System.StringComparison.OrdinalIgnoreCase)
                || path.EndsWith("/api/v2/AD/GetChangedUsers", System.StringComparison.OrdinalIgnoreCase)
                || path.EndsWith("/api/v2/AD/GetSyncSnapshot", System.StringComparison.OrdinalIgnoreCase);
        }

        private (string Level, string Emoji, string Action) GetPerformanceStats(double seconds)
        {
            if (seconds < 0.2)
                return ("OPTIMAL", "✅", "None - Healthy");

            if (seconds < 0.5)
                return ("ACCEPTABLE", "🟡", "Monitor for trends");

            if (seconds < 1.5)
                return ("DEGRADED", "🟠", "Investigate logic/queries");

            // Critical: Potential to cause thread pool starvation or timeouts
            return ("CRITICAL", "🚨", "Immediate optimization required");
        }
    }

}