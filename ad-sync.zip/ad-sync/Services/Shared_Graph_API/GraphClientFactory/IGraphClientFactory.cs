﻿using Microsoft.Graph;

namespace ADGlobalService.Services.GraphClientFactory
{
    public interface IGraphClientFactory
    {
        GraphServiceClient CreateAppClient();
        // GraphServiceClient CreateDelegatedClient(string userAccessToken);
    }
}
