﻿using Azure.Core.Pipeline;
using Azure.Identity;
using Microsoft.Graph;
using System;
using System.Net.Http;
using System.Web.Configuration;
namespace ADGlobalService.Services.GraphClientFactory
{
    public class GraphClientFactory : IGraphClientFactory
    {
        private readonly GraphServiceClient _appClient;

        public GraphClientFactory()
        {
            _appClient = BuildGraphAppClient();
        }

        public GraphServiceClient CreateAppClient()
        {
            return _appClient;
        }

        private GraphServiceClient BuildGraphAppClient()
        {
            var tenantId = WebConfigurationManager.AppSettings["TenantId"];
            var clientId = WebConfigurationManager.AppSettings["ClientId"];
            var clientSecret = WebConfigurationManager.AppSettings["ClientSecret"];
            var proxyUri = WebConfigurationManager.AppSettings["Proxy:Uri"];
            var useDefaultCreds = bool.Parse(WebConfigurationManager.AppSettings["Proxy:UseDefaultCredentials"] ?? "false");

            var webProxy = new System.Net.WebProxy(new Uri(proxyUri), true)
            {
                UseDefaultCredentials = useDefaultCreds
            };

            var httpClientHandler = new HttpClientHandler { Proxy = webProxy, UseProxy = webProxy != null };
            var identityHttpClient = new HttpClient(httpClientHandler, disposeHandler: true);
            var credOptions = new ClientSecretCredentialOptions
            {
                Transport = new HttpClientTransport(identityHttpClient)
            };
            var credential = new ClientSecretCredential(
                     tenantId,
                     clientId,
                     clientSecret,
                     credOptions
                     );
            var graphHttpClient = Microsoft.Graph.GraphClientFactory.Create(proxy: webProxy);
            var scopes = new[] { "https://graph.microsoft.com/.default" };
            return new GraphServiceClient(graphHttpClient, credential, scopes);
        }
    }
}