﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADGlobalService.Services.EmailService
{
    public sealed class SyncEmailReport
    {
        public string SyncName { get; set; }
        public string ItemName { get; set; } = "Records";

        public SyncEmailStatus Status { get; set; }
        public DateTime StartedAtUtc { get; set; }

        public string Stage { get; set; }

        public int? TotalItems { get; set; }
        public int ProcessedItems { get; set; }

        public int CompletedBatches { get; set; }
        public int? TotalBatches { get; set; }

        public string FailureReason { get; set; }
        public string Note { get; set; }

        public Dictionary<string, string> Metrics { get; } =
            new Dictionary<string, string>();

        public Dictionary<string, string> Details { get; } =
            new Dictionary<string, string>();
    }
}