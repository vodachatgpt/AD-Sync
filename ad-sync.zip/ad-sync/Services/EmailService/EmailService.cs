﻿using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ADGlobalService.Services.EmailService
{
    public sealed class EmailService : IEmailService
    {
        private static readonly HttpClient Client = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(30)
        };

        private readonly string _emailApiBaseUrl;
        private readonly string _fromEmail;

        public EmailService()
        {
            _emailApiBaseUrl = ConfigurationManager.AppSettings["EmailApiBaseUrl"]?.TrimEnd('/');

            _fromEmail = ConfigurationManager.AppSettings["EmailFrom"];

            if (string.IsNullOrWhiteSpace(_emailApiBaseUrl))
            {
                throw new ConfigurationErrorsException("EmailApiBaseUrl is missing.");
            }

            if (string.IsNullOrWhiteSpace(_fromEmail))
            {
                throw new ConfigurationErrorsException("EmailFrom is missing.");
            }
        }
                

        public async Task SendEmailAsync(
            bool isGuest,
            string to,
            string cc,
            string subject,
            string body)
        {
            if (string.IsNullOrWhiteSpace(to))
            {
                throw new ArgumentException("Recipient email is required.", nameof(to));

            }

           
            string url = $"{_emailApiBaseUrl}/api/NewMail/SendEmail";

            object payload = new
            {
                SendEmailTo = to,
                CcTo = cc,
                EmailSubject = subject,
                EmailBody = body
            };
             

            string json = JsonConvert.SerializeObject(payload);

            using (var content = new StringContent(
                json, Encoding.UTF8, "application/json"))



            
          using (var response = await Client.PostAsync(url, content))
            {
                if (!response.IsSuccessStatusCode)
                {
                    string error = await response.Content.ReadAsStringAsync();

                    System.Diagnostics.Trace.TraceError(
                        $"Email API Error | Status: {(int)response.StatusCode} | " +
                        $"Response: {error} | URL: {url}");

                    throw new HttpRequestException(
                        $"Email API failed: {(int)response.StatusCode} - {error}");
                }
          }

            }
        }
    }