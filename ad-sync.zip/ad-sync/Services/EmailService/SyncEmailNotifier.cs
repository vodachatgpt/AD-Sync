﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ADGlobalService.Services.EmailService
{
    public sealed class SyncEmailNotifier
    {
        private readonly IEmailService _emailService;

        public SyncEmailNotifier(IEmailService emailService)
        {
            _emailService = emailService
                ?? throw new ArgumentNullException(nameof(emailService));
        }

        public async Task TrySendAsync(SyncEmailReport report)
        {
            try
            {
                if (report == null)
                    throw new ArgumentNullException(nameof(report));

                string to = ConfigurationManager.AppSettings[
                    "DirectorySync:EmailTo"];

                string cc = ConfigurationManager.AppSettings[
                    "DirectorySync:EmailCc"] ?? "";

                string environment = ConfigurationManager.AppSettings[
                    "DirectorySync:Environment"] ?? "Unknown";

                if (string.IsNullOrWhiteSpace(to))
                {
                    Trace.TraceWarning("Sync notification recipient missing.");
                    return;
                }

                bool started = report.Status == SyncEmailStatus.Started;
                bool succeeded = report.Status == SyncEmailStatus.Succeeded;
                bool failed = report.Status == SyncEmailStatus.Failed;

                string status = report.Status.ToString().ToUpperInvariant();

                string accent = failed ? "#D62840"
                    : succeeded ? "#991B2B"
                    : "#B42338";

                string title = started ? "Sync started"
                    : succeeded ? "Sync completed"
                    : "Sync failed";

                DateTime now = DateTime.UtcNow;
                TimeSpan elapsed = now - report.StartedAtUtc;

                string duration = started
                    ? "Running"
                    : string.Format("{0:00}:{1:00}:{2:00}",
                        (int)elapsed.TotalHours,
                        elapsed.Minutes,
                        elapsed.Seconds);

                int progress = succeeded ? 100
                    : report.TotalItems.HasValue &&
                      report.TotalItems.Value > 0
                        ? Math.Min(100, (int)Math.Round(
                            report.ProcessedItems * 100.0 /
                            report.TotalItems.Value))
                        : 0;

                string FormatCount(int value)
                {
                    return value.ToString(
                        "N0", CultureInfo.InvariantCulture);
                }


                var metrics = new List<KeyValuePair<string, string>>
                {
                    new KeyValuePair<string, string>(
                        report.ItemName + " total",
                        report.TotalItems.HasValue
                            ? FormatCount(report.TotalItems.Value)
                            : "Pending"),

                    new KeyValuePair<string, string>(
                        report.ItemName + " processed",
                        FormatCount(report.ProcessedItems)),

                    new KeyValuePair<string, string>(
                        "Execution time",
                        duration)
                };

                // Only show batches when the sync actually tracks them.
                if (report.TotalBatches.HasValue)
                {
                    metrics.Insert(
                        2,
                        new KeyValuePair<string, string>(
                            "Batches completed",
                            $"{report.CompletedBatches} / {report.TotalBatches.Value}"));
                }

                foreach (var item in report.Metrics)
                {
                    metrics.Add(item);
                }


                foreach (var item in report.Metrics)
                    metrics.Add(item);

                var metricHtml = new StringBuilder();

                for (int i = 0; i < metrics.Count; i += 2)
                {
                    metricHtml.Append("<tr>");
                    metricHtml.Append(EmailMetric(
                        metrics[i].Key, metrics[i].Value));

                    if (i + 1 < metrics.Count)
                    {
                        metricHtml.Append(EmailMetric(
                            metrics[i + 1].Key,
                            metrics[i + 1].Value));
                    }
                    else
                    {
                        metricHtml.Append("<td width='50%'></td>");
                    }

                    metricHtml.Append("</tr>");
                }

                var detailsHtml = new StringBuilder();

                detailsHtml.Append(EmailRow("Environment", environment));
                detailsHtml.Append(EmailRow("Sync name", report.SyncName));
                detailsHtml.Append(EmailRow("Status", status));
                detailsHtml.Append(EmailRow("Current step", report.Stage));
                detailsHtml.Append(EmailRow(
                    "Started at (UTC)",
                    report.StartedAtUtc.ToString("yyyy-MM-dd HH:mm:ss")));

                detailsHtml.Append(EmailRow(
                    "Finished at (UTC)",
                    started ? "In progress" :
                    now.ToString("yyyy-MM-dd HH:mm:ss")));

                foreach (var item in report.Details)
                    detailsHtml.Append(EmailRow(item.Key, item.Value));

                string failureHtml = "";

                if (failed)
                {
                    string error = report.FailureReason ??
                        "See application logs.";

                    if (error.Length > 600)
                        error = error.Substring(0, 600) + "...";

                    failureHtml = $@"
                    <tr>
                        <td style='padding:0 30px 24px'>
                            <table width='100%' cellpadding='0'
                                   cellspacing='0'
                                   style='background:#FCE5E9'>
                                <tr>
                                    <td style='padding:20px;color:#991B2B'>
                                        <strong>FAILURE DETAILS</strong>
                                        <p>Failed step:
                                            {Encode(report.Stage)}
                                        </p>
                                        <p>Error:
                                            {Encode(error)}
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>";
                }

                string note = report.Note ??
                    (started
                        ? "Sync has started. A final notification will follow."
                        : succeeded
                            ? "Sync completed successfully."
                            : "Sync failed. Review the error details and application logs.");

                string body = $@"
                <!DOCTYPE html>
                <html>
                <body style='margin:0;padding:25px;
                             background:#FFF4F5;
                             font-family:Arial,Helvetica,sans-serif'>

                <table role='presentation' align='center'
                       width='650' cellpadding='0' cellspacing='0'
                       style='width:100%;max-width:650px;
                              background:#FFFFFF'>

                    <tr>
                        <td style='padding:30px;background:#650D18'>
                            <div style='font-size:12px;
                                        letter-spacing:2px;
                                        color:#F4C8CE'>
                                ADGLOBAL / DIRECTORY OPERATIONS
                            </div>

                            <h1 style='color:#FFFFFF;font-size:25px;
                                       margin:15px 0 12px'>
                                {Encode(title)}
                            </h1>

                            <div style='color:#FFFFFF;font-size:14px;
                                        font-weight:bold'>
                                {Encode(report.SyncName)} — {status}
                            </div>

                            <p style='color:#F4C8CE;font-size:13px'>
                                {Encode(environment)}
                                &nbsp; | &nbsp;
                                {report.StartedAtUtc:yyyy-MM-dd HH:mm} UTC
                            </p>
                        </td>
                    </tr>

                    <tr>
                        <td style='padding:24px'>
                            <table width='100%' cellpadding='0'
                                   cellspacing='0'>
                                {metricHtml}
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <td style='padding:0 30px 25px'>
                            <table width='100%' cellpadding='0'
                                   cellspacing='0'>
                                <tr>
                                    <td style='color:#650D18'>
                                        Processing progress
                                    </td>
                                    <td align='right'
                                        style='color:{accent};font-weight:bold'>
                                        {progress}%
                                    </td>
                                </tr>
                            </table>

                            <table width='100%' cellpadding='0'
                                   cellspacing='0'
                                   style='margin-top:12px;background:#F7DCE0'>
                                <tr>
                                    <td width='{progress}%'
                                        height='9'
                                        bgcolor='{accent}'></td>
                                    <td></td>
                                </tr>
                            </table>
                        </td>
                    </tr>

                    {failureHtml}

                    <tr>
                        <td style='padding:0 30px 24px'>
                            <h2 style='color:#650D18;font-size:16px'>
                                Execution details
                            </h2>

                            <table width='100%' cellpadding='0'
                                   cellspacing='0'>
                                {detailsHtml}
                            </table>
                        </td>
                    </tr>

                    <tr>
                        <td style='padding:0 30px 28px'>
                            <div style='background:#FFF0F2;
                                        color:#873A46;
                                        padding:16px;
                                        font-size:13px;
                                        line-height:1.6'>
                                {Encode(note)}
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td style='background:#FCEAEC;
                                   padding:18px;
                                   text-align:center;
                                   color:#99505B;
                                   font-size:11px'>
                            ADGlobalService |
                            Automated Sync Notification
                        </td>
                    </tr>

                </table>
                </body>
                </html>";

                string subject = started
                    ? $"[{environment}] {report.SyncName} - STARTED"
                    : $"[{environment}] {report.SyncName} - {status} - " +
                      $"{report.ProcessedItems:N0}/{report.TotalItems.GetValueOrDefault():N0}";

                await _emailService.SendEmailAsync(
                    false, to, cc, subject, body);
            }
            catch (Exception ex)
            {
                // Email failures must not affect Sync.
                Trace.TraceError(
                    "[SYNC EMAIL] Notification failed: " + ex);
            }
        }

        private static string Encode(string value)
        {
            return WebUtility.HtmlEncode(value ?? "—");
        }

        private static string EmailRow(string label, string value)
        {
            return $@"
            <tr>
                <td style='padding:11px 14px;
                           width:42%;
                           color:#99505B;
                           border-bottom:1px solid #F4D2D8'>
                    {Encode(label)}
                </td>
                <td style='padding:11px 14px;
                           color:#650D18;
                           font-weight:bold;
                           border-bottom:1px solid #F4D2D8'>
                    {Encode(value)}
                </td>
            </tr>";
        }

        private static string EmailMetric(string label, string value)
        {
            return $@"
            <td width='50%' style='padding:6px;vertical-align:top'>
                <table width='100%' cellpadding='0' cellspacing='0'
                       style='background:#FFF0F2;
                              border:1px solid #F4D2D8'>
                    <tr>
                        <td style='padding:17px 16px'>
                            <div style='font-size:23px;
                                        color:#650D18;
                                        font-weight:bold'>
                                {Encode(value)}
                            </div>
                            <div style='font-size:12px;
                                        color:#99505B;
                                        padding-top:5px'>
                                {Encode(label)}
                            </div>
                        </td>
                    </tr>
                </table>
            </td>";
        }
    }

}