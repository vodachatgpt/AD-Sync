﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADGlobalService.Services.EmailService
{
    public enum SyncEmailStatus
    {
        Started,
        Succeeded,
        Failed
    }
}