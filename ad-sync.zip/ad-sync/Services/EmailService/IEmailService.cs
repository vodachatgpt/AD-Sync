﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADGlobalService.Services.EmailService
{
    public interface IEmailService
    {
        Task SendEmailAsync(
            bool isGuest,
            string to,
            string cc,
            string subject,
            string body);
    }
}
