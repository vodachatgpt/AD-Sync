﻿using ADGlobalService.DependencyInjectionConfigs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADGlobalService.Services.HangfireService
{
    public interface IHangfireService : IInjectable
    {
        Task<bool> DeleteScheduleJobAsync(string key);
        Task AddScheduleJob(string key, string jobIntervalInCronExperssion, string targetEndpoint, Object Content = null);
        Task EnsureRecurringJobAsync(
            string key,
            string cronExpression, 
            string targetEndpoint,
            object content = null);
    }
}