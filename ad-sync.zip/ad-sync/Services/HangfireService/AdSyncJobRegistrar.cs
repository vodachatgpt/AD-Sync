﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ADGlobalService.Services.HangfireService
{
    public class AdSyncJobRegistrar 
    {
        private readonly IHangfireService _hangfireService;

        public AdSyncJobRegistrar(IHangfireService hangfireService)
        {
            _hangfireService = hangfireService
                ?? throw new ArgumentNullException(nameof(hangfireService));
        }

        public async Task EnsureAdSyncJobsRegisteredAsync()
        {
            var usersUrl = ConfigurationManager.AppSettings["AdSync.UsersUrl"];
            var groupsUrl = ConfigurationManager.AppSettings["AdSync.GroupsUrl"];
            var photosUrl = ConfigurationManager.AppSettings["AdSync.PhotosUrl"];
            var softDeleteUrl = ConfigurationManager.AppSettings["AdSync.softDeleteUrl"];

            var usersCron = ConfigurationManager.AppSettings["AdSync.UsersCron"];
            var groupsCron = ConfigurationManager.AppSettings["AdSync.GroupsCron"];
            var photosCron = ConfigurationManager.AppSettings["AdSync.PhotosCron"];
            var SoftDeleteCron = ConfigurationManager.AppSettings["AdSync.SoftDelete"];

            await _hangfireService.EnsureRecurringJobAsync(
                "AD-Users-Sync",
                usersCron,
                usersUrl);

            await _hangfireService.EnsureRecurringJobAsync(
                "AD-Groups-Sync",
                groupsCron,
                groupsUrl);

            await _hangfireService.EnsureRecurringJobAsync(
                "AD-SoftDelete-Sync",
                SoftDeleteCron,
                softDeleteUrl);
        }
    }
}