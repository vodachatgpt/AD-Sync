﻿using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace ADGlobalService.Services.HangfireService
{
    public class HangfireService : IHangfireService
    {
        private readonly HttpClient _httpClient;
        public HangfireService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        public async Task AddScheduleJob(string key, string jobIntervalInCronExperssion, string targetEndpoint, Object Content = null)
        {
            var url = ConfigurationManager.AppSettings["HangfireService.ApiURL"] + "api/jobs/AddScheduleJob";

            var jobBody = new AddScheduleJobDTO
            {
                url = targetEndpoint,
                jobIntervalInCronExperssion = jobIntervalInCronExperssion,
                key = key,
                Content = Content
            };

            var json = JsonConvert.SerializeObject(jobBody);
            StringContent httpContent = new StringContent(json, Encoding.UTF8, "application/json");


            using (var response = await _httpClient.PostAsync(url, httpContent))
            {
                var responseContent = await response.Content.ReadAsStringAsync();

                Log.Information(
                    $"Hangfire Registration - Job: {key}, " +
                    $"Status: {(int)response.StatusCode}, " +
                    $"Response: {responseContent}");

                if (!response.IsSuccessStatusCode)
                {
                    throw new Exception(
                        $"Failed to register Hangfire Job '{key}'. " +
                        $"Status: {response.StatusCode}. " +
                        $"Response: {responseContent}");
                }
            }
        }

        public async Task<bool> DeleteScheduleJobAsync(string key)
        {
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("Job key is required", nameof(key));

            var baseUrl = ConfigurationManager.AppSettings["HangfireService.ApiURL"];
            var url = $"{baseUrl.TrimEnd('/')}/api/jobs/RemoveJob?key={key}";

            var response = await _httpClient.DeleteAsync(url);

            if (response.IsSuccessStatusCode)
            {
                var responseContent = await response.Content.ReadAsStringAsync();

                return true;
            }


            return false;
        }

        public async Task EnsureRecurringJobAsync(string key, string cronExpression, string targetEndpoint, object content = null)
        {
            if (string.IsNullOrWhiteSpace(key))
                throw new ArgumentException("Job key is required", nameof(key));

            if (string.IsNullOrWhiteSpace(cronExpression))
                throw new ArgumentException("Cron expression is required", nameof(cronExpression));

            if (string.IsNullOrWhiteSpace(targetEndpoint))
                throw new ArgumentException("Target endpoint is required", nameof(targetEndpoint));

            // Remove old job if it exists so startup always guarantees a fresh schedule.
            await DeleteScheduleJobAsync(key);
            await AddScheduleJob(key, cronExpression, targetEndpoint, content);
        }

        public class OneTimeJobDTO
        {
            public object Content { get; set; }
            public string key { get; set; }
            public string url { get; set; }
            public DateTime? ScheduledAt { get; set; }
        }
        public class AddScheduleJobDTO : OneTimeJobDTO
        {
            public string jobIntervalInCronExperssion { get; set; }
        }
        public class JobContent
        {
            public string Type { get; set; }
            public object Data { get; set; }
        }
    }
}