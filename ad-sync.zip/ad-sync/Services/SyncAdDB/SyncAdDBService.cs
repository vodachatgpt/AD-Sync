﻿using ActiveDirectory.DTOs;
using ADGlobalService.Abstractions;
using ADGlobalService.Data;
using ADGlobalService.Models.SyncAdDBDtos;
using ADGlobalService.Services.ActiveDirectoryService;
using ADGlobalService.Services.EmailService;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Serilog;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Diagnostics;
using System.DirectoryServices.Protocols;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ADGlobalService.Services.SyncAdDB
{
    public sealed class SyncAdDBService : ISyncAdDBService
    {
        readonly ActiveDirectoryDBEntities _activeDirectoryDB;
        private readonly SyncEmailNotifier _syncEmailNotifier;
        private readonly IActiveDirectoryService _activeDirectoryService;
        private readonly IEmailService _emailService;

        public SyncAdDBService(
            ActiveDirectoryDBEntities activeDirectoryDB,
            HttpClient httpClient,
            IActiveDirectoryService activeDirectoryService,
            IEmailService emailService,
            SyncEmailNotifier syncEmailNotifier)
        {
            _activeDirectoryDB = activeDirectoryDB
                ?? throw new ArgumentNullException(nameof(activeDirectoryDB));

            _activeDirectoryDB.Configuration.LazyLoadingEnabled = false;
            _activeDirectoryDB.Configuration.ProxyCreationEnabled = false;

            _activeDirectoryService = activeDirectoryService;
            _emailService = emailService;
            _syncEmailNotifier = syncEmailNotifier;
        }


        // ============================================
        // Dispose
        // ============================================

        public void Dispose()
        {
            _activeDirectoryDB.Dispose();
        }





        // ============================================
        // sync
        // ============================================



        public async Task<Result<JArray>> GetMembersFromAdAsync(string department)
        {
            if (string.IsNullOrWhiteSpace(department))
            {
                return Result.Failure<JArray>(
                    new Error("Department.Invalid", "Department is required."));
            }

            try
            {
                List<Dictionary<string, object>> users = await _activeDirectoryService
                        .GetUsersRawAttributesByDepartmentAsync(department.Trim());

                if (users == null)
                {
                    return Result.Failure<JArray>(
                        new Error("AD.InvalidResponse", "Active Directory returned null."));
                }

                JArray data = JArray.FromObject(users);

                return Result.Success(data);
            }
            catch (Exception)
            {
                return Result.Failure<JArray>(
                    new Error("AD.RequestFailed", "Failed to retrieve Active Directory users."));
            }
        }





        public async Task<Result<int>> SyncDepartmentAsync(string department)
        {
            if (string.IsNullOrWhiteSpace(department))
            {
                return Result.Failure<int>(
                    new Error("Department.Invalid", "Department is required."));
            }

            department = department.Trim();

            string syncName = "Department:" + department;

            if (syncName.Length > 100)
            {
                return Result.Failure<int>(
                    new Error("Department.Invalid", "Department name is too long."));
            }

            // =====================================================
            // 1. GET ACTIVE DIRECTORY DATA
            // =====================================================

            Result<JArray> adResult =
                await GetMembersFromAdAsync(department);

            if (adResult.IsFailure)
                return Result.Failure<int>(adResult.Error);

            if (adResult.Value == null)
            {
                return Result.Failure<int>(
                    new Error("AD.InvalidResponse", "Invalid AD response."));
            }

            var adUsers = new Dictionary<Guid, JObject>();

            foreach (JToken token in adResult.Value)
            {
                JObject adUser = token as JObject;

                if (adUser == null)
                {
                    return Result.Failure<int>(
                        new Error("AD.InvalidUser", "Invalid AD user."));
                }

                Guid guid;

                if (!TryGetAdGuid(adUser, out guid))
                {
                    return Result.Failure<int>(
                        new Error("AD.InvalidGuid", "Invalid AD objectGUID."));
                }

                //if (!adUsers.TryAddCompatible(guid, adUser))
                //{
                //    return Result.Failure<int>(
                //        new Error("AD.DuplicateGuid", "Duplicate objectGUID."));
                //}

                if (adUsers.ContainsKey(guid))
                {
                    return Result.Failure<int>(
                        new Error("AD.DuplicateGuid", "Duplicate objectGUID."));
                }

                adUsers.Add(guid, adUser);
            }

            if (adUsers.Count == 0)
            {
                return Result.Failure<int>(
                    new Error("AD.EmptySnapshot", "No users returned from AD."));
            }

            // =====================================================
            // 2. PREPARE ATTRIBUTES IN MEMORY
            // =====================================================

            var desiredAttributesByGuid =
                new Dictionary<Guid, List<DirectoryUserAttributeValue>>();

            foreach (KeyValuePair<Guid, JObject> item in adUsers)
            {
                desiredAttributesByGuid[item.Key] =
                    BuildUserAttributes(item.Value);
            }

            // =====================================================
            // 3. LOAD EXISTING USERS BEFORE TRANSACTION
            // =====================================================

            List<Guid> guids = adUsers.Keys.ToList();

            var usersByGuid = new Dictionary<Guid, DirectoryUser>();

            for (int i = 0; i < guids.Count; i += 400)
            {
                List<Guid> batch = guids.Skip(i).Take(400).ToList();

                List<DirectoryUser> existing =
                    await _activeDirectoryDB.DirectoryUsers
                        .Where(x => batch.Contains(x.ActiveDirectoryObjectGuid))
                        .ToListAsync();

                foreach (DirectoryUser user in existing)
                {
                    usersByGuid.Add(user.ActiveDirectoryObjectGuid, user);
                }
            }

            // =====================================================
            // 4. LOAD EXISTING METADATA AND ATTRIBUTES
            //    BEFORE TRANSACTION
            // =====================================================

            List<long> existingUserIds = usersByGuid.Values
                .Select(x => x.UserId)
                .ToList();

            var metadataByUserId =
                new Dictionary<long, DirectoryUserAccountMetadata>();

            var oldAttributes =
                new List<DirectoryUserAttributeValue>();

            for (int i = 0; i < existingUserIds.Count; i += 400)
            {
                List<long> batch = existingUserIds
                    .Skip(i)
                    .Take(400)
                    .ToList();

                List<DirectoryUserAccountMetadata> metadata =
                    await _activeDirectoryDB
                        .Set<DirectoryUserAccountMetadata>()
                        .Where(x => batch.Contains(x.UserId))
                        .ToListAsync();

                foreach (DirectoryUserAccountMetadata item in metadata)
                {
                    metadataByUserId[item.UserId] = item;
                }

                List<DirectoryUserAttributeValue> attributes =
                    await _activeDirectoryDB
                        .Set<DirectoryUserAttributeValue>()
                        .Where(x => batch.Contains(x.UserId))
                        .ToListAsync();

                oldAttributes.AddRange(attributes);
            }

            // =====================================================
            // 5. PREPARE USER INSERTS / UPDATES
            // =====================================================

            var newUsers = new List<DirectoryUser>();

            foreach (KeyValuePair<Guid, JObject> item in adUsers)
            {
                DirectoryUser user;

                if (!usersByGuid.TryGetValue(item.Key, out user))
                {
                    user = new DirectoryUser
                    {
                        ActiveDirectoryObjectGuid = item.Key
                    };

                    newUsers.Add(user);
                    usersByGuid.Add(item.Key, user);
                }

                MapDirectoryUser(user, item.Value);

                user.IsDeleted = false;
            }

            if (newUsers.Count > 0)
            {
                _activeDirectoryDB.DirectoryUsers.AddRange(newUsers);
            }

            // =====================================================
            // 6. PREPARE OLD ATTRIBUTE LOOKUP
            // =====================================================

            var oldAttributesByKey =
                new Dictionary<
                    Tuple<long, string, int>,
                    DirectoryUserAttributeValue>();

            foreach (DirectoryUserAttributeValue attribute in oldAttributes)
            {
                if (!ExtraAttributeNames.Contains(attribute.AttributeName))
                    continue;

                var key = GetAttributeKey(attribute);

                oldAttributesByKey.Add(key, attribute);
            }

            // =====================================================
            // 7. SHORT TRANSACTION FOR DATABASE WRITES
            // =====================================================

            using (var transaction =
                _activeDirectoryDB.Database.BeginTransaction())
            {
                // Generate UserId for newly inserted users.
                // Existing tracked user updates are also saved here.

                if (newUsers.Count > 0)
                {
                    await _activeDirectoryDB.SaveChangesAsync();
                }

                // =================================================
                // 8. UPSERT ACCOUNT METADATA
                // =================================================

                var newMetadata =
                    new List<DirectoryUserAccountMetadata>();

                foreach (KeyValuePair<Guid, JObject> item in adUsers)
                {
                    long userId = usersByGuid[item.Key].UserId;

                    DirectoryUserAccountMetadata metadata;

                    if (!metadataByUserId.TryGetValue(userId, out metadata))
                    {
                        metadata = new DirectoryUserAccountMetadata
                        {
                            UserId = userId
                        };

                        newMetadata.Add(metadata);
                        metadataByUserId.Add(userId, metadata);
                    }

                    MapAccountMetadata(metadata, item.Value);
                }

                if (newMetadata.Count > 0)
                {
                    _activeDirectoryDB
                        .Set<DirectoryUserAccountMetadata>()
                        .AddRange(newMetadata);
                }

                // =================================================
                // 9. COMPARE ATTRIBUTES (DIFF)
                // =================================================

                var attributesToInsert =
                    new List<DirectoryUserAttributeValue>();

                var attributesToDelete =
                    new List<DirectoryUserAttributeValue>();

                var matchedKeys =
                    new HashSet<Tuple<long, string, int>>();

                foreach (KeyValuePair<Guid, JObject> item in adUsers)
                {
                    long userId = usersByGuid[item.Key].UserId;

                    List<DirectoryUserAttributeValue> desired =
                        desiredAttributesByGuid[item.Key];

                    foreach (DirectoryUserAttributeValue newAttribute in desired)
                    {
                        newAttribute.UserId = userId;

                        var key = GetAttributeKey(newAttribute);

                        if (!matchedKeys.Add(key))
                        {
                            throw new InvalidOperationException(
                                "Duplicate attribute: " + newAttribute.AttributeName);
                        }

                        DirectoryUserAttributeValue oldAttribute;

                        if (!oldAttributesByKey.TryGetValue(key, out oldAttribute))
                        {
                            attributesToInsert.Add(newAttribute);
                            continue;
                        }

                        if (!SameAttributeValue(oldAttribute, newAttribute))
                        {
                            oldAttribute.StringValue = newAttribute.StringValue;
                            oldAttribute.NumberValue = newAttribute.NumberValue;
                            oldAttribute.DateValue = newAttribute.DateValue;
                            oldAttribute.BinaryValue = newAttribute.BinaryValue;
                        }
                    }
                }

                foreach (var item in oldAttributesByKey)
                {
                    if (!matchedKeys.Contains(item.Key))
                    {
                        attributesToDelete.Add(item.Value);
                    }
                }

                // =================================================
                // 10. BATCH ADD / REMOVE
                // =================================================

                bool originalDetectChanges =
                    _activeDirectoryDB.Configuration.AutoDetectChangesEnabled;

                try
                {
                    _activeDirectoryDB.Configuration.AutoDetectChangesEnabled = false;

                    if (attributesToDelete.Count > 0)
                    {
                        _activeDirectoryDB
                            .Set<DirectoryUserAttributeValue>()
                            .RemoveRange(attributesToDelete);
                    }

                    if (attributesToInsert.Count > 0)
                    {
                        _activeDirectoryDB
                            .Set<DirectoryUserAttributeValue>()
                            .AddRange(attributesToInsert);
                    }
                }
                finally
                {
                    _activeDirectoryDB.Configuration.AutoDetectChangesEnabled =
                        originalDetectChanges;
                }

                // =================================================
                // 11. UPDATE SYNC STATE
                // =================================================

                DirectorySyncState state =
                    await _activeDirectoryDB
                        .Set<DirectorySyncState>()
                        .FirstOrDefaultAsync(x => x.SyncName == syncName);

                if (state == null)
                {
                    state = new DirectorySyncState
                    {
                        SyncName = syncName,
                        TrackingMethod = "Full"
                    };

                    _activeDirectoryDB
                        .Set<DirectorySyncState>()
                        .Add(state);
                }

                state.LastSuccessfulSyncUtc = DateTime.UtcNow;

                // =================================================
                // 12. SAVE ALL CHANGES
                // =================================================

                await _activeDirectoryDB.SaveChangesAsync();


                // =====================================================
                // 13. RESOLVE MANAGERS - CURRENT DEPARTMENT ONLY
                // =====================================================

                //await _activeDirectoryDB.Database.ExecuteSqlCommandAsync(
                //    @"
                //    UPDATE employee
                //    SET employee.ManagerUserId = manager.UserId
                //    FROM dbo.DirectoryUsers AS employee
                //    INNER JOIN dbo.DirectoryUsers AS manager
                //        ON manager.DistinguishedName =
                //           employee.ManagerDistinguishedName
                //        AND manager.IsDeleted = 0
                //        AND manager.UserId <> employee.UserId
                //    WHERE employee.IsDeleted = 0
                //      AND employee.Department = @p0
                //      AND (
                //          employee.ManagerUserId IS NULL
                //          OR employee.ManagerUserId <> manager.UserId
                //      );
                //    ",
                //    department
                //);


                // =================================================
                // 14. COMMIT
                // =================================================

                transaction.Commit();
            }

            return Result.Success(adUsers.Count);
        }





        private static void MapDirectoryUser(DirectoryUser user, JObject ad)
        {
            // Identity
            user.ActiveDirectoryObjectSid = GetAdValue(ad, "objectSid");
            user.DistinguishedName = GetAdValue(ad, "distinguishedName");
            user.CommonName = GetAdValue(ad, "cn");
            user.ObjectName = GetAdValue(ad, "name");

            // Account
            user.NT = GetAdValue(ad, "sAMAccountName");
            user.UserPrincipalName = GetAdValue(ad, "userPrincipalName");
            user.MailAlias = GetAdValue(ad, "mailNickname");

            // Personal Information
            user.DisplayName = GetAdValue(ad, "displayName");
            user.FirstName = GetAdValue(ad, "givenName");
            user.LastName = GetAdValue(ad, "sn");
            user.MiddleName = GetAdValue(ad, "middleName");

            // Contact Information
            user.Email = GetAdValue(ad, "mail");
            user.MobileNumber = GetAdValue(ad, "mobile");

            // Country
            user.CountryIsoCode = GetAdValue(ad, "c");
            user.CountryName = GetAdValue(ad, "co");
            user.CountryNumericCode = ParseInt(GetAdValue(ad, "countryCode"));

            // Organization

            user.Department = NormalizeDepartmentName(GetAdValue(ad, "department"));

            user.JobTitle = GetAdValue(ad, "title");
            user.CompanyName = GetAdValue(ad, "company");
            user.StaffId = GetAdValue(ad, "employeeID");
            user.Office = GetAdValue(ad, "physicalDeliveryOfficeName");
            user.Description = GetAdValue(ad, "description");

            user.HoDNT = GetAdValue(ad, "VF-extensionAttribute04");
            user.ManagerNT = GetAdValue(ad, "extensionAttribute7");
            user.SubDepartment = GetAdValue(ad, "extensionAttribute6");

            user.Gender = NormalizeGender(GetAdValue(ad, "extensionAttribute8"));



            // Hierarchy
            user.ManagerDistinguishedName = GetAdValue(ad, "manager");

            // ManagerUserId is resolved after all departments sync

            // Account Status
            user.UserAccountControl =
                ParseInt(GetAdValue(ad, "userAccountControl"));

            user.PrimaryGroupId =
                ParseInt(GetAdValue(ad, "primaryGroupID"));

            user.IsEnabled = user.UserAccountControl.HasValue
                ? (bool?)((user.UserAccountControl.Value & 2) == 0)
                : null;

            // Dates
            user.CreatedInAdAtUtc =
                ParseAdDate(GetAdValue(ad, "whenCreated"));

            user.ModifiedInAdAtUtc =
                ParseAdDate(GetAdValue(ad, "whenChanged"));

            // Custom Attributes
            //user.AlternateJobTitle = GetAdValue(ad, "jobTitle");
            user.FullName = GetAdValue(ad, "fullName");
            user.HiringDate = GetAdValue(ad, "hiringDate");
            user.CostCenter = GetAdValue(ad, "costCenter");
            user.ReportTo = GetAdValue(ad, "gweReportingTo");
            user.IsInternal = GetAdValue(ad, "gweinternalUser");

            user.SapId = GetAdValue(ad, "extensionAttribute10");



            var token = ad.GetValue(
                "uSNChanged",
                StringComparison.OrdinalIgnoreCase);

            string value = token is JArray array
                ? array.First?.ToString()
                : token?.ToString();

            long usn;

            if (!long.TryParse(value, out usn) || usn <= 0)
            {
                throw new FormatException(
                    $"Invalid uSNChanged. User: {GetAdValue(ad, "sAMAccountName")}, Value: {value ?? "NULL"}");
            }

            user.UsnChanged = usn;



        }



        private static void MapAccountMetadata(
            DirectoryUserAccountMetadata metadata,
            JObject ad)
        {
            string pwdLastSet = GetAdValue(ad, "pwdLastSet");
            string accountExpires = GetAdValue(ad, "accountExpires");

            metadata.PasswordLastSetUtc = ParseAdFileTime(pwdLastSet);

            metadata.MustChangePassword = pwdLastSet == null
                ? (bool?)null
                : pwdLastSet == "0";

            metadata.AccountNeverExpires = accountExpires == null
                ? (bool?)null
                : accountExpires == "0" ||
                  accountExpires == long.MaxValue.ToString();

            metadata.AccountExpiresAtUtc =
                metadata.AccountNeverExpires == true
                    ? (DateTime?)null
                    : ParseAdFileTime(accountExpires);

            metadata.LockoutTimeUtc =
                ParseAdFileTime(GetAdValue(ad, "lockoutTime"));

            metadata.LastLogonApproxUtc =
                ParseAdFileTime(GetAdValue(ad, "lastLogonTimestamp"));

            metadata.SamAccountType =
                ParseInt(GetAdValue(ad, "sAMAccountType"));

            metadata.LastSyncedAtUtc = DateTime.UtcNow;
        }


        private static readonly string[] StringExtraAttributes =
        {
            // Cloud
            "msDS-cloudExtensionAttribute5",
            "msDS-cloudExtensionAttribute12",
            "msDS-cloudExtensionAttribute18",
            "msDS-cloudExtensionAttribute19",
            "msDS-cloudExtensionAttribute20",

    // Extensions
    "extensionAttribute1",
    "extensionAttribute2",
    "extensionAttribute3",
    "extensionAttribute4",
    "extensionAttribute5",
    "extensionAttribute6",
    "extensionAttribute7",
    "extensionAttribute8",
    "extensionAttribute9",
    "extensionAttribute10",
    "extensionAttribute14",

    // Exchange
    "targetAddress",
    "showInAddressBook",
    "proxyAddresses",
    "legacyExchangeDN",

    // Additional
    "msDS-ExternalDirectoryObjectId",
    "otherMobile",

    // User's direct group DNs, without Group Sync
    "memberOf"
};

        private static readonly string[] NumberExtraAttributes =
        {
    "msExchRecipientTypeDetails",
    "msExchRemoteRecipientType",
    "msExchRecipientDisplayType"
};

        private static readonly string[] BinaryExtraAttributes =
        {
    "mS-DS-ConsistencyGuid"
};

        private static readonly HashSet<string> ExtraAttributeNames =
            new HashSet<string>(
                StringExtraAttributes
                    .Concat(NumberExtraAttributes)
                    .Concat(BinaryExtraAttributes),
                StringComparer.OrdinalIgnoreCase
            );





        private static List<DirectoryUserAttributeValue> BuildUserAttributes(
            JObject ad)
        {
            var result = new List<DirectoryUserAttributeValue>();

            // String attributes
            foreach (string name in StringExtraAttributes)
            {
                int index = 0;

                foreach (JToken value in GetAdValues(ad, name))
                {
                    result.Add(new DirectoryUserAttributeValue
                    {
                        AttributeName = name,
                        ValueIndex = index++,
                        StringValue = value.ToString()
                    });
                }
            }

            // Number attributes
            foreach (string name in NumberExtraAttributes)
            {
                int index = 0;

                foreach (JToken value in GetAdValues(ad, name))
                {
                    long number;

                    if (!long.TryParse(value.ToString(), out number))
                    {
                        throw new FormatException(
                            "Invalid AD numeric attribute: " + name);
                    }

                    result.Add(new DirectoryUserAttributeValue
                    {
                        AttributeName = name,
                        ValueIndex = index++,
                        NumberValue = number
                    });
                }
            }

            // Binary attributes
            foreach (string name in BinaryExtraAttributes)
            {
                int index = 0;

                foreach (JToken value in GetAdValues(ad, name))
                {
                    result.Add(new DirectoryUserAttributeValue
                    {
                        AttributeName = name,
                        ValueIndex = index++,
                        BinaryValue = Convert.FromBase64String(
                            value.ToString())
                    });
                }
            }

            return result;
        }



        private static Tuple<long, string, int> GetAttributeKey(
            DirectoryUserAttributeValue attribute)
        {
            return Tuple.Create(
                attribute.UserId,
                attribute.AttributeName.ToUpperInvariant(),
                attribute.ValueIndex);
        }

        private static bool SameAttributeValue(
            DirectoryUserAttributeValue oldValue,
            DirectoryUserAttributeValue newValue)
        {
            bool stringsEqual = string.Equals(
                oldValue.StringValue,
                newValue.StringValue,
                StringComparison.Ordinal);

            bool numbersEqual = Nullable.Equals(
                oldValue.NumberValue,
                newValue.NumberValue);

            bool datesEqual = Nullable.Equals(
                oldValue.DateValue,
                newValue.DateValue);

            bool binaryEqual = SameBytes(
                oldValue.BinaryValue,
                newValue.BinaryValue);

            return stringsEqual &&
                   numbersEqual &&
                   datesEqual &&
                   binaryEqual;
        }

        private static bool SameBytes(byte[] first, byte[] second)
        {
            if (ReferenceEquals(first, second))
                return true;

            if (first == null || second == null)
                return false;

            return first.SequenceEqual(second);
        }


        private static JToken GetAdToken(JObject ad, string name)
        {
            JProperty property = ad.Properties()
                .FirstOrDefault(x => string.Equals(
                    x.Name,
                    name,
                    StringComparison.OrdinalIgnoreCase));

            return property == null ? null : property.Value;
        }

        private static string GetAdValue(JObject ad, string name)
        {
            JToken token = GetAdToken(ad, name);

            if (token == null || token.Type == JTokenType.Null)
                return null;

            JArray array = token as JArray;

            if (array != null)
            {
                if (array.Count == 0)
                    return null;

                token = array[0];
            }

            return token.Type == JTokenType.Null
                ? null
                : token.ToString();
        }

        private static IEnumerable<JToken> GetAdValues(
            JObject ad,
            string attributeName)
        {
            JToken token = GetAdToken(ad, attributeName);

            if (token == null || token.Type == JTokenType.Null)
                yield break;

            JArray array = token as JArray;

            if (array != null)
            {
                foreach (JToken item in array)
                {
                    if (item != null && item.Type != JTokenType.Null)
                        yield return item;
                }
            }
            else
            {
                yield return token;
            }
        }

        private static bool TryGetAdGuid(JObject ad, out Guid guid)
        {
            string value = GetAdValue(ad, "objectGUID");

            if (Guid.TryParse(value, out guid))
                return guid != Guid.Empty;

            try
            {
                byte[] bytes = Convert.FromBase64String(value ?? "");

                if (bytes.Length == 16)
                {
                    guid = new Guid(bytes);
                    return guid != Guid.Empty;
                }
            }
            catch (FormatException)
            {
            }

            guid = Guid.Empty;
            return false;
        }

        private static int? ParseInt(string value)
        {
            int number;

            return int.TryParse(value, out number)
                ? (int?)number
                : null;
        }

        // AD whenCreated / whenChanged / ISO dates
        private static DateTime? ParseAdDate(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            DateTime date;

            // LDAP Generalized Time:
            // 20261020120000.0Z
            if (value.EndsWith("Z", StringComparison.OrdinalIgnoreCase)
                && value.Length >= 15
                && DateTime.TryParseExact(
                    value.Substring(0, 14),
                    "yyyyMMddHHmmss",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.AssumeUniversal |
                    System.Globalization.DateTimeStyles.AdjustToUniversal,
                    out date))
            {
                return date;
            }

            DateTimeOffset offset;

            if (DateTimeOffset.TryParse(
                value,
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.AssumeUniversal,
                out offset))
            {
                return offset.UtcDateTime;
            }

            return null;
        }

        // AD FILETIME:
        // pwdLastSet, accountExpires, lockoutTime,
        // lastLogonTimestamp
        private static DateTime? ParseAdFileTime(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
                return null;

            long fileTime;

            if (long.TryParse(value, out fileTime))
            {
                if (fileTime <= 0 || fileTime == long.MaxValue)
                    return null;

                try
                {
                    return DateTime.FromFileTimeUtc(fileTime);
                }
                catch (ArgumentOutOfRangeException)
                {
                    return null;
                }
            }

            // Supports ISO dates if AD API already converted them
            return ParseAdDate(value);
        }





        private static string ReadAdProperty(
            JObject obj,
            params string[] names)
        {
            string value;

            return TryReadAdProperty(obj, out value, names)
                ? value
                : null;
        }

        private static bool TryReadAdProperty(
            JObject obj,
            out string value,
            params string[] names)
        {
            foreach (string name in names)
            {
                JProperty property = obj.Properties()
                    .FirstOrDefault(x =>
                        string.Equals(x.Name, name,
                            StringComparison.OrdinalIgnoreCase));

                if (property == null)
                    continue;

                value = property.Value.Type == JTokenType.Null
                    ? null
                    : property.Value.ToString();

                return true;
            }

            value = null;
            return false;
        }








        public async Task<Result<List<DirectoryUserHierarchyNode>>> GetUsersByDepartmentAsync(
            string department = null,
            bool hierarchical = false)
        {
            //var sw = System.Diagnostics.Stopwatch.StartNew();

            // 1. Build SQL Query
            IQueryable<DirectoryUser> query = _activeDirectoryDB.DirectoryUsers
                .AsNoTracking()
                .Where(x => !x.IsDeleted);

            if (!string.IsNullOrWhiteSpace(department))
            {
                department = department.Trim();

                query = query.Where(x => x.Department == department);
            }

            // 2. Get Users
            List<DirectoryUserHierarchyNode> users = await query
                .OrderBy(x => x.FullName)
                .Select(user => new DirectoryUserHierarchyNode
                {
                    UserId = user.UserId,
                    // Identity
                    NT = user.NT,
                    UserPrincipalName = user.UserPrincipalName,

                    // Personal
                    FullName = user.FullName,
                    FirstName = user.FirstName,
                    LastName = user.LastName,

                    // Contact
                    Email = user.Email,
                    MobileNumber = user.MobileNumber,

                    // Organization
                    Department = user.Department,
                    JobTitle = user.JobTitle,
                    Company = user.CompanyName,
                    StaffId = user.StaffId,
                    Office = user.Office,
                    CostCenter = user.CostCenter,
                    Description = user.Description,

                    // Additional
                    CountryName = user.CountryName,
                    HiringDate = user.HiringDate,
                    ReportTo = user.ReportTo,
                    GweInternalUserRaw = user.IsInternal,

                    // Hierarchy
                    ManagerUserId = user.ManagerUserId,
                    ManagerDistinguishedName = user.ManagerDistinguishedName
                })
                .ToListAsync();

            //System.Diagnostics.Debug.WriteLine(
            //    $"[1] EF Users Query: {sw.ElapsedMilliseconds} ms | Count: {users.Count}");

            //sw.Restart();

            // 3. Fast lookup for all loaded users
            Dictionary<long, DirectoryUserHierarchyNode> userDictionary =
                users.ToDictionary(x => x.UserId);


            List<long> missingManagerIds = users
                .Where(x =>
                    x.ManagerUserId.HasValue &&
                    !userDictionary.ContainsKey(x.ManagerUserId.Value))
                .Select(x => x.ManagerUserId.Value)
                .Distinct()
                .ToList();

            Dictionary<long, string> externalManagers =
                new Dictionary<long, string>();

            if (missingManagerIds.Count > 0)
            {
                externalManagers = await _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x =>
                        !x.IsDeleted &&
                        missingManagerIds.Contains(x.UserId))
                    .Select(x => new
                    {
                        x.UserId,
                        x.FullName
                    })
                    .ToDictionaryAsync(x => x.UserId, x => x.FullName);
            }

            //System.Diagnostics.Debug.WriteLine(
            //    $"[2] External Managers Query: {sw.ElapsedMilliseconds} ms");

            //sw.Restart();

            // 5. Resolve Manager Names and Internal User Flag
            foreach (DirectoryUserHierarchyNode user in users)
            {
                bool isInternal;

                user.IsInternalUser =
                    bool.TryParse(user.GweInternalUserRaw, out isInternal)
                        ? (bool?)isInternal
                        : null;

                if (!user.ManagerUserId.HasValue)
                {
                    continue;

                }

                long managerId = user.ManagerUserId.Value;

                DirectoryUserHierarchyNode manager;
                string managerName;

                if (userDictionary.TryGetValue(managerId, out manager))
                {
                    user.ManagerFullName = manager.FullName;
                }
                else if (externalManagers.TryGetValue(managerId, out managerName))
                {
                    user.ManagerFullName = managerName;
                }
            }

            //System.Diagnostics.Debug.WriteLine(
            //    $"[3] Mapping: {sw.ElapsedMilliseconds} ms");

            //sw.Restart();

            // 6. Flat List
            if (!hierarchical)
            {
                return Result.Success(users);
            }

            // 7. Build Hierarchy
            //List<DirectoryUserHierarchyNode> hierarchy =
            //    new List<DirectoryUserHierarchyNode>();

            //foreach (DirectoryUserHierarchyNode user in users)
            //{
            //    DirectoryUserHierarchyNode manager;

            //    if (user.ManagerUserId.HasValue &&
            //        userDictionary.TryGetValue(
            //            user.ManagerUserId.Value, out manager) &&
            //        !HasManagerCycle(user, userDictionary))
            //    {
            //        manager.Children.Add(user);
            //    }
            //    else
            //    {
            //        hierarchy.Add(user);
            //    }
            //}


            List<DirectoryUserHierarchyNode> hierarchy = BuildHierarchyFast(users, userDictionary);



            //System.Diagnostics.Debug.WriteLine(
            //    $"[4] Hierarchy Building: {sw.ElapsedMilliseconds} ms");

            return Result.Success(hierarchy);
        }



        private static List<DirectoryUserHierarchyNode> BuildHierarchyFast(
            List<DirectoryUserHierarchyNode> users,
            Dictionary<long, DirectoryUserHierarchyNode> userDictionary)
        {
            var states = new Dictionary<long, byte>(users.Count);
            var cycleBreakers = new HashSet<long>();
            var path = new List<long>();

            // Step 1: Detect cycles in O(N)
            foreach (var start in users)
            {
                if (states.ContainsKey(start.UserId))
                    continue;

                path.Clear();

                var current = start;

                while (current != null)
                {
                    byte state;

                    if (states.TryGetValue(current.UserId, out state))
                    {
                        // 1 = Currently visiting
                        // 2 = Fully processed
                        if (state == 1)
                        {
                            cycleBreakers.Add(current.UserId);
                        }

                        break;
                    }

                    states[current.UserId] = 1;
                    path.Add(current.UserId);

                    DirectoryUserHierarchyNode manager;

                    if (current.ManagerUserId.HasValue &&
                        userDictionary.TryGetValue(
                            current.ManagerUserId.Value, out manager))
                    {
                        current = manager;
                    }
                    else
                    {
                        current = null;
                    }
                }

                foreach (long id in path)
                {
                    states[id] = 2;
                }
            }

            // Step 2: Build tree in O(N)
            var roots = new List<DirectoryUserHierarchyNode>();

            foreach (var user in users)
            {
                DirectoryUserHierarchyNode manager;

                if (!cycleBreakers.Contains(user.UserId) &&
                    user.ManagerUserId.HasValue &&
                    userDictionary.TryGetValue(
                        user.ManagerUserId.Value, out manager))
                {
                    manager.Children.Add(user);
                }
                else
                {
                    roots.Add(user);
                }
            }

            return roots;
        }


        public async Task<Result<object>> GetDepartmentChangesAsync(
            string department)
        {
            if (string.IsNullOrWhiteSpace(department))
            {
                return Result.Failure<object>(
                    new Error("Department.Invalid", "Department is required."));
            }

            department = department.Trim();

            // Get current users from Active Directory
            Result<JArray> adResult =
                await GetMembersFromAdAsync(department);

            if (adResult.IsFailure)
                return Result.Failure<object>(adResult.Error);

            // Get current users from SQL
            var sqlUsers = await _activeDirectoryDB.DirectoryUsers
                .AsNoTracking()
                .Where(x => x.Department == department && !x.IsDeleted)
                .Select(x => new
                {
                    x.ActiveDirectoryObjectGuid,
                    x.NT,
                    x.FullName,
                    x.Email,
                    x.Department,
                    x.JobTitle,
                    x.CompanyName,
                    x.ManagerDistinguishedName
                })
                .ToListAsync();

            var sqlDictionary = sqlUsers.ToDictionary(
                x => x.ActiveDirectoryObjectGuid);

            var added = new List<object>();
            var updated = new List<object>();
            var adGuids = new HashSet<Guid>();

            foreach (JToken token in adResult.Value)
            {
                JObject adUser = token as JObject;

                if (adUser == null)
                    throw new InvalidOperationException("Invalid AD user.");

                string guidText = ReadAdProperty(adUser, "objectGUID");

                Guid guid;

                if (!Guid.TryParse(guidText, out guid) || guid == Guid.Empty)
                    throw new InvalidOperationException("Invalid AD objectGUID.");

                if (!adGuids.Add(guid))
                    throw new InvalidOperationException("Duplicate AD objectGUID.");

                var adNT = ReadAdProperty(adUser, "sAMAccountName");
                var adFullName = ReadAdProperty(adUser, "displayName");
                var adEmail = ReadAdProperty(adUser, "mail");
                var adJobTitle = ReadAdProperty(adUser, "title");
                var adCompany = ReadAdProperty(adUser, "company");
                var adManager = ReadAdProperty(adUser, "manager");

                if (!sqlDictionary.TryGetValue(guid, out var sqlUser))
                {
                    added.Add(new
                    {
                        ObjectGuid = guid,
                        NT = adNT,
                        FullName = adFullName
                    });

                    continue;
                }

                var changes = new Dictionary<string, object>();

                if (!Same(sqlUser.FullName, adFullName))
                    changes["FullName"] = new { Old = sqlUser.FullName, New = adFullName };

                if (!Same(sqlUser.NT, adNT))
                    changes["NT"] = new { Old = sqlUser.NT, New = adNT };

                if (!Same(sqlUser.Email, adEmail))
                    changes["Email"] = new { Old = sqlUser.Email, New = adEmail };

                if (!Same(sqlUser.JobTitle, adJobTitle))
                    changes["JobTitle"] = new { Old = sqlUser.JobTitle, New = adJobTitle };

                if (!Same(sqlUser.CompanyName, adCompany))
                    changes["CompanyName"] = new { Old = sqlUser.CompanyName, New = adCompany };

                if (!Same(sqlUser.ManagerDistinguishedName, adManager))
                    changes["Manager"] = new { Old = sqlUser.ManagerDistinguishedName, New = adManager };

                if (changes.Count > 0)
                {
                    updated.Add(new
                    {
                        ObjectGuid = guid,
                        AccountName = adNT,
                        Changes = changes
                    });
                }
            }

            // Missing from this department, not necessarily deleted from AD
            var missing = sqlUsers
                .Where(x => !adGuids.Contains(x.ActiveDirectoryObjectGuid))
                .Select(x => new
                {
                    ObjectGuid = x.ActiveDirectoryObjectGuid,
                    x.NT,
                    x.FullName
                })
                .ToList();

            return Result.Success<object>(new
            {
                Department = department,
                AdCount = adGuids.Count,
                SqlCount = sqlUsers.Count,

                AddedCount = added.Count,
                UpdatedCount = updated.Count,
                MissingFromDepartmentCount = missing.Count,

                Added = added,
                Updated = updated,
                MissingFromDepartment = missing
            });
        }

        private static bool Same(string a, string b)
        {
            return string.Equals(
                a?.Trim(),
                b?.Trim(),
                StringComparison.Ordinal);
        }




        //public async Task<Result<DirectoryUserItemDto>> SearchUsersByEmailAsync(
        //    string email,
        //    string department = null)
        //{
        //    if (string.IsNullOrWhiteSpace(email))
        //    {
        //        return Result.Failure<DirectoryUserItemDto>(
        //            new Error("Email.Invalid", "Email is required."));
        //    }

        //    IQueryable<DirectoryUser> query =
        //        BuildSearchQuery(email, "email", department);

        //    DirectoryUserItemDto user = await query
        //        .Select(UserItemProjection)
        //        .FirstOrDefaultAsync();

        //    if (user == null)
        //    {
        //        return Result.Failure<DirectoryUserItemDto>(
        //            new Error("User.NotFound", "User not found."));
        //    }

        //    await PopulateUserRelationsAsync(
        //        new List<DirectoryUserItemDto> { user });

        //    return Result.Success(user);
        //}




        public async Task<Result<PagedResultDto<DirectoryUserItemDto>>> SearchUsersAsync(
            string search,
            string searchField = "all",
            string department = null,
            int page = 1,
            int pageSize = 20)
        {
            if (string.IsNullOrWhiteSpace(search))
            {
                return Result.Failure<PagedResultDto<DirectoryUserItemDto>>(
                    new Error("Search.Invalid", "Search is required."));
            }

            IQueryable<DirectoryUser> query =
                BuildSearchQuery(search, searchField, department);

            PagedResultDto<DirectoryUserItemDto> result =
                await GetPagedUsersAsync(query, page, pageSize);

            return Result.Success(result);
        }










        public async Task<Result<List<DirectoryUserItemDto>>> GetUserAncestorsAsync(long userId)
        {
            if (userId <= 0)
            {
                return Result.Failure<List<DirectoryUserItemDto>>(
                    new Error("User.Invalid", "Invalid UserId."));
            }

            const string sql = @"
        ;WITH ManagerChain AS
        (
            -- Selected employee
            SELECT
                u.UserId,
                u.FullName,
                u.NT ,
                u.Email,
                u.JobTitle,
                u.Departmen,
                u.CompanyName,
                u.ManagerUserId,

                0 AS HierarchyLevel,

                CAST(
                    '|' + CAST(u.UserId AS VARCHAR(20)) + '|'
                    AS VARCHAR(MAX)
                ) AS VisitedIds

            FROM dbo.DirectoryUsers u

            WHERE u.UserId = @p0
              AND u.IsDeleted = 0

            UNION ALL

            -- Manager, manager's manager, and so on
            SELECT
                manager.UserId,
                manager.FullName,
                manager.NT,
                manager.Email,
                manager.JobTitle,
                manager.Department,
                manager.CompanyName,
                manager.ManagerUserId,

                employee.HierarchyLevel + 1,

                CAST(
                    employee.VisitedIds +
                    CAST(manager.UserId AS VARCHAR(20)) + '|'
                    AS VARCHAR(MAX)
                )

            FROM dbo.DirectoryUsers manager

            INNER JOIN ManagerChain employee
                ON manager.UserId = employee.ManagerUserId

            WHERE manager.IsDeleted = 0
              AND employee.HierarchyLevel < 99

              -- Prevent circular manager references
              AND CHARINDEX(
                    '|' + CAST(manager.UserId AS VARCHAR(20)) + '|',
                    employee.VisitedIds
                  ) = 0
        )

        SELECT
            UserId,
            FullName,
            NT,
            Email,
            JobTitle,
            Department,
            CompanyName,
            ManagerUserId,

            HierarchyLevel,

            CAST(NULL AS NVARCHAR(256)) AS ManagerFullName,
            CAST(0 AS INT) AS DirectReportsCount

        FROM ManagerChain

        ORDER BY HierarchyLevel DESC

        OPTION (MAXRECURSION 100);
    ";

            List<DirectoryUserItemDto> users =
                await _activeDirectoryDB.Database
                    .SqlQuery<DirectoryUserItemDto>(sql, userId)
                    .ToListAsync();

            if (users.Count == 0)
            {
                return Result.Failure<List<DirectoryUserItemDto>>(
                    new Error("User.NotFound", "User not found."));
            }

            await PopulateUserRelationsAsync(users);

            // Ordered: CEO -> Manager -> Employee
            return Result.Success(users);
        }




        public async Task<Result<PagedResultDto<DirectoryUserItemDto>>> GetDirectReportsAsync(
                long managerUserId,
                int page = 1,
                int pageSize = 20,
                string department = null)
        {
            if (managerUserId <= 0)
            {
                return Result.Failure<PagedResultDto<DirectoryUserItemDto>>(
                    new Error(
                        "Manager.Invalid",
                        "Invalid ManagerUserId."));
            }

            bool managerExists = await _activeDirectoryDB.DirectoryUsers
                .AsNoTracking()
                .AnyAsync(x =>
                    x.UserId == managerUserId &&
                    !x.IsDeleted);

            if (!managerExists)
            {
                return Result.Failure<PagedResultDto<DirectoryUserItemDto>>(
                    new Error(
                        "Manager.NotFound",
                        "Manager not found."));
            }

            IQueryable<DirectoryUser> query =
                _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x =>
                        !x.IsDeleted &&
                        x.ManagerUserId == managerUserId);

            if (!string.IsNullOrWhiteSpace(department))
            {
                department = NormalizeDepartmentName(department);

                query = query.Where(x =>
                    x.Department == department);
            }

            PagedResultDto<DirectoryUserItemDto> result =
                await GetPagedUsersAsync(
                    query,
                    page,
                    pageSize,
                    department);

            return Result.Success(result);
        }





        public async Task<Result<PagedResultDto<DirectoryUserItemDto>>> GetDirectoryUsersAsync(
            string search = null,
            string department = null,
            string subDepartment = null,
            bool? isEnabled = null,
            int page = 1,
            int pageSize = 50,
            string searchField = "all")
        {
            IQueryable<DirectoryUser> query =
                _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

            if (!string.IsNullOrWhiteSpace(department))
            {
                department = NormalizeDepartmentName(department);

                query = query.Where(x =>
                    x.Department == department);
            }

            if (!string.IsNullOrWhiteSpace(subDepartment))
            {
                subDepartment = subDepartment.Trim();

                query = query.Where(x =>
                    x.SubDepartment == subDepartment);
            }

            if (isEnabled.HasValue)
            {
                query = query.Where(x =>
                    x.IsEnabled == isEnabled.Value);
            }

            if (!string.IsNullOrWhiteSpace(search))
            {
                search = search.Trim();

                searchField = (searchField ?? "all")
                    .Trim()
                    .ToLowerInvariant();

                switch (searchField)
                {
                    case "displayname":
                        query = query.Where(x =>
                            x.DisplayName.Contains(search));
                        break;

                    case "fullname":
                        query = query.Where(x =>
                            x.FullName.Contains(search));
                        break;

                    case "nt":
                        query = query.Where(x =>
                            x.NT.StartsWith(search));
                        break;

                    case "email":
                        query = query.Where(x =>
                            x.Email.StartsWith(search));
                        break;

                    case "staffid":
                        query = query.Where(x =>
                            x.StaffId.StartsWith(search));
                        break;

                    case "department":
                        query = query.Where(x =>
                            x.Department.Contains(search));
                        break;

                    case "jobtitle":
                        query = query.Where(x =>
                            x.JobTitle.Contains(search));
                        break;

                    case "all":
                        query = query.Where(x =>
                            x.DisplayName.Contains(search) ||
                            x.FullName.Contains(search) ||
                            x.NT.Contains(search) ||
                            x.Email.Contains(search) ||
                            x.StaffId.Contains(search));
                        break;

                    default:
                        return Result.Failure<PagedResultDto<DirectoryUserItemDto>>(
                            new Error(
                                "Search.InvalidField",
                                "Allowed: all, displayname, fullname, nt, email, " +
                                "staffid, department, jobtitle."));
                }
            }

            var result = await GetPagedUsersAsync(
                query, page, pageSize, department);

            return Result.Success(result);
        }






        public async Task<Result<PagedResultDto<DirectoryUserItemDto>>> GetRootUsersAsync(
                string department = null,
                int page = 1,
                int pageSize = 20)
        {
            IQueryable<DirectoryUser> query =
                _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

            if (!string.IsNullOrWhiteSpace(department))
            {
                department = NormalizeDepartmentName(department);

                // Root within the selected department.
                query = query.Where(x =>
                    x.Department == department &&
                    (
                        !x.ManagerUserId.HasValue ||
                        !_activeDirectoryDB.DirectoryUsers.Any(manager =>
                            manager.UserId == x.ManagerUserId.Value &&
                            !manager.IsDeleted &&
                            manager.Department == department)
                    ));
            }
            else
            {
                // Root across the entire organization.
                query = query.Where(x =>
                    !x.ManagerUserId.HasValue ||
                    !_activeDirectoryDB.DirectoryUsers.Any(manager =>
                        manager.UserId == x.ManagerUserId.Value &&
                        !manager.IsDeleted)
                );
            }

            PagedResultDto<DirectoryUserItemDto> result =
                await GetPagedUsersAsync(
                    query,
                    page,
                    pageSize,
                    department);

            return Result.Success(result);
        }





        public async Task<Result<List<DirectoryDepartmentDto>>> GetDepartmentsAsync()
        {
            // Grouping is executed in SQL first.
            var rawDepartments = await _activeDirectoryDB.DirectoryUsers
                .AsNoTracking()
                .Where(x =>
                    !x.IsDeleted &&
                    x.Department != null &&
                    x.Department != "")
                .GroupBy(x => x.Department)
                .Select(g => new
                {
                    Name = g.Key,
                    Count = g.Count()
                })
                .ToListAsync();

            // Merge case and whitespace variations in memory.
            List<DirectoryDepartmentDto> departments = rawDepartments
                .Where(x => !string.IsNullOrWhiteSpace(x.Name))
                .GroupBy(
                    x => x.Name.Trim(),
                    StringComparer.OrdinalIgnoreCase)
                .Select(group =>
                {
                    // Prefer the most common original spelling.
                    var displayName = group
                        .OrderByDescending(x => x.Count)
                        .ThenBy(x => x.Name)
                        .First()
                        .Name
                        .Trim();

                    return new DirectoryDepartmentDto
                    {
                        Name = displayName,
                        EmployeesCount = group.Sum(x => x.Count)
                    };
                })
                .OrderBy(x => x.Name)
                .ToList();

            return Result.Success(departments);
        }




        public async Task<Result<DirectoryUserDetailsDto>> GetUserByIdAsync(long userId)
        {
            if (userId <= 0)
            {
                return Result.Failure<DirectoryUserDetailsDto>(
                    new Error("User.Invalid", "Invalid UserId."));
            }

            DirectoryUserDetailsDto user =
                await _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x =>
                        x.UserId == userId &&
                        !x.IsDeleted)
                    .Select(x => new DirectoryUserDetailsDto
                    {
                        UserId = x.UserId,
                        ActiveDirectoryObjectGuid =
                            x.ActiveDirectoryObjectGuid,

                        NT = x.NT,
                        UserPrincipalName = x.UserPrincipalName,

                        FullName = x.FullName,
                        FirstName = x.FirstName,
                        LastName = x.LastName,

                        Email = x.Email,
                        MobileNumber = x.MobileNumber,

                        Department = x.Department,
                        JobTitle = x.JobTitle,
                        Company = x.CompanyName,
                        EmployeeCode = x.StaffId,
                        OfficeName = x.Office,
                        CostCenterCode = x.CostCenter,

                        Description = x.Description,
                        CountryName = x.CountryName,
                        HiringDate = x.HiringDate,

                        ManagerUserId = x.ManagerUserId,
                        ManagerDistinguishedName =
                            x.ManagerDistinguishedName,

                        ReportTo = x.ReportTo,
                        GweInternalUserRaw = x.IsInternal,

                        IsEnabled = x.IsEnabled,

                        CreatedInAdAtUtc = x.CreatedInAdAtUtc,
                        ModifiedInAdAtUtc = x.ModifiedInAdAtUtc
                    })
                    .FirstOrDefaultAsync();

            if (user == null)
            {
                return Result.Failure<DirectoryUserDetailsDto>(
                    new Error("User.NotFound", "User not found."));
            }

            await PopulateUserRelationsAsync(
                new List<DirectoryUserItemDto> { user });


            user.DistributionLists =
                await _activeDirectoryDB.DirectoryGroups
                    .AsNoTracking()
                    .Where(g =>
                        !g.IsDeleted &&
                        g.DLEmail != null &&
                        g.DLEmail != "" &&
                        g.DirectoryUsers.Any(u => u.UserId == userId))
                    .OrderBy(g => g.DLDisplayName)
                    .Select(g => new DistributionListDto
                    {
                        Name = g.DLDisplayName ?? g.DLName,
                        Email = g.DLEmail
                    })
                    .ToListAsync();



            return Result.Success(user);
        }




        public async Task<Result<DirectoryUpsertSummaryDto>> UpsertDirectoryUsersAsync(
            JArray adUsers)
        {
            if (adUsers == null || adUsers.Count == 0 || adUsers.Count > 100)
            {
                return Result.Failure<DirectoryUpsertSummaryDto>(
                    new Error(
                        "Upsert.InvalidBatch",
                        "Send between 1 and 100 users."));
            }

            // Validate everything before changing SQL.
            var incoming = new Dictionary<Guid, JObject>();

            foreach (JToken token in adUsers)
            {
                var adUser = token as JObject;

                if (adUser == null)
                {
                    return Result.Failure<DirectoryUpsertSummaryDto>(
                        new Error("Upsert.InvalidUser", "Invalid AD user."));
                }

                string guidText;

                if (!TryReadAttribute(adUser, "objectGUID", out guidText))
                {
                    return Result.Failure<DirectoryUpsertSummaryDto>(
                        new Error("Upsert.MissingGuid", "objectGUID is required."));
                }

                Guid guid;

                if (!Guid.TryParse(guidText, out guid) || guid == Guid.Empty)
                {
                    return Result.Failure<DirectoryUpsertSummaryDto>(
                        new Error("Upsert.InvalidGuid", "Invalid objectGUID."));
                }

                if (incoming.ContainsKey(guid))
                {
                    return Result.Failure<DirectoryUpsertSummaryDto>(
                        new Error("Upsert.DuplicateGuid", "Duplicate objectGUID in request."));
                }

                incoming.Add(guid, adUser);
            }

            try
            {
                using (var transaction = _activeDirectoryDB.Database.BeginTransaction())
                {
                    List<Guid> guids = incoming.Keys.ToList();

                    // Tracked entities: EF will detect our changes.
                    var existingUsers = await _activeDirectoryDB.DirectoryUsers
                        .Where(x => guids.Contains(x.ActiveDirectoryObjectGuid))
                        .ToListAsync();

                    var existingByGuid = existingUsers.ToDictionary(
                        x => x.ActiveDirectoryObjectGuid);

                    var insertedGuids = new HashSet<Guid>();
                    var updatedGuids = new HashSet<Guid>();
                    var affectedUsers = new List<DirectoryUser>();

                    foreach (var pair in incoming)
                    {
                        Guid guid = pair.Key;
                        JObject adUser = pair.Value;

                        DirectoryUser user;
                        bool isNew = !existingByGuid.TryGetValue(guid, out user);

                        if (isNew)
                        {
                            user = new DirectoryUser
                            {
                                ActiveDirectoryObjectGuid = guid,
                                IsDeleted = false
                            };
                        }

                        bool changed = ApplyDirectoryUserFields(user, adUser);

                        if (user.IsDeleted)
                        {
                            user.IsDeleted = false;
                            changed = true;
                        }

                        if (isNew)
                        {
                            if (string.IsNullOrWhiteSpace(user.NT))
                            {
                                return Result.Failure<DirectoryUpsertSummaryDto>(
                                    new Error(
                                        "Upsert.MissingAccount",
                                        "sAMAccountName is required for new users."));
                            }

                            _activeDirectoryDB.DirectoryUsers.Add(user);

                            insertedGuids.Add(guid);
                        }
                        else if (changed)
                        {
                            updatedGuids.Add(guid);
                        }

                        affectedUsers.Add(user);
                    }

                    // Save new users first to generate identity UserIds.
                    await _activeDirectoryDB.SaveChangesAsync();

                    // Resolve managers for the affected users.
                    var managerDns = affectedUsers
                        .Where(x => !string.IsNullOrWhiteSpace(
                            x.ManagerDistinguishedName))
                        .Select(x => x.ManagerDistinguishedName.Trim())
                        .Distinct(StringComparer.OrdinalIgnoreCase)
                        .ToList();

                    var managers = managerDns.Count == 0
                        ? new List<DirectoryUser>()
                        : await _activeDirectoryDB.DirectoryUsers
                            .AsNoTracking()
                            .Where(x =>
                                !x.IsDeleted &&
                                managerDns.Contains(x.DistinguishedName))
                            .ToListAsync();

                    var managersByDn = new Dictionary<string, long>(
                        StringComparer.OrdinalIgnoreCase);

                    foreach (var manager in managers)
                    {
                        if (managersByDn.ContainsKey(manager.DistinguishedName))
                        {
                            throw new InvalidOperationException(
                                "Duplicate manager DistinguishedName in SQL.");
                        }

                        managersByDn.Add(
                            manager.DistinguishedName,
                            manager.UserId);
                    }

                    int managersLinked = 0;

                    foreach (DirectoryUser user in affectedUsers)
                    {
                        long? managerUserId = null;

                        if (!string.IsNullOrWhiteSpace(
                            user.ManagerDistinguishedName))
                        {
                            long resolvedId;

                            if (managersByDn.TryGetValue(
                                user.ManagerDistinguishedName.Trim(),
                                out resolvedId))
                            {
                                if (resolvedId == user.UserId)
                                {
                                    throw new InvalidOperationException(
                                        "A user cannot be their own manager.");
                                }

                                managerUserId = resolvedId;
                            }
                        }

                        if (user.ManagerUserId != managerUserId)
                        {
                            user.ManagerUserId = managerUserId;

                            if (!insertedGuids.Contains(
                                user.ActiveDirectoryObjectGuid))
                            {
                                updatedGuids.Add(
                                    user.ActiveDirectoryObjectGuid);
                            }
                        }

                        if (user.ManagerUserId.HasValue)
                            managersLinked++;
                    }

                    await _activeDirectoryDB.SaveChangesAsync();

                    // Commit exactly once.
                    transaction.Commit();

                    return Result.Success(new DirectoryUpsertSummaryDto
                    {
                        ReceivedCount = incoming.Count,
                        InsertedCount = insertedGuids.Count,
                        UpdatedCount = updatedGuids.Count,
                        UnchangedCount =
                            incoming.Count -
                            insertedGuids.Count -
                            updatedGuids.Count,
                        ManagersLinkedCount = managersLinked
                    });
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.ToString());

                return Result.Failure<DirectoryUpsertSummaryDto>(
                    new Error(
                        "Upsert.Failed",
                        "Could not save directory users. Check server logs."));
            }
        }




        public async Task<Result<List<DirectoryUserItemDto>>> GetHierarchyChildrenAsync(long userId)
        {
            if (userId <= 0)
                return Result.Failure<List<DirectoryUserItemDto>>(
                    new Error("User.Invalid", "Invalid UserId."));

            var users = await _activeDirectoryDB.DirectoryUsers
                .AsNoTracking()
                .Where(x =>
                    !x.IsDeleted &&
                    x.ManagerUserId == userId)
                .OrderBy(x => x.DisplayName)
                .Select(UserItemProjection)
                .ToListAsync();

            await PopulateUserRelationsAsync(users);

            return Result.Success(users);
        }





        private IQueryable<DirectoryUser> BuildSearchQuery(
            string search,
            string searchField = "all",
            string department = null)
        {
            IQueryable<DirectoryUser> query =
                _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

            if (!string.IsNullOrWhiteSpace(department))
            {
                department = department.Trim();

                query = query.Where(x =>
                    x.Department == department);
            }

            if (string.IsNullOrWhiteSpace(search))
                return query;

            search = search.Trim();

            switch ((searchField ?? "all").Trim().ToLowerInvariant())
            {
                case "fullname":
                    query = query.Where(x =>
                        x.FullName.StartsWith(search));
                    break;

                case "nt":
                    query = query.Where(x =>
                        x.NT.StartsWith(search));
                    break;

                case "email":
                    query = query.Where(x =>
                        x.Email == search);
                    break;

                case "mobile":
                    query = query.Where(x =>
                        x.MobileNumber.StartsWith(search));
                    break;

                case "staffid":
                    query = query.Where(x =>
                        x.StaffId == search);
                    break;

                case "all":
                    query = query.Where(x =>
                        x.FullName.StartsWith(search) ||
                        x.NT.StartsWith(search) ||
                        x.Email.StartsWith(search) ||
                        x.MobileNumber.StartsWith(search) ||
                        x.StaffId.StartsWith(search));
                    break;

                default:
                    throw new ArgumentException(
                        "Invalid search field.", nameof(searchField));
            }

            return query;
        }





        private static readonly Expression<Func<DirectoryUser, DirectoryUserItemDto>>
            UserItemProjection = user => new DirectoryUserItemDto
            {
                UserId = user.UserId,

                FullName = user.FullName,
                NT = user.NT,
                Email = user.Email,

                JobTitle = user.JobTitle,
                Department = user.Department,
                Company = user.CompanyName,

                ManagerUserId = user.ManagerUserId,
                CostCenter = user.CostCenter,
                DisplyName = user.DisplayName,
                Gender = user.Gender,
                HiringDate = user.HiringDate,
                HoDNT = user.HoDNT,
                ReportTo = user.ReportTo,
                Office = user.Office,
                StaffId = user.StaffId,
                SapId = user.SapId,
                SubDepartment = user.SubDepartment,
                IsInternal = user.IsInternal,
                IsEnabled = user.IsEnabled,
                MobileNumber = user.MobileNumber,
                MangerNT = user.ManagerNT,


            };


        // Executes pagination directly in SQL Server.

        private async Task<PagedResultDto<DirectoryUserItemDto>> GetPagedUsersAsync(
            IQueryable<DirectoryUser> query,
            int page,
            int pageSize,
            string department = null)
        {
            page = Math.Max(1, Math.Min(page, 100000));
            pageSize = Math.Max(1, Math.Min(pageSize, 100));

            int totalCount = await query.CountAsync();

            List<DirectoryUserItemDto> items = await query
                .OrderBy(x => x.FullName)
                .ThenBy(x => x.UserId)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(UserItemProjection)
                .ToListAsync();

            if (items.Count == 0)
            {
                return new PagedResultDto<DirectoryUserItemDto>
                {
                    Items = items,
                    TotalCount = totalCount,
                    Page = page,
                    PageSize = pageSize
                };
            }

            // Populate manager names and existing user relations.
            await PopulateUserRelationsAsync(items);

            // Without a department, preserve the existing company-wide counts.
            if (!string.IsNullOrWhiteSpace(department))
            {
                department = NormalizeDepartmentName(department);

                List<long> userIds = items
                    .Select(x => x.UserId)
                    .ToList();

                // Get direct-report counts ONLY inside the selected department.
                var counts = await _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x =>
                        !x.IsDeleted &&
                        x.ManagerUserId.HasValue &&
                        userIds.Contains(x.ManagerUserId.Value) &&
                        x.Department == department)
                    .GroupBy(x => x.ManagerUserId.Value)
                    .Select(g => new
                    {
                        ManagerUserId = g.Key,
                        Count = g.Count()
                    })
                    .ToListAsync();

                var countsByManager = counts.ToDictionary(
                    x => x.ManagerUserId,
                    x => x.Count);

                foreach (DirectoryUserItemDto item in items)
                {
                    int count;

                    item.DirectReportsCount =
                        countsByManager.TryGetValue(item.UserId, out count)
                            ? count
                            : 0;
                }
            }

            return new PagedResultDto<DirectoryUserItemDto>
            {
                Items = items,
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize
            };
        }


        // Populates manager names and direct-report counts
        // without loading the entire employee hierarchy.
        private async Task PopulateUserRelationsAsync(
            List<DirectoryUserItemDto> users)
        {
            if (users == null || users.Count == 0)
                return;

            List<long> userIds = users
                .Select(x => x.UserId)
                .Distinct()
                .ToList();

            List<long> managerIds = users
                .Where(x => x.ManagerUserId.HasValue)
                .Select(x => x.ManagerUserId.Value)
                .Distinct()
                .ToList();

            // Get manager names in a single query.
            var managerNames = new Dictionary<long, string>();

            if (managerIds.Count > 0)
            {
                var managers = await _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x =>
                        !x.IsDeleted &&
                        managerIds.Contains(x.UserId))
                    .Select(x => new
                    {
                        x.UserId,
                        x.FullName
                    })
                    .ToListAsync();

                managerNames = managers.ToDictionary(
                    x => x.UserId,
                    x => x.FullName);
            }

            // Get the number of direct reports per user.
            var reportCounts = await _activeDirectoryDB.DirectoryUsers
                .AsNoTracking()
                .Where(x =>
                    !x.IsDeleted &&
                    x.ManagerUserId.HasValue &&
                    userIds.Contains(x.ManagerUserId.Value))
                .GroupBy(x => x.ManagerUserId.Value)
                .Select(g => new
                {
                    ManagerId = g.Key,
                    Count = g.Count()
                })
                .ToListAsync();

            var counts = reportCounts.ToDictionary(
                x => x.ManagerId,
                x => x.Count);

            foreach (DirectoryUserItemDto user in users)
            {
                string managerName;

                if (user.ManagerUserId.HasValue &&
                    managerNames.TryGetValue(
                        user.ManagerUserId.Value,
                        out managerName))
                {
                    user.ManagerFullName = managerName;
                }

                int count;

                user.DirectReportsCount =
                    counts.TryGetValue(user.UserId, out count)
                        ? count
                        : 0;
            }
        }



        private static bool HasManagerCycle(
            DirectoryUserHierarchyNode user,
            Dictionary<long, DirectoryUserHierarchyNode> users)
        {
            HashSet<long> visited = new HashSet<long>();

            DirectoryUserHierarchyNode current = user;

            while (current != null)
            {
                if (!visited.Add(current.UserId))
                    return true;

                DirectoryUserHierarchyNode manager;

                if (!current.ManagerUserId.HasValue ||
                    !users.TryGetValue(current.ManagerUserId.Value, out manager))
                {
                    return false;
                }

                current = manager;
            }

            return false;
        }




        private static bool TryReadAttribute(
            JObject adUser,
            string attributeName,
            out string value)
        {
            value = null;

            JToken token = adUser.GetValue(
                attributeName,
                StringComparison.OrdinalIgnoreCase);

            if (token == null)
                return false;

            if (token.Type == JTokenType.Null)
                return true;

            if (token.Type == JTokenType.Array)
            {
                var array = (JArray)token;

                if (array.Count == 0)
                    return true;

                if (array.Count != 1)
                {
                    throw new InvalidOperationException(
                        attributeName + " must contain one value.");
                }

                token = array[0];
            }

            value = token.Type == JTokenType.Null
                ? null
                : token.ToString().Trim();

            return true;
        }


        private static bool SetAttribute(
            JObject adUser,
            string attributeName,
            string currentValue,
            Action<string> assign)
        {
            string newValue;

            if (!TryReadAttribute(
                adUser,
                attributeName,
                out newValue))
            {
                return false;
            }

            if (string.Equals(
                currentValue,
                newValue,
                StringComparison.Ordinal))
            {
                return false;
            }

            assign(newValue);
            return true;
        }


        private static bool ApplyDirectoryUserFields(
            DirectoryUser user,
            JObject adUser)
        {
            bool changed = false;

            changed |= SetAttribute(
                adUser, "sAMAccountName",
                user.NT,
                value => user.NT = value);

            changed |= SetAttribute(
                adUser, "displayName",
                user.DisplayName,
                value => user.DisplayName = value);

            changed |= SetAttribute(
                adUser, "fullName",
                user.FullName,
                value => user.FullName = value);

            changed |= SetAttribute(
                adUser, "distinguishedName",
                user.DistinguishedName,
                value => user.DistinguishedName = value);

            changed |= SetAttribute(
                adUser, "givenName",
                user.FirstName,
                value => user.FirstName = value);

            changed |= SetAttribute(
                adUser, "sn",
                user.LastName,
                value => user.LastName = value);

            changed |= SetAttribute(
                adUser, "mail",
                user.Email,
                value => user.Email = value);

            changed |= SetAttribute(
                adUser, "mobile",
                user.MobileNumber,
                value => user.MobileNumber = value);


            string rawDepartment;

            if (TryReadAttribute(adUser, "department", out rawDepartment))
            {
                string normalizedDepartment =
                    NormalizeDepartmentName(rawDepartment);

                if (!string.Equals(
                    user.Department,
                    normalizedDepartment,
                    StringComparison.Ordinal))
                {
                    user.Department = normalizedDepartment;
                    changed = true;
                }
            }


            changed |= SetAttribute(
                adUser, "title",
                user.JobTitle,
                value => user.JobTitle = value);

            changed |= SetAttribute(
                adUser, "company",
                user.CompanyName,
                value => user.CompanyName = value);

            changed |= SetAttribute(
                adUser, "employeeID",
                user.StaffId,
                value => user.StaffId = value);

            changed |= SetAttribute(
                adUser, "physicalDeliveryOfficeName",
                user.Office,
                value => user.Office = value);

            changed |= SetAttribute(
                adUser, "description",
                user.Description,
                value => user.Description = value);

            changed |= SetAttribute(
                adUser, "manager",
                user.ManagerDistinguishedName,
                value => user.ManagerDistinguishedName = value);


            changed |= SetAttribute(
                adUser, "costCenter",
                user.CostCenter,
                value => user.CostCenter = value);

            changed |= SetAttribute(
                adUser, "gweReportingTo",
                user.ReportTo,
                value => user.ReportTo = value);

            changed |= SetAttribute(
                adUser, "gweinternalUser",
                user.IsInternal,
                value => user.IsInternal = value);

            changed |= SetAttribute(
                adUser, "extensionAttribute6",
                user.SubDepartment,
                value => user.SubDepartment = value);

            changed |= SetAttribute(
                adUser, "extensionAttribute7",
                user.ManagerNT,
                value => user.ManagerNT = value);

            changed |= SetAttribute(
                adUser, "VF-extensionAttribute04",
                user.HoDNT,
                value => user.HoDNT = value);

            changed |= SetAttribute(
                adUser, "hiringDate",
                user.HiringDate,
                value => user.HiringDate = value);

            // Gender requires normalization.
            string rawGender;
            if (TryReadAttribute(
                adUser, "extensionAttribute8", out rawGender))
            {
                string gender = NormalizeGender(rawGender);

                if (user.Gender != gender)
                {
                    user.Gender = gender;
                    changed = true;
                }
            }


            return changed;
        }


        //=====



        public async Task<Result<SoftDeleteSyncDto>> SyncDeletedObjectsAsync(
            bool dryRun = true)
        {
            try
            {
                Log.Information(
                    "[SOFT DELETE][START] DryRun={DryRun}", dryRun);

                // 1. Get active GUIDs from SQL.

                var groupGuids = await _activeDirectoryDB.DirectoryGroups
                   .AsNoTracking()
                   .Where(x => !x.IsDeleted)
                   .Select(x => x.DLObjectGuid)
                   .ToListAsync();


                var userGuids = await _activeDirectoryDB.Database
                .SqlQuery<Guid>(@"
                    SELECT ActiveDirectoryObjectGuid
                    FROM dbo.DirectoryUsers WITH (INDEX(0))
                    WHERE IsDeleted = 0
                ")
                .ToListAsync();


                if (userGuids.Contains(Guid.Empty) ||
                    groupGuids.Contains(Guid.Empty))
                {
                    throw new InvalidOperationException(
                        "SQL contains an invalid objectGUID.");
                }

                Log.Information(
                    "[SOFT DELETE][SQL LOADED] Users={Users}, Groups={Groups}",
                    userGuids.Count, groupGuids.Count);

                // 2. Check which GUIDs still exist in AD.
                var existing = await _activeDirectoryService
                    .GetExistingAdGuidsAsync(userGuids, groupGuids);

                if (existing == null ||
                    existing.UserGuids == null ||
                    existing.GroupGuids == null)
                {
                    throw new InvalidOperationException(
                        "Invalid AD validation response.");
                }

                // Fail safely if AD unexpectedly finds nothing.
                if ((userGuids.Count > 0 && existing.UserGuids.Count == 0) ||
                    (groupGuids.Count > 0 && existing.GroupGuids.Count == 0))
                {
                    throw new InvalidOperationException(
                        "AD returned no matching objects. " +
                        "Soft Delete cancelled.");
                }

                // 3. Find GUIDs missing from AD.
                var missingUsers = userGuids
                    .Except(existing.UserGuids)
                    .ToList();

                var missingGroups = groupGuids
                    .Except(existing.GroupGuids)
                    .ToList();

                var summary = new SoftDeleteSyncDto
                {
                    DryRun = dryRun,
                    UsersChecked = userGuids.Count,
                    GroupsChecked = groupGuids.Count,
                    MissingUserGuids = missingUsers,
                    MissingGroupGuids = missingGroups
                };

                Log.Information(
                    "[SOFT DELETE][COMPARED] MissingUsers={Users}, MissingGroups={Groups}",
                    missingUsers.Count, missingGroups.Count);

                // 4. Preview only.
                if (dryRun)
                    return Result.Success(summary);

                // Safety: stop unusually large delete operations.
                if ((userGuids.Count > 0 &&
                     missingUsers.Count > userGuids.Count * 0.10) ||
                    (groupGuids.Count > 0 &&
                     missingGroups.Count > groupGuids.Count * 0.10))
                {
                    throw new InvalidOperationException(
                        "More than 10% of objects are missing. " +
                        "Review dry-run results before deletion.");
                }

                // 5. Mark missing objects as deleted.
                // Both tables are updated in one SQL transaction.
                using (var transaction =
                    _activeDirectoryDB.Database.BeginTransaction())
                {
                    const int batchSize = 200;

                    for (int i = 0; i < missingUsers.Count; i += batchSize)
                    {
                        var batch = missingUsers
                            .Skip(i).Take(batchSize).ToList();

                        var users = await _activeDirectoryDB.DirectoryUsers
                            .Where(x =>
                                !x.IsDeleted &&
                                batch.Contains(x.ActiveDirectoryObjectGuid))
                            .ToListAsync();

                        foreach (var user in users)
                        {
                            user.IsDeleted = true;
                            summary.SoftDeletedUsers++;
                        }

                        await _activeDirectoryDB.SaveChangesAsync();
                    }

                    for (int i = 0; i < missingGroups.Count; i += batchSize)
                    {
                        var batch = missingGroups
                            .Skip(i).Take(batchSize).ToList();

                        var groups = await _activeDirectoryDB.DirectoryGroups
                            .Where(x =>
                                !x.IsDeleted &&
                                batch.Contains(x.DLObjectGuid))
                            .ToListAsync();

                        foreach (var group in groups)
                        {
                            group.IsDeleted = true;
                            summary.SoftDeletedGroups++;
                        }

                        await _activeDirectoryDB.SaveChangesAsync();
                    }

                    transaction.Commit();
                }

                Log.Information(
                    "[SOFT DELETE][DONE] Users={Users}, Groups={Groups}",
                    summary.SoftDeletedUsers,
                    summary.SoftDeletedGroups);

                return Result.Success(summary);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "[SOFT DELETE][FAILED]");

                return Result.Failure<SoftDeleteSyncDto>(
                    new Error(
                        "AD.SoftDeleteFailed",
                        "Soft Delete Sync failed. Check server logs."));
            }
        }



        public async Task<Result<DirectorySyncSummaryDto>> SyncDirectoryChangesAsync()
        {
            const string syncName = "AD-Users";
            const int batchSize = 200;

            var report = new SyncEmailReport
            {
                SyncName = syncName,
                ItemName = "Users",
                Status = SyncEmailStatus.Started,
                StartedAtUtc = DateTime.UtcNow,
                Stage = "Starting directory Sync"
            };

            report.Details["Source"] = "Active Directory";
            report.Details["Destination"] = "DirectoryUsers";
            report.Details["Batch size"] = batchSize.ToString();
            report.Details["Checkpoint"] = "Not yet updated";

            bool checkpointCommitted = false;

            try
            {
                // EMAIL 1: STARTED
                await _syncEmailNotifier.TrySendAsync(report);

                _activeDirectoryDB.Database.CommandTimeout = 300;

                // STEP 1: Read last successful checkpoint.
                report.Stage = "Reading Sync checkpoint";

                DirectorySyncState previous =
                    await _activeDirectoryDB
                        .Set<DirectorySyncState>()
                        .AsNoTracking()
                        .FirstOrDefaultAsync(x => x.SyncName == syncName);

                bool initialSync =
                    previous == null ||
                    !previous.UsnWatermark.HasValue;

                long fromUsn = initialSync
                    ? 0L
                    : previous.UsnWatermark.Value;

                string dcName = initialSync
                    ? null
                    : previous.DomainControllerName;

                report.Details["Sync type"] =
                    initialSync ? "Initial" : "Incremental";

                report.Details["From USN"] = fromUsn.ToString();

                if (!initialSync &&
                    (string.IsNullOrWhiteSpace(dcName) ||
                     !previous.InvocationId.HasValue))
                {
                    throw new InvalidOperationException(
                        "Stored DC identity is incomplete.");
                }

                // STEP 2: Fetch changed users from AD.
                report.Stage = "Fetching changed users from Active Directory";

                AdChangedUsersResponseDto changes =
                    await GetChangesFromAdAsync(fromUsn, dcName);

                if (changes == null || changes.Users == null)
                {
                    throw new InvalidOperationException(
                        "Active Directory returned an invalid response.");
                }

                report.TotalItems = changes.Users.Count;
                report.TotalBatches =
                    (changes.Users.Count + batchSize - 1) / batchSize;

                report.Details["To USN"] = changes.ToUsn.ToString();
                report.Details["Domain Controller"] = changes.DomainControllerName;

                report.Details["Invocation ID"] = changes.InvocationId.ToString();

                Log.Information($"[SYNC] Total users received: {changes.Users.Count}");

                // Validate AD checkpoint information.
                report.Stage = "Validating Active Directory checkpoint";

                if (changes.FromUsn != fromUsn ||
                    changes.ToUsn < fromUsn ||
                    string.IsNullOrWhiteSpace(changes.DomainControllerName) ||
                    changes.InvocationId == Guid.Empty)
                {
                    throw new InvalidOperationException(
                        "Invalid AD checkpoint information.");
                }

                if (!initialSync && (!string.Equals(
                        previous.DomainControllerName,
                        changes.DomainControllerName,
                        StringComparison.OrdinalIgnoreCase) ||
                     previous.InvocationId.Value != changes.InvocationId))
                {
                    throw new InvalidOperationException(
                        "Domain Controller identity changed. " +
                        "A full rebaseline is required.");
                }

                if (initialSync && changes.Users.Count == 0)
                {
                    throw new InvalidOperationException(
                        "Initial AD snapshot is empty.");
                }

                // STEP 3: Validate GUIDs before writing.
                report.Stage = "Validating AD objectGUIDs";

                var knownGuids = new HashSet<Guid>();

                foreach (Dictionary<string, object> item in changes.Users)
                {
                    JObject user = JObject.FromObject(item);

                    Guid guid;

                    if (user == null ||
                        !TryGetAdGuid(user, out guid) ||
                        guid == Guid.Empty ||
                        !knownGuids.Add(guid))
                    {
                        throw new InvalidOperationException(
                            "Invalid or duplicate AD objectGUID.");
                    }
                }


                if (!initialSync)
                {
                    foreach (var item in changes.Users)
                    {
                        string GetValue(string key)
                        {
                            if (!item.TryGetValue(key, out var raw) || raw == null)
                                return "N/A";

                            if (raw is string[] values)
                                return values.FirstOrDefault() ?? "N/A";

                            return Convert.ToString(raw);
                        }

                        Log.Information(
                            "[AD USER CHANGED] Account={Account}, GUID={Guid}, " +
                            "USN={USN}, WhenChanged={WhenChanged}",
                            GetValue("sAMAccountName"),
                            GetValue("objectGUID"),
                            GetValue("uSNChanged"),
                            GetValue("whenChanged"));
                    }
                }


                // STEP 4: Upsert users in batches.
                int processed = 0;

                for (int i = 0; i < changes.Users.Count; i += batchSize)
                {
                    int batchNumber = (i / batchSize) + 1;

                    report.Stage =
                        $"Upserting AD users - Batch {batchNumber}/{report.TotalBatches}";

                    //JArray batch = new JArray(
                    //    changes.Users
                    //        .Skip(i)
                    //        .Take(batchSize));

                    JArray batch = JArray.FromObject(
                         changes.Users
                         .Skip(i)
                         .Take(batchSize)
                         .ToList());

                    int batchCount =
                        await UpsertAdUsersBatchAsync(batch);

                    processed += batchCount;

                    // Update email statistics after a successful batch.
                    report.ProcessedItems = processed;
                    report.CompletedBatches++;

                    Log.Information(
                        $"[SYNC] Processed {processed}/{changes.Users.Count}");
                }

                if (processed != changes.Users.Count)
                {
                    throw new InvalidOperationException(
                        "Processed users count does not match AD response count.");
                }

                if (initialSync && processed == 0)
                {
                    throw new InvalidOperationException(
                        "Initial sync completed without users.");
                }

                // STEP 5: Resolve managers.
                report.Stage = "Resolving manager relationships";

                Log.Information("[SYNC] Resolving managers started");

                await ResolveChangedManagersAsync();

                Log.Information("[SYNC] Resolving managers completed");

                report.Details["Manager resolution"] = "Completed";

                // STEP 6: Save checkpoint.
                report.Stage = "Saving Sync checkpoint";

                using (var transaction =
                    _activeDirectoryDB.Database.BeginTransaction())
                {
                    DirectorySyncState state =
                        await _activeDirectoryDB
                            .Set<DirectorySyncState>()
                            .FirstOrDefaultAsync(x => x.SyncName == syncName);

                    if (state == null)
                    {
                        state = new DirectorySyncState
                        {
                            SyncName = syncName
                        };

                        _activeDirectoryDB
                            .Set<DirectorySyncState>()
                            .Add(state);
                    }
                    else if (initialSync
                        ? state.UsnWatermark.HasValue
                        : state.UsnWatermark != fromUsn)
                    {
                        throw new InvalidOperationException(
                            "Checkpoint changed during synchronization.");
                    }

                    state.TrackingMethod = "USN";
                    state.UsnWatermark = changes.ToUsn;
                    state.DomainControllerName = changes.DomainControllerName;
                    state.InvocationId = changes.InvocationId;
                    state.LastSuccessfulSyncUtc = DateTime.UtcNow;

                    await _activeDirectoryDB.SaveChangesAsync();

                    transaction.Commit();
                    checkpointCommitted = true;
                }

                // EMAIL 2: SUCCESS
                report.Status = SyncEmailStatus.Succeeded;
                report.Stage = "Sync completed";
                report.Details["Checkpoint"] = "Committed successfully";

                report.Note =
                    "All received AD users were processed, manager " +
                    "relationships were resolved, and the USN " +
                    "checkpoint was successfully committed.";

                return Result.Success(new DirectorySyncSummaryDto
                {
                    IsInitialSync = initialSync,
                    ProcessedUsers = processed,
                    FromUsn = fromUsn,
                    ToUsn = changes.ToUsn,
                    DomainControllerName = changes.DomainControllerName
                });
            }
            catch (Exception ex)
            {
                // EMAIL 2: FAILURE
                report.Status = SyncEmailStatus.Failed;

                report.FailureReason =
                    ex.GetType().Name + ": " + ex.Message;

                report.Details["Checkpoint"] = checkpointCommitted
                    ? "Committed before a later failure"
                    : "Not advanced by this execution";

                Log.Error(ex, "[SYNC] AD Users Sync failed");

                return Result.Failure<DirectorySyncSummaryDto>(
                    new Error(
                        "Directory.SyncFailed",
                        "Directory sync failed. Check server logs."));
            }
            finally
            {
                // Always attempt final notification.
                await _syncEmailNotifier.TrySendAsync(report);
            }
        }



        private async Task<AdChangedUsersResponseDto> GetChangesFromAdAsync(
            long fromUsn,
            string domainControllerName)
        {
            var result =
                await _activeDirectoryService.GetChangedUsersAsync(
                    fromUsn,
                    domainControllerName);

            if (result == null || result.Users == null)
            {
                throw new InvalidOperationException(
                    "Invalid AD changes response.");
            }

            return result;
        }


        private async Task<int> UpsertAdUsersBatchAsync(JArray batch)
        {
            var adUsers = new Dictionary<Guid, JObject>();

            // 1. Validate batch.
            foreach (JToken token in batch)
            {
                JObject adUser = token as JObject;

                Guid guid;

                if (adUser == null ||
                    !TryGetAdGuid(adUser, out guid) ||
                    guid == Guid.Empty ||
                    adUsers.ContainsKey(guid))
                {
                    throw new InvalidOperationException(
                        "Invalid or duplicate AD objectGUID.");
                }

                adUsers.Add(guid, adUser);
            }

            List<Guid> guids = adUsers.Keys.ToList();

            // 2. Prepare additional attributes.
            var desiredAttributes =
                new Dictionary<Guid, List<DirectoryUserAttributeValue>>();

            foreach (var item in adUsers)
            {
                desiredAttributes[item.Key] =
                    BuildUserAttributes(item.Value);
            }

            // 3. Load existing users.
            List<DirectoryUser> existingUsers =
                await _activeDirectoryDB.DirectoryUsers
                    .Where(x => guids.Contains(x.ActiveDirectoryObjectGuid))
                    .ToListAsync();

            var usersByGuid = existingUsers.ToDictionary(
                x => x.ActiveDirectoryObjectGuid);

            List<long> existingIds = existingUsers
                .Select(x => x.UserId)
                .ToList();

            // 4. Load existing metadata and attributes.
            List<DirectoryUserAccountMetadata> existingMetadata =
                existingIds.Count == 0
                    ? new List<DirectoryUserAccountMetadata>()
                    : await _activeDirectoryDB
                        .Set<DirectoryUserAccountMetadata>()
                        .Where(x => existingIds.Contains(x.UserId))
                        .ToListAsync();

            var metadataById = existingMetadata.ToDictionary(
                x => x.UserId);

            List<DirectoryUserAttributeValue> existingAttributes =
                existingIds.Count == 0
                    ? new List<DirectoryUserAttributeValue>()
                    : await _activeDirectoryDB
                        .Set<DirectoryUserAttributeValue>()
                        .Where(x => existingIds.Contains(x.UserId))
                        .ToListAsync();

            var oldAttributesByKey =
                new Dictionary<
                    Tuple<long, string, int>,
                    DirectoryUserAttributeValue>();

            foreach (var attribute in existingAttributes)
            {
                if (!ExtraAttributeNames.Contains(attribute.AttributeName))
                    continue;

                oldAttributesByKey.Add(
                    GetAttributeKey(attribute),
                    attribute);
            }

            // 5. Apply user changes.
            var newUsers = new List<DirectoryUser>();

            foreach (var item in adUsers)
            {
                DirectoryUser user;

                if (!usersByGuid.TryGetValue(item.Key, out user))
                {
                    user = new DirectoryUser
                    {
                        ActiveDirectoryObjectGuid = item.Key
                    };

                    usersByGuid.Add(item.Key, user);
                    newUsers.Add(user);
                }

                MapDirectoryUser(user, item.Value);
                user.IsDeleted = false;

                if (existingUsers.Contains(user))
                {
                    DbEntityEntry<DirectoryUser> entry = _activeDirectoryDB.Entry(user);

                    List<string> changedFields = entry.CurrentValues.PropertyNames
                        .Where(property => !object.Equals(
                            entry.OriginalValues[property],
                            entry.CurrentValues[property]))
                        .ToList();

                    Log.Information(
                        "[USER SQL DIFF] Guid={Guid}, Fields={Fields}",
                        item.Key,
                        changedFields.Count == 0
                            ? "No changes"
                            : string.Join(", ", changedFields));
                }
                else
                {
                    Log.Information(
                        "[USER SQL DIFF] Guid={Guid}, Status=New User",
                        item.Key);
                }

            }

            using (var transaction =
                _activeDirectoryDB.Database.BeginTransaction())
            {
                if (newUsers.Count > 0)
                {
                    _activeDirectoryDB.DirectoryUsers.AddRange(newUsers);

                    // Generate UserIds for new users.
                    await _activeDirectoryDB.SaveChangesAsync();
                }

                // 6. Insert or update account metadata.
                var metadataToInsert =
                    new List<DirectoryUserAccountMetadata>();

                foreach (var item in adUsers)
                {
                    long userId = usersByGuid[item.Key].UserId;

                    DirectoryUserAccountMetadata metadata;

                    if (!metadataById.TryGetValue(userId, out metadata))
                    {
                        metadata = new DirectoryUserAccountMetadata
                        {
                            UserId = userId
                        };

                        metadataById.Add(userId, metadata);
                        metadataToInsert.Add(metadata);
                    }

                    MapAccountMetadata(metadata, item.Value);
                }

                if (metadataToInsert.Count > 0)
                {
                    _activeDirectoryDB
                        .Set<DirectoryUserAccountMetadata>()
                        .AddRange(metadataToInsert);
                }

                // 7. Diff the additional attributes.
                var attributesToInsert =
                    new List<DirectoryUserAttributeValue>();

                var attributesToDelete =
                    new List<DirectoryUserAttributeValue>();

                var matchedKeys =
                    new HashSet<Tuple<long, string, int>>();

                foreach (var item in adUsers)
                {
                    long userId = usersByGuid[item.Key].UserId;

                    foreach (DirectoryUserAttributeValue desired
                        in desiredAttributes[item.Key])
                    {
                        desired.UserId = userId;

                        var key = GetAttributeKey(desired);

                        if (!matchedKeys.Add(key))
                        {
                            throw new InvalidOperationException(
                                "Duplicate AD attribute key.");
                        }

                        DirectoryUserAttributeValue oldValue;

                        if (!oldAttributesByKey.TryGetValue(key, out oldValue))
                        {
                            attributesToInsert.Add(desired);
                            continue;
                        }

                        if (!SameAttributeValue(oldValue, desired))
                        {
                            oldValue.StringValue = desired.StringValue;
                            oldValue.NumberValue = desired.NumberValue;
                            oldValue.DateValue = desired.DateValue;
                            oldValue.BinaryValue = desired.BinaryValue;
                        }
                    }
                }

                foreach (var item in oldAttributesByKey)
                {
                    if (!matchedKeys.Contains(item.Key))
                        attributesToDelete.Add(item.Value);
                }

                // 8. Apply attribute changes.
                if (attributesToDelete.Count > 0)
                {
                    _activeDirectoryDB
                        .Set<DirectoryUserAttributeValue>()
                        .RemoveRange(attributesToDelete);
                }

                if (attributesToInsert.Count > 0)
                {
                    _activeDirectoryDB
                        .Set<DirectoryUserAttributeValue>()
                        .AddRange(attributesToInsert);
                }

                // 9. Save batch.
                await _activeDirectoryDB.SaveChangesAsync();

                transaction.Commit();
            }

            // This DbContext belongs to this sync request.
            // Detach saved entities to prevent EF tracking from
            // growing across thousands of employees.
            foreach (var entry in _activeDirectoryDB
                .ChangeTracker.Entries().ToList())
            {
                entry.State = EntityState.Detached;
            }

            return adUsers.Count;
        }




        private async Task ResolveChangedManagersAsync()
        {
            const string sql = @"
            SET NOCOUNT ON;
            SET XACT_ABORT ON;

            -- Prepare manager lookup
            SELECT
                UserId,
                DistinguishedName,
                LEFT(DistinguishedName, 150) AS DnKey
            INTO #Managers
            FROM dbo.DirectoryUsers
            WHERE IsDeleted = 0
              AND DistinguishedName IS NOT NULL;

            CREATE INDEX IX_Managers_Key
            ON #Managers(DnKey);


            -- Prepare all active employees
            SELECT
                UserId,
                ManagerUserId,
                ManagerDistinguishedName,
                LEFT(ManagerDistinguishedName, 150) AS DnKey
            INTO #Employees
            FROM dbo.DirectoryUsers
            WHERE IsDeleted = 0;

            CREATE INDEX IX_Employees_Key
            ON #Employees(DnKey);


            -- Resolve current manager for every employee
            SELECT
                E.UserId AS EmployeeId,
                M.UserId AS ManagerId
            INTO #Matches
            FROM #Employees E
            LEFT JOIN #Managers M
                ON E.DnKey = M.DnKey
                AND E.ManagerDistinguishedName = M.DistinguishedName
                AND E.UserId <> M.UserId;


            -- Prevent ambiguous manager relationships
            IF EXISTS
            (
                SELECT EmployeeId
                FROM #Matches
                GROUP BY EmployeeId
                HAVING COUNT(*) > 1
            )
            BEGIN
                THROW 50001,
                    'Duplicate manager matches found.',
                    1;
            END;


            -- Update ONLY employees whose manager changed
            SELECT
                E.EmployeeId,
                E.ManagerId
            INTO #Changes
            FROM #Matches E
            INNER JOIN dbo.DirectoryUsers U
                ON U.UserId = E.EmployeeId
            WHERE
                U.ManagerUserId <> E.ManagerId
                OR (U.ManagerUserId IS NULL AND E.ManagerId IS NOT NULL)
                OR (U.ManagerUserId IS NOT NULL AND E.ManagerId IS NULL);

            CREATE UNIQUE CLUSTERED INDEX IX_Changes
            ON #Changes(EmployeeId);


            -- Update in batches
            CREATE TABLE #Batch
            (
                EmployeeId BIGINT PRIMARY KEY,
                ManagerId BIGINT NULL
            );

            WHILE EXISTS (SELECT 1 FROM #Changes)
            BEGIN
                DELETE FROM #Batch;

                INSERT INTO #Batch(EmployeeId, ManagerId)
                SELECT TOP (200)
                    EmployeeId,
                    ManagerId
                FROM #Changes
                ORDER BY EmployeeId;

                BEGIN TRANSACTION;

                UPDATE U
                SET U.ManagerUserId = B.ManagerId
                FROM dbo.DirectoryUsers U
                INNER JOIN #Batch B
                    ON U.UserId = B.EmployeeId
                WHERE U.IsDeleted = 0;

                DELETE C
                FROM #Changes C
                INNER JOIN #Batch B
                    ON C.EmployeeId = B.EmployeeId;

                COMMIT TRANSACTION;
            END;

            DROP TABLE #Batch;
            DROP TABLE #Changes;
            DROP TABLE #Matches;
            DROP TABLE #Employees;
            DROP TABLE #Managers;
            ";

            await _activeDirectoryDB.Database
                .ExecuteSqlCommandAsync(
                    TransactionalBehavior.DoNotEnsureTransaction,
                    sql);
        }



        private static string NormalizeDepartmentName(string department)
        {
            if (string.IsNullOrWhiteSpace(department))
                return null;

            string value = department.Trim();

            switch (value.ToLowerInvariant())
            {
                case "cbu":
                    return "CBU";

                case "ceo":
                    return "CEO";

                case "consumer marketing":
                case "consumer_mkg":
                case "Consumer Market":
                    return "Consumer Marketing";

                case "consumer sales":
                    return "Consumer Sales";

                case "customer care":
                case "customer crae":
                    return "Customer Care";

                case "enterprise":
                    return "Enterprise";

                case "external affairs":
                case "ext. affairs":
                case "externl affairs":
                    return "External affairs";

                case "finance":
                    return "Finance";

                case "financial services":
                    return "Financial Services";

                case "hr":
                case "human resources":
                    return "HR";

                case "property":
                    return "Property";

                case "retail":
                    return "Retail";

                case "strategy":
                case "strategy _ b d":
                    return "Strategy";

                case "technology":
                case "tecnology":
                    return "Technology";

                default:
                    // Preserve unknown values until business mapping is confirmed.
                    return value;
            }
        }



        public async Task<Result<DirectoryUserItemDto>> GetHierarchyRootAsync()
        {
            var ceos = await _activeDirectoryDB.DirectoryUsers
                .AsNoTracking()
                .Where(x =>
                    !x.IsDeleted &&
                    x.JobTitle == "CEO, Egypt")
                .Take(2)
                .Select(UserItemProjection)
                .ToListAsync();

            if (ceos.Count == 0)
            {
                return Result.Failure<DirectoryUserItemDto>(
                    new Error(
                        "Hierarchy.CeoNotFound",
                        "CEO, Egypt was not found."));
            }

            if (ceos.Count > 1)
            {
                return Result.Failure<DirectoryUserItemDto>(
                    new Error(
                        "Hierarchy.MultipleCeos",
                        "More than one CEO was found."));
            }

            var ceo = ceos[0];

            await PopulateUserRelationsAsync(
                new List<DirectoryUserItemDto> { ceo });

            return Result.Success(ceo);
        }



        //====== Intrafrtions




        public async Task<Result<PagedResultDto<DirectoryUserDto>>> SearchDirectoryUsersAsync(
            string search,
            string searchField,
            int page,
            int pageSize,
            string relations = "none")
        {
            if (string.IsNullOrWhiteSpace(search))
            {
                return Result.Failure<PagedResultDto<DirectoryUserDto>>(
                    new Error("Search.Invalid", "Search is required."));
            }

            if (page < 1 || pageSize < 1 || pageSize > 100 ||
                ((long)page - 1) * pageSize > int.MaxValue)
            {
                return Result.Failure<PagedResultDto<DirectoryUserDto>>(
                    new Error("Paging.Invalid", "Invalid pagination values."));
            }

            search = search.Trim();

            searchField = (searchField ?? "all")
                .Trim()
                .ToLowerInvariant();

            relations = (relations ?? "none")
                .Trim()
                .ToLowerInvariant();

            if (relations != "none" &&
                relations != "parents" &&
                relations != "children" &&
                relations != "both")
            {
                return Result.Failure<PagedResultDto<DirectoryUserDto>>(
                    new Error(
                        "Search.InvalidRelations",
                        "Allowed: none, parents, children, both."));
            }

            IQueryable<DirectoryUser> query =
                _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

            switch (searchField)
            {
                case "fullname":
                    query = query.Where(x =>
                        x.FullName.Contains(search));
                    break;

                case "accountname":
                    query = query.Where(x =>
                        x.NT.StartsWith(search));
                    break;

                case "email":
                    query = query.Where(x =>
                        x.Email.Contains(search));
                    break;

                case "mobile":
                    query = query.Where(x =>
                        x.MobileNumber.Contains(search));
                    break;

                case "employeecode":
                    query = query.Where(x =>
                        x.StaffId.StartsWith(search));
                    break;

                case "all":
                    query = query.Where(x =>
                        x.FullName.Contains(search) ||
                        x.NT.Contains(search) ||
                        x.Email.Contains(search) ||
                        x.MobileNumber.Contains(search) ||
                        x.StaffId.Contains(search) ||
                        x.SapId.Contains(search));
                    break;

                default:
                    return Result.Failure<PagedResultDto<DirectoryUserDto>>(
                        new Error(
                            "Search.InvalidField",
                            "Allowed: all, fullname, accountname, " +
                            "email, mobile, employeecode."));
            }

            int totalCount = await query.CountAsync();

            List<DirectoryUserDto> users = await query
                .OrderBy(x => x.FullName)
                .ThenBy(x => x.UserId)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(UserProjection)
                .ToListAsync();

            foreach (var user in users)
            {
                user.HoDNT = MapHODNt(user.ReportTo, user.HoDNT);
            }


            // Load relations only when requested.
            if (users.Count > 0 && relations != "none")
            {
                bool includeParents =
                    relations == "parents" || relations == "both";

                bool includeChildren =
                    relations == "children" || relations == "both";

                // Parent: direct manager only.
                if (includeParents)
                {
                    List<long> managerIds = users
                        .Where(x => x.ManagerUserId.HasValue)
                        .Select(x => x.ManagerUserId.Value)
                        .Distinct()
                        .ToList();

                    if (managerIds.Count > 0)
                    {
                        List<DirectoryUserDto> managers =
                            await _activeDirectoryDB.DirectoryUsers
                                .AsNoTracking()
                                .Where(x =>
                                    !x.IsDeleted &&
                                    managerIds.Contains(x.UserId))
                                .Select(UserProjection)
                                .ToListAsync();

                        var managerLookup = managers
                            .ToDictionary(x => x.UserId);

                        foreach (DirectoryUserDto user in users)
                        {
                            if (!user.ManagerUserId.HasValue)
                                continue;

                            DirectoryUserDto manager;

                            if (managerLookup.TryGetValue(
                                user.ManagerUserId.Value,
                                out manager))
                            {
                                user.Parent = manager;
                            }
                        }
                    }
                }

                // Children: direct reports only.
                if (includeChildren)
                {
                    List<long> userIds = users
                        .Select(x => x.UserId)
                        .ToList();

                    List<DirectoryUserDto> children =
                        await _activeDirectoryDB.DirectoryUsers
                            .AsNoTracking()
                            .Where(x =>
                                !x.IsDeleted &&
                                x.ManagerUserId.HasValue &&
                                userIds.Contains(x.ManagerUserId.Value))
                            .OrderBy(x => x.FullName)
                            .Select(UserProjection)
                            .ToListAsync();

                    var childrenLookup = children
                        .GroupBy(x => x.ManagerUserId.Value)
                        .ToDictionary(
                            x => x.Key,
                            x => x.ToList());

                    foreach (DirectoryUserDto user in users)
                    {
                        List<DirectoryUserDto> directReports;

                        user.Children = childrenLookup.TryGetValue(
                            user.UserId,
                            out directReports)
                            ? directReports
                            : new List<DirectoryUserDto>();
                    }
                }
            }

            return Result.Success(new PagedResultDto<DirectoryUserDto>
            {
                Items = users,
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize
            });
        }



        public async Task<Result<List<DepartmentWithSubDepartmentsDto>>> GetDepartmentsWithSubDepartmentsAsync(
            string department = null)
        {
            IQueryable<DirectoryUser> query = _activeDirectoryDB.DirectoryUsers
                .AsNoTracking()
                .Where(x =>
                    !x.IsDeleted &&
                    x.Department != null &&
                    x.Department != "");

            if (!string.IsNullOrWhiteSpace(department))
            {
                department = NormalizeDepartmentName(department);

                query = query.Where(x => x.Department == department);
            }

            // Group in SQL, not in memory.
            var data = await query
                .GroupBy(x => new
                {
                    x.Department,
                    x.SubDepartment
                })
                .Select(g => new
                {
                    Department = g.Key.Department,
                    SubDepartment = g.Key.SubDepartment,
                    EmployeeCount = g.Count()
                })
                .ToListAsync();

            // Build nested response in memory.
            var result = data
                .GroupBy(
                    x => x.Department.Trim(),
                    StringComparer.OrdinalIgnoreCase)
                .Select(dept => new DepartmentWithSubDepartmentsDto
                {
                    Department = dept.Key,

                    TotalEmployees = dept.Sum(x => x.EmployeeCount),

                    SubDepartments = dept
                        .Where(x => !string.IsNullOrWhiteSpace(x.SubDepartment))
                        .GroupBy(
                            x => x.SubDepartment.Trim(),
                            StringComparer.OrdinalIgnoreCase)
                        .Select(sub => new SubDepartmentDto
                        {
                            Name = sub.Key,
                            EmployeeCount = sub.Sum(x => x.EmployeeCount)
                        })
                        .OrderBy(x => x.Name)
                        .ToList()
                })
                .OrderBy(x => x.Department)
                .ToList();

            return Result.Success(result);
        }



        public async Task<Result<DirectoryDepartmentResponseDto>> GetUsersByDepartmentAsync(
            string department,
            bool hierarchical,
            string direction,
            string email)
        {
            department = NormalizeDepartmentName(department);

            List<DirectoryUserDto> users = await _activeDirectoryDB
                .DirectoryUsers
                .AsNoTracking()
                .Where(x =>
                    !x.IsDeleted &&
                    x.Department == department)
                .OrderBy(x => x.FullName)
                .ThenBy(x => x.UserId)
                .Select(UserProjection)
                .ToListAsync();

            var response = new DirectoryDepartmentResponseDto
            {
                Department = department,
                Hierarchical = hierarchical,
                Direction = direction,
                TotalCount = users.Count
            };

            // OPTION 1: Flat list.
            if (!hierarchical)
            {
                response.Users = users;
                return Result.Success(response);
            }

            // OPTION 2: Department children hierarchy.
            if (direction == "children")
            {
                response.Hierarchy = BuildDepartmentHierarchy(users);
                return Result.Success(response);
            }

            // OPTION 3: Employee's parent hierarchy using Email.
            if (string.IsNullOrWhiteSpace(email))
            {
                return Result.Failure<DirectoryDepartmentResponseDto>(
                    new Error(
                        "Directory.EmailRequired",
                        "Email is required for parents hierarchy."));
            }

            email = email.Trim();

            var matchedUsers = users
                .Where(x =>
                    !string.IsNullOrWhiteSpace(x.Email) &&
                    string.Equals(
                        x.Email.Trim(),
                        email,
                        StringComparison.OrdinalIgnoreCase))
                .Take(2)
                .ToList();

            if (matchedUsers.Count == 0)
            {
                return Result.Failure<DirectoryDepartmentResponseDto>(
                    new Error(
                        "Directory.UserNotFound",
                        "User not found in this department."));
            }

            if (matchedUsers.Count > 1)
            {
                return Result.Failure<DirectoryDepartmentResponseDto>(
                    new Error(
                        "Directory.DuplicateEmail",
                        "Multiple users found with the same email."));
            }

            long userId = matchedUsers[0].UserId;

            DirectoryUserNodeDto parentTree =
                await BuildParentHierarchyAsync(userId);

            response.Hierarchy = new List<DirectoryUserNodeDto>
            {
                parentTree
            };

            return Result.Success(response);
        }




        private static readonly Expression<Func<DirectoryUser, DirectoryUserDto>>
            UserProjection = u => new DirectoryUserDto
            {
                UserId = u.UserId,
                ActiveDirectoryObjectGuid = u.ActiveDirectoryObjectGuid,
                Company = u.CompanyName,
                DisplyName = u.DisplayName,
                Gender = u.Gender,

                FullName = u.FullName,
                NT = u.NT,
                Email = u.Email,
                MobileNumber = u.MobileNumber,

                StaffId = u.StaffId,
                SapId = u.SapId,

                Department = u.Department,
                JobTitle = u.JobTitle,
                CostCenter = u.CostCenter,

                ManagerUserId = u.ManagerUserId,
                IsEnabled = u.IsEnabled,

                HiringDate = u.HiringDate,
                Office = u.Office,
                ReportTo = u.ReportTo,

                MangerNT = u.ManagerNT,
                HoDNT = u.HoDNT,

                IsInternal = u.IsInternal,
                SubDepartment = u.SubDepartment,



            };


        private static string MapHODNt(string reportTo, string hodNt)
        {
            hodNt = hodNt?.Trim();
            reportTo = reportTo?.Trim();

            if (string.Equals(hodNt, "Manager HOD", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(hodNt, "Manager EXCO", StringComparison.OrdinalIgnoreCase) ||
                string.Equals(hodNt, "Manager CEO", StringComparison.OrdinalIgnoreCase))
            {
                return reportTo;
            }

            return hodNt;
        }




        public async Task<Result<GroupsUpsertSummaryDto>> SyncGroupsAsync()
        {
            const string syncName = "AD-Groups";
            var totalWatch = System.Diagnostics.Stopwatch.StartNew();
            var stepWatch = new System.Diagnostics.Stopwatch();
            string stage = "Starting group sync";
            int received = -1;

            var report = new SyncEmailReport
            {
                SyncName = syncName,
                ItemName = "Groups",
                Status = SyncEmailStatus.Started,
                StartedAtUtc = DateTime.UtcNow,
                Stage = stage
            };

            report.Details["Source"] = "Active Directory";
            report.Details["Destination"] = "DirectoryGroups";
            report.Details["Operation"] = "Insert / Update";

            Log.Information("[GROUP SYNC][START] Utc={Utc}", DateTime.UtcNow);

            try
            {
                _activeDirectoryDB.Database.CommandTimeout = 300;

                stepWatch.Restart();
                Log.Information("[GROUP SYNC][EMAIL START] Sending started notification");
                await _syncEmailNotifier.TrySendAsync(report);
                Log.Information("[GROUP SYNC][EMAIL START DONE] Seconds={Seconds:F2}", stepWatch.Elapsed.TotalSeconds);

                // 1. Read checkpoint.
                stage = "Reading checkpoint";
                report.Stage = stage;
                stepWatch.Restart();
                Log.Information("[GROUP SYNC][CHECKPOINT START]");

                var previous = await _activeDirectoryDB.DirectorySyncStates
                    .AsNoTracking()
                    .FirstOrDefaultAsync(x => x.SyncName == syncName);

                bool initialSync = previous == null || !previous.UsnWatermark.HasValue;
                long fromUsn = initialSync ? 0L : previous.UsnWatermark.Value;
                string dcName = initialSync ? null : previous.DomainControllerName;

                Log.Information(
                    "[GROUP SYNC][CHECKPOINT DONE] Mode={Mode}, FromUSN={FromUSN}, DC={DC}, " +
                    "HasCheckpoint={HasCheckpoint}, Seconds={Seconds:F2}",
                    initialSync ? "Full" : "Incremental",
                    fromUsn,
                    dcName ?? "(not pinned)",
                    previous != null,
                    stepWatch.Elapsed.TotalSeconds);

                if (!initialSync &&
                    (string.IsNullOrWhiteSpace(dcName) || !previous.InvocationId.HasValue))
                {
                    throw new InvalidOperationException("Stored group sync DC identity is incomplete.");
                }

                // 2. Read Active Directory. Includes RootDSE, paged LDAP search, member ranges.
                stage = "Fetching groups from AD";
                report.Stage = stage;
                stepWatch.Restart();
                Log.Information(
                    "[GROUP SYNC][AD START] Mode={Mode}, FromUSN={FromUSN}, DC={DC}",
                    initialSync ? "Full" : "Incremental", fromUsn, dcName ?? "(discovery)");

                bool usersSyncCompleted = await _activeDirectoryDB.DirectorySyncStates
                    .AsNoTracking()
                    .AnyAsync(x =>
                        x.SyncName == "AD-Users" &&
                        x.UsnWatermark.HasValue &&
                        x.LastSuccessfulSyncUtc.HasValue);

                if (!usersSyncCompleted)
                {
                    Log.Warning(
                        "[GROUP SYNC] Waiting for initial Users Sync to complete.");

                    report.Status = SyncEmailStatus.Failed;
                    report.FailureReason = "Initial Users Sync not completed.";

                    return Result.Failure<GroupsUpsertSummaryDto>(
                        new Error(
                            "Groups.UsersSyncNotReady",
                            "Users Sync must complete before Groups Sync."));
                }


                var changes = await _activeDirectoryService.GetChangedGroupsAsync(fromUsn, dcName);

                // IMPORTANT: this log proves ALL AD calls (including member ranges) have finished.
                received = changes?.Groups?.Count ?? -1;
                Log.Information(
                    "[GROUP SYNC][AD COMPLETE] Seconds={Seconds:F2}, Groups={Groups}, " +
                    "FromUSN={FromUSN}, ToUSN={ToUSN}, DC={DC}",
                    stepWatch.Elapsed.TotalSeconds,
                    received,
                    fromUsn,
                    changes?.ToUsn,
                    changes?.DomainControllerName);
                System.Diagnostics.Debug.WriteLine(
                    $"[GROUP SYNC][AD COMPLETE] Groups={received}, Time={stepWatch.Elapsed.TotalSeconds:F2}s");

                stage = "Validating AD response";
                report.Stage = stage;
                if (changes == null || changes.Groups == null ||
                    changes.FromUsn != fromUsn ||
                    changes.ToUsn < fromUsn ||
                    changes.InvocationId == Guid.Empty ||
                    string.IsNullOrWhiteSpace(changes.DomainControllerName))
                {
                    throw new InvalidOperationException("Invalid AD groups response.");
                }

                if (!initialSync &&
                    (!string.Equals(dcName, changes.DomainControllerName,
                        StringComparison.OrdinalIgnoreCase) ||
                     previous.InvocationId.Value != changes.InvocationId))
                {
                    throw new InvalidOperationException("Domain Controller identity changed. Rebaseline required.");
                }

                var list = changes.Groups;
                if (initialSync && list.Count == 0)
                    throw new InvalidOperationException("Initial groups snapshot is empty.");

                report.TotalItems = list.Count;
                Log.Information(
                    "[GROUP SYNC][AD VALIDATED] Mode={Mode}, Count={Count}, FromUSN={From}, ToUSN={To}",
                    initialSync ? "Full" : "Incremental", list.Count, fromUsn, changes.ToUsn);

                var summary = new GroupsUpsertSummaryDto { TotalReceived = list.Count };

                // 3. SQL Upsert and membership reconciliation.
                if (list.Count > 0)
                {
                    stage = "Preparing JSON groups";
                    report.Stage = stage;
                    stepWatch.Restart();
                    Log.Information("[GROUP SYNC][JSON CONVERT START] Groups={Count}", list.Count);
                    JArray groupsJson = JArray.FromObject(list);
                    Log.Information("[GROUP SYNC][JSON CONVERT DONE] Seconds={Seconds:F2}",
                        stepWatch.Elapsed.TotalSeconds);

                    stage = "Upserting groups";
                    report.Stage = stage;
                    stepWatch.Restart();
                    Log.Information("[GROUP SYNC][UPSERT START] Groups={Count}", list.Count);
                    Result<GroupsUpsertSummaryDto> result = await UpsertDirectoryGroupsAsync(groupsJson);

                    // Never access result.Value until IsFailure has been checked.
                    if (result.IsFailure)
                    {
                        Log.Error("[GROUP SYNC][UPSERT FAILED] Seconds={Seconds:F2}, Error={Error}",
                            stepWatch.Elapsed.TotalSeconds, result.Error.Description);
                        report.Status = SyncEmailStatus.Failed;
                        report.FailureReason = result.Error.Description;
                        return result;
                    }

                    summary = result.Value;
                    Log.Information(
                        "[GROUP SYNC][UPSERT DONE] Seconds={Seconds:F2}, Received={Received}, " +
                        "Inserted={Inserted}, Updated={Updated}",
                        stepWatch.Elapsed.TotalSeconds,
                        summary.TotalReceived, summary.Inserted, summary.Updated);

                    stage = "Synchronizing memberships";
                    report.Stage = stage;
                    stepWatch.Restart();
                    Log.Information("[GROUP SYNC][MEMBERSHIPS START] Groups={Count}", list.Count);
                    await SyncGroupMembershipsFromSnapshotAsync(list);
                    Log.Information("[GROUP SYNC][MEMBERSHIPS DONE] Seconds={Seconds:F2}",
                        stepWatch.Elapsed.TotalSeconds);
                }
                else
                {
                    Log.Information("[GROUP SYNC][NO CHANGES] Upsert and memberships skipped");
                }

                // 4. Checkpoint.
                stage = "Saving checkpoint";
                report.Stage = stage;
                stepWatch.Restart();
                Log.Information("[GROUP SYNC][CHECKPOINT SAVE START] ToUSN={ToUSN}", changes.ToUsn);

                using (var transaction = _activeDirectoryDB.Database.BeginTransaction())
                {
                    var state = await _activeDirectoryDB.DirectorySyncStates
                        .FirstOrDefaultAsync(x => x.SyncName == syncName);

                    if (state == null)
                    {
                        state = new DirectorySyncState { SyncName = syncName };
                        _activeDirectoryDB.DirectorySyncStates.Add(state);
                        Log.Information("[GROUP SYNC][CHECKPOINT] Creating AD-Groups checkpoint");
                    }
                    else if (initialSync
                        ? state.UsnWatermark.HasValue
                        : state.UsnWatermark != fromUsn)
                    {
                        throw new InvalidOperationException("Group checkpoint changed during synchronization.");
                    }

                    state.TrackingMethod = "USN";
                    state.UsnWatermark = changes.ToUsn;
                    state.DomainControllerName = changes.DomainControllerName;
                    state.InvocationId = changes.InvocationId;
                    state.LastSuccessfulSyncUtc = DateTime.UtcNow;

                    Log.Information("[GROUP SYNC][CHECKPOINT SAVECHANGES START]");
                    await _activeDirectoryDB.SaveChangesAsync();
                    Log.Information("[GROUP SYNC][CHECKPOINT SAVECHANGES DONE] Seconds={Seconds:F2}",
                        stepWatch.Elapsed.TotalSeconds);

                    transaction.Commit();
                }

                Log.Information("[GROUP SYNC][CHECKPOINT COMMITTED] ToUSN={ToUSN}, Seconds={Seconds:F2}",
                    changes.ToUsn, stepWatch.Elapsed.TotalSeconds);

                report.Status = SyncEmailStatus.Succeeded;
                report.Stage = "Group synchronization completed";
                report.ProcessedItems = summary.Inserted + summary.Updated;
                report.Metrics["Inserted Groups"] = summary.Inserted.ToString("N0");
                report.Metrics["Updated Groups"] = summary.Updated.ToString("N0");
                report.Note =
                    $"Groups received: {list.Count:N0}, " +
                    $"Inserted: {summary.Inserted:N0}, Updated: {summary.Updated:N0}.";

                Log.Information(
                    "[GROUP SYNC][SUCCESS] TotalSeconds={Seconds:F2}, Received={Received}, " +
                    "Inserted={Inserted}, Updated={Updated}, CheckpointUSN={USN}",
                    totalWatch.Elapsed.TotalSeconds, list.Count,
                    summary.Inserted, summary.Updated, changes.ToUsn);

                return Result.Success(summary);
            }
            catch (Exception ex)
            {
                report.Status = SyncEmailStatus.Failed;
                report.FailureReason = ex.GetBaseException().Message;
                Log.Error(ex,
                    "[GROUP SYNC][FAILED] Stage={Stage}, Received={Received}, " +
                    "TotalSeconds={Seconds:F2}, Cause={Cause}",
                    stage, received, totalWatch.Elapsed.TotalSeconds, ex.GetBaseException().Message);
                System.Diagnostics.Debug.WriteLine(
                    $"[GROUP SYNC ERROR] Stage={stage}, {ex.GetBaseException()}");
                return Result.Failure<GroupsUpsertSummaryDto>(
                    new Error("Groups.SyncFailed", ex.Message));
            }
            finally
            {
                var emailWatch = System.Diagnostics.Stopwatch.StartNew();
                Log.Information("[GROUP SYNC][FINAL EMAIL START] Status={Status}", report.Status);
                try
                {
                    await _syncEmailNotifier.TrySendAsync(report);
                    Log.Information("[GROUP SYNC][FINAL EMAIL DONE] Seconds={Seconds:F2}",
                        emailWatch.Elapsed.TotalSeconds);
                }
                finally
                {
                    Log.Information("[GROUP SYNC][END] Stage={Stage}, Status={Status}, TotalSeconds={Seconds:F2}",
                        stage, report.Status, totalWatch.Elapsed.TotalSeconds);
                }
            }
        }





        public async Task<Result<GroupsUpsertSummaryDto>> UpsertDirectoryGroupsAsync(
            JArray groups)
        {
            var watch = System.Diagnostics.Stopwatch.StartNew();
            string stage = "Validation";
            int currentIndex = 0;

            Log.Information("[GROUP UPSERT][START] InputCount={Count}", groups?.Count ?? 0);

            try
            {
                if (groups == null || groups.Count == 0)
                {
                    Log.Warning("[GROUP UPSERT][EMPTY] No groups received");
                    return Result.Failure<GroupsUpsertSummaryDto>(
                        new Error("Groups.Empty", "No groups received."));
                }

                stage = "Loading existing groups from SQL";
                var stepWatch = System.Diagnostics.Stopwatch.StartNew();
                Log.Information("[GROUP UPSERT][SQL LOAD START] Loading existing groups by GUID");

                var existingGroups = await _activeDirectoryDB.DirectoryGroups
                    .ToDictionaryAsync(x => x.DLObjectGuid);

                Log.Information(
                    "[GROUP UPSERT][SQL LOAD DONE] ExistingGroups={Count}, Seconds={Seconds:F2}",
                    existingGroups.Count, stepWatch.Elapsed.TotalSeconds);

                var summary = new GroupsUpsertSummaryDto { TotalReceived = groups.Count };
                var processedGuids = new HashSet<Guid>();
                DateTime now = DateTime.UtcNow;

                stage = "Mapping incoming groups";
                stepWatch.Restart();
                Log.Information("[GROUP UPSERT][MAPPING START] InputCount={Count}", groups.Count);

                foreach (JToken token in groups)
                {
                    currentIndex++;
                    JObject item = token as JObject;

                    if (item == null)
                    {
                        Log.Error("[GROUP UPSERT][INVALID ITEM] Index={Index}", currentIndex);
                        return Result.Failure<GroupsUpsertSummaryDto>(
                            new Error("Groups.InvalidItem", "Invalid group object."));
                    }

                    Guid objectGuid;
                    if (!Guid.TryParse(GetGroupText(item, "objectGUID"), out objectGuid) ||
                        objectGuid == Guid.Empty)
                    {
                        Log.Error("[GROUP UPSERT][INVALID GUID] Index={Index}", currentIndex);
                        return Result.Failure<GroupsUpsertSummaryDto>(
                            new Error("Groups.InvalidGuid", "A group has a missing or invalid objectGUID."));
                    }

                    if (!processedGuids.Add(objectGuid))
                    {
                        Log.Error("[GROUP UPSERT][DUPLICATE GUID] Index={Index}, GUID={Guid}",
                            currentIndex, objectGuid);
                        return Result.Failure<GroupsUpsertSummaryDto>(
                            new Error("Groups.DuplicateGuid", "Duplicate group GUID in the request: " + objectGuid));
                    }

                    DirectoryGroup entity;
                    if (!existingGroups.TryGetValue(objectGuid, out entity))
                    {
                        entity = new DirectoryGroup { DLObjectGuid = objectGuid };
                        _activeDirectoryDB.DirectoryGroups.Add(entity);
                        existingGroups.Add(objectGuid, entity);
                        summary.Inserted++;
                    }
                    else
                    {
                        summary.Updated++;
                    }

                    entity.DLObjectGuid = objectGuid;
                    entity.DLDistinguishedName = GetGroupText(item, "distinguishedName");
                    entity.DLName = GetGroupText(item, "name");
                    entity.DLDisplayName = GetGroupText(item, "displayName");
                    entity.DLNT = GetGroupText(item, "sAMAccountName");
                    //entity.DLObjectSid = GetGroupText(item, "objectSid");
                    entity.DLDescription = GetGroupText(item, "description");
                    //entity.DLGroupType = GetGroupInt(item, "groupType");
                    entity.DLManagedBy = GetGroupText(item, "managedBy");
                    entity.DLEmail = GetGroupText(item, "mail");
                    //entity.DLAlias = GetGroupText(item, "mailNickname");
                    entity.DLProxyAddresses = GetGroupProxyAddresses(item);
                    entity.DLIsHiddenFromAddressLists = GetGroupBool(item, "msExchHideFromAddressLists");
                    entity.DLExchangeRecipientTypeDetails = GetGroupLong(item, "msExchRecipientTypeDetails");
                    entity.DLWhenCreatedUtc = GetGroupDate(item, "whenCreated");
                    entity.DLWhenChangedUtc = GetGroupDate(item, "whenChanged");
                    entity.DLUsnChanged = GetGroupLong(item, "uSNChanged");
                    entity.IsDeleted = false;
                    entity.LastSyncedAtUtc = now;

                    if (currentIndex % 500 == 0)
                    {
                        Log.Information(
                            "[GROUP UPSERT][MAPPING PROGRESS] Mapped={Mapped}/{Total}, " +
                            "Inserted={Inserted}, Existing={Existing}, Seconds={Seconds:F2}",
                            currentIndex, groups.Count, summary.Inserted,
                            summary.Updated, stepWatch.Elapsed.TotalSeconds);
                    }
                }

                Log.Information(
                    "[GROUP UPSERT][MAPPING DONE] Seconds={Seconds:F2}, Inserted={Inserted}, " +
                    "Updated={Updated}, Tracked={Tracked}",
                    stepWatch.Elapsed.TotalSeconds, summary.Inserted, summary.Updated,
                    _activeDirectoryDB.DirectoryGroups.Local.Count);

                stage = "Saving groups to SQL";
                stepWatch.Restart();
                Log.Information("[GROUP UPSERT][SQL SAVE START] Inserted={Inserted}, Updated={Updated}",
                    summary.Inserted, summary.Updated);
                await _activeDirectoryDB.SaveChangesAsync();
                Log.Information(
                    "[GROUP UPSERT][SQL SAVE DONE] Seconds={Seconds:F2}, TotalSeconds={TotalSeconds:F2}",
                    stepWatch.Elapsed.TotalSeconds, watch.Elapsed.TotalSeconds);

                Log.Information("[GROUP UPSERT][SUCCESS] InputCount={Count}, TotalSeconds={Seconds:F2}",
                    groups.Count, watch.Elapsed.TotalSeconds);
                return Result.Success(summary);
            }
            catch (Exception ex)
            {
                Log.Error(ex,
                    "[GROUP UPSERT][FAILED] Stage={Stage}, ItemIndex={Index}, " +
                    "TotalSeconds={Seconds:F2}", stage, currentIndex, watch.Elapsed.TotalSeconds);
                throw;
            }
        }
        private static JToken GetGroupField(JObject item, string name)
        {
            JToken value;

            return item.TryGetValue(
                name,
                StringComparison.OrdinalIgnoreCase,
                out value)
                ? value
                : null;
        }

        private static string GetGroupText(JObject item, string name)
        {
            JToken value = GetGroupField(item, name);

            if (value == null || value.Type == JTokenType.Null)
                return null;

            if (value.Type == JTokenType.Array)
                value = value.FirstOrDefault();

            return value == null || value.Type == JTokenType.Null
                ? null
                : value.ToString();
        }

        private static int? GetGroupInt(JObject item, string name)
        {
            int result;

            return int.TryParse(
                GetGroupText(item, name),
                System.Globalization.NumberStyles.Integer,
                System.Globalization.CultureInfo.InvariantCulture,
                out result)
                ? (int?)result
                : null;
        }

        private static long? GetGroupLong(JObject item, string name)
        {
            long result;

            return long.TryParse(
                GetGroupText(item, name),
                System.Globalization.NumberStyles.Integer,
                System.Globalization.CultureInfo.InvariantCulture,
                out result)
                ? (long?)result
                : null;
        }

        private static bool? GetGroupBool(JObject item, string name)
        {
            string value = GetGroupText(item, name);

            if (string.IsNullOrWhiteSpace(value))
                return null;

            if (value.Equals("1") ||
                value.Equals("true", StringComparison.OrdinalIgnoreCase))
                return true;

            if (value.Equals("0") ||
                value.Equals("false", StringComparison.OrdinalIgnoreCase))
                return false;

            return null;
        }

        private static DateTime? GetGroupDate(JObject item, string name)
        {
            string value = GetGroupText(item, name);

            if (string.IsNullOrWhiteSpace(value))
                return null;

            DateTime date;

            string[] formats =
            {
                "yyyyMMddHHmmss'Z'",
                "yyyyMMddHHmmss.FFFFFFF'Z'",
                "yyyyMMddHHmmss.fff'Z'",
                "o"
            };

            var styles =
                System.Globalization.DateTimeStyles.AssumeUniversal |
                System.Globalization.DateTimeStyles.AdjustToUniversal;

            if (DateTime.TryParseExact(
                value,
                formats,
                System.Globalization.CultureInfo.InvariantCulture,
                styles,
                out date))
            {
                return date;
            }

            if (DateTime.TryParse(
                value,
                System.Globalization.CultureInfo.InvariantCulture,
                styles,
                out date))
            {
                return date;
            }

            return null;
        }

        private static string GetGroupProxyAddresses(JObject item)
        {
            JToken value = GetGroupField(item, "proxyAddresses");

            if (value == null || value.Type == JTokenType.Null)
                return null;

            if (value.Type == JTokenType.Array)
                return value.ToString(Newtonsoft.Json.Formatting.None);

            return Newtonsoft.Json.JsonConvert.SerializeObject(
                new[] { value.ToString() });
        }


        private async Task<DirectoryUserNodeDto> BuildParentHierarchyAsync(
            long userId)
        {
            var chain = new List<DirectoryUserDto>();
            var visited = new HashSet<long>();

            long? currentId = userId;

            while (currentId.HasValue)
            {
                if (!visited.Add(currentId.Value))
                    throw new InvalidOperationException(
                        "Circular manager relationship detected.");

                if (chain.Count >= 100)
                    throw new InvalidOperationException(
                        "Hierarchy depth limit exceeded.");

                long id = currentId.Value;

                DirectoryUserDto user = await _activeDirectoryDB
                    .DirectoryUsers
                    .AsNoTracking()
                    .Where(x => x.UserId == id && !x.IsDeleted)
                    .Select(UserProjection)
                    .FirstOrDefaultAsync();

                if (user == null)
                    break;

                chain.Add(user);

                currentId = user.ManagerUserId;
            }

            chain.Reverse();

            DirectoryUserNodeDto root = null;
            DirectoryUserNodeDto previous = null;

            foreach (DirectoryUserDto user in chain)
            {
                var node = new DirectoryUserNodeDto
                {
                    User = user
                };

                if (root == null)
                    root = node;

                if (previous != null)
                    previous.Children.Add(node);

                previous = node;
            }

            return root;
        }


        private static List<DirectoryUserNodeDto> BuildDepartmentHierarchy(List<DirectoryUserDto> users)
        {
            var nodes = users.ToDictionary(
                x => x.UserId,
                x => new DirectoryUserNodeDto { User = x });

            var usersById = users.ToDictionary(x => x.UserId);

            var roots = new List<DirectoryUserNodeDto>();

            foreach (DirectoryUserDto user in users)
            {
                DirectoryUserNodeDto parentNode;

                if (user.ManagerUserId.HasValue &&
                    nodes.TryGetValue(
                        user.ManagerUserId.Value,
                        out parentNode) &&
                    !HasHierarchyCycle(
                        user.UserId,
                        user.ManagerUserId.Value,
                        usersById))
                {
                    parentNode.Children.Add(nodes[user.UserId]);
                }
                else
                {
                    roots.Add(nodes[user.UserId]);
                }
            }

            return roots;
        }



        private static string NormalizeGender(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
                return null;

            string value = title
                .Trim()
                .Replace(".", "")
                .ToLowerInvariant();

            switch (value)
            {
                case "mr":
                case "mister":
                    return "Male";

                case "mrs":
                case "miss":
                case "ms":
                case "madam":
                case "madame":
                    return "Female";

                default:
                    return null;
            }
        }


        private static bool HasHierarchyCycle(
        long childId,
        long managerId,
        Dictionary<long, DirectoryUserDto> users)
        {
            var visited = new HashSet<long> { childId };

            long? currentId = managerId;

            while (currentId.HasValue)
            {
                if (!visited.Add(currentId.Value))
                    return true;

                DirectoryUserDto currentUser;

                if (!users.TryGetValue(
                    currentId.Value,
                    out currentUser))
                {
                    break;
                }

                currentId = currentUser.ManagerUserId;
            }

            return false;
        }



        private sealed class GroupMembershipPlan
        {
            public DirectoryGroup Parent { get; set; }
            public HashSet<long> UserIds { get; set; }
            public HashSet<long> ChildGroupIds { get; set; }
        }




        private async Task SyncGroupMembershipsFromSnapshotAsync(
             List<Dictionary<string, object>> list)
        {
            const int batchSize = 100;
            var watch = System.Diagnostics.Stopwatch.StartNew();
            int batchNumber = 0;
            string stage = "Starting membership sync";

            Log.Information("[MEMBERSHIP][START] ADGroups={Count}, BatchSize={BatchSize}",
                list?.Count ?? 0, batchSize);

            try
            {
                stage = "Preparing SQL group lookup";
                var stageWatch = System.Diagnostics.Stopwatch.StartNew();
                Log.Information("[MEMBERSHIP][GROUP LOOKUP START]");

                // Groups are already tracked after Upsert.
                var groups = _activeDirectoryDB.DirectoryGroups.Local
                    .Where(g => !g.IsDeleted)
                    .ToList();

                var groupsByGuid = groups.ToDictionary(g => g.DLObjectGuid);
                var groupsById = groups.ToDictionary(g => g.GroupId);

                var groupsByDn = groups
                    .Where(g => !string.IsNullOrWhiteSpace(g.DLDistinguishedName))
                    .GroupBy(g => g.DLDistinguishedName.Trim(),
                        StringComparer.OrdinalIgnoreCase)
                    .Where(g => g.Count() == 1)
                    .ToDictionary(g => g.Key, g => g.First().GroupId,
                        StringComparer.OrdinalIgnoreCase);

                Log.Information(
                    "[MEMBERSHIP][GROUP LOOKUP DONE] TrackedGroups={Tracked}, GUIDs={Guids}, " +
                    "ResolvableDNs={DNs}, Seconds={Seconds:F2}",
                    groups.Count, groupsByGuid.Count, groupsByDn.Count,
                    stageWatch.Elapsed.TotalSeconds);

                stage = "Loading SQL users for DN matching";
                stageWatch.Restart();
                Log.Information("[MEMBERSHIP][USER LOOKUP START]");

                // Load only the user fields needed for matching.
                var users = await _activeDirectoryDB.DirectoryUsers
                    .AsNoTracking()
                    .Where(u => !u.IsDeleted)
                    .Select(u => new { u.UserId, u.DistinguishedName })
                    .ToListAsync();

                var usersByDn = users
                    .Where(u => !string.IsNullOrWhiteSpace(u.DistinguishedName))
                    .GroupBy(u => u.DistinguishedName.Trim(),
                        StringComparer.OrdinalIgnoreCase)
                    .Where(u => u.Count() == 1)
                    .ToDictionary(u => u.Key, u => u.First().UserId,
                        StringComparer.OrdinalIgnoreCase);

                Log.Information(
                    "[MEMBERSHIP][USER LOOKUP DONE] SQLUsers={Users}, ResolvableDNs={DNs}, " +
                    "Seconds={Seconds:F2}",
                    users.Count, usersByDn.Count, stageWatch.Elapsed.TotalSeconds);

                stage = "Building membership plans";
                stageWatch.Restart();
                Log.Information("[MEMBERSHIP][PLANS START] ADGroups={Count}", list.Count);

                var plans = new List<GroupMembershipPlan>();

                int skippedRanges = 0;
                int emptyGroups = 0;
                int skippedUnresolved = 0;

                // Prepare relationships from AD snapshot.

                foreach (var item in list)
                {
                    // Don't process incomplete ranged memberships.
                    if (item.Keys.Any(k => k.StartsWith(
                        "member;range=", StringComparison.OrdinalIgnoreCase)))
                    {
                        Log.Error("[MEMBERSHIP][INCOMPLETE RANGE] Group skipped; sync must fail");
                        throw new InvalidOperationException(
                            "Incomplete group member range detected.");
                    }

                    // Resolve the parent group first.
                    Guid guid;
                    DirectoryGroup parent;

                    if (!item.ContainsKey("objectGUID") ||
                        !Guid.TryParse(Convert.ToString(item["objectGUID"]), out guid) ||
                        !groupsByGuid.TryGetValue(guid, out parent))
                    {
                        skippedUnresolved++;
                        Log.Debug("[MEMBERSHIP][UNRESOLVED PARENT] Number={Number}",
                            skippedUnresolved);
                        continue;
                    }

                    // No member attribute means an empty group
                    // when the AD read is complete.
                    object raw;
                    string[] members;

                    if (!item.TryGetValue("member", out raw) || raw == null)
                    {
                        members = Array.Empty<string>();
                        emptyGroups++;
                    }
                    else if (raw is string)
                    {
                        members = new[] { (string)raw };
                    }
                    else if (raw is string[])
                    {
                        members = (string[])raw;
                    }
                    else
                    {
                        skippedUnresolved++;
                        continue;
                    }

                    if (members.Any(string.IsNullOrWhiteSpace))
                    {
                        skippedUnresolved++;
                        continue;
                    }

                    var userIds = new HashSet<long>();
                    var childIds = new HashSet<long>();
                    bool invalid = false;

                    foreach (var value in members)
                    {
                        string dn = value.Trim();

                        long userId, childId;

                        bool isUser = usersByDn.TryGetValue(dn, out userId);
                        bool isGroup = groupsByDn.TryGetValue(dn, out childId);

                        if (isUser == isGroup ||
                            (isGroup && childId == parent.GroupId))
                        {
                            invalid = true;
                            break;
                        }

                        if (isUser)
                            userIds.Add(userId);
                        else
                            childIds.Add(childId);
                    }

                    if (invalid)
                    {
                        skippedUnresolved++;
                        continue;
                    }

                    // Empty groups are included with empty relationships.
                    plans.Add(new GroupMembershipPlan
                    {
                        Parent = parent,
                        UserIds = userIds,
                        ChildGroupIds = childIds
                    });
                }


                Log.Information(
                    "[MEMBERSHIP][PLANS DONE] Plans={Plans}, EmptyGroups={EmptyGroups}, " +
                    "Unresolved={Unresolved}, Seconds={Seconds:F2}",
                    plans.Count, emptyGroups, skippedUnresolved,
                    stageWatch.Elapsed.TotalSeconds);

                stage = "Preparing tracked user references";
                stageWatch.Restart();
                Log.Information("[MEMBERSHIP][REFERENCES START]");

                // Attach users by ID only when a relationship needs changing.
                var trackedUsers = _activeDirectoryDB.DirectoryUsers.Local
                    .ToDictionary(u => u.UserId);

                DirectoryUser GetUser(long id)
                {
                    if (!trackedUsers.TryGetValue(id, out var user))
                    {
                        user = new DirectoryUser { UserId = id };
                        _activeDirectoryDB.DirectoryUsers.Attach(user);
                        trackedUsers.Add(id, user);
                    }

                    return user;
                }

                var stateManager =
                    ((System.Data.Entity.Infrastructure.IObjectContextAdapter)
                        _activeDirectoryDB)
                    .ObjectContext.ObjectStateManager;

                int usersAdded = 0, usersRemoved = 0;
                int groupsAdded = 0, groupsRemoved = 0;

                Log.Information(
                    "[MEMBERSHIP][REFERENCES DONE] TrackedUsers={Count}, Seconds={Seconds:F2}",
                    trackedUsers.Count, stageWatch.Elapsed.TotalSeconds);
                Log.Information("[MEMBERSHIP][SQL BATCHES START] Plans={Plans}, Batches={Batches}",
                    plans.Count, (plans.Count + batchSize - 1) / batchSize);

                // Read and reconcile only the current batch.
                for (int i = 0; i < plans.Count; i += batchSize)
                {
                    batchNumber = i / batchSize + 1;
                    stage = "Membership batch " + batchNumber;
                    var batchWatch = System.Diagnostics.Stopwatch.StartNew();
                    var queryWatch = System.Diagnostics.Stopwatch.StartNew();
                    Log.Information("[MEMBERSHIP][BATCH START] Batch={Batch}, Offset={Offset}",
                        batchNumber, i);

                    var batch = plans.Skip(i).Take(batchSize).ToList();

                    var parentIds = batch
                        .Select(p => p.Parent.GroupId)
                        .ToList();

                    var userLinks = await _activeDirectoryDB.DirectoryGroups
                        .AsNoTracking()
                        .Where(g => parentIds.Contains(g.GroupId))
                        .SelectMany(g => g.DirectoryUsers.Select(u => new
                        {
                            g.GroupId,
                            u.UserId
                        }))
                        .ToListAsync();

                    Log.Information(
                        "[MEMBERSHIP][USER LINKS LOADED] Batch={Batch}, Links={Count}, Seconds={Seconds:F2}",
                        batchNumber, userLinks.Count, queryWatch.Elapsed.TotalSeconds);

                    queryWatch.Restart();
                    var groupLinks = await _activeDirectoryDB.DirectoryGroups
                        .AsNoTracking()
                        .Where(g => parentIds.Contains(g.GroupId))
                        .SelectMany(g => g.DirectoryGroups.Select(child => new
                        {
                            ParentId = g.GroupId,
                            ChildId = child.GroupId
                        }))
                        .ToListAsync();

                    Log.Information(
                        "[MEMBERSHIP][GROUP LINKS LOADED] Batch={Batch}, Links={Count}, Seconds={Seconds:F2}",
                        batchNumber, groupLinks.Count, queryWatch.Elapsed.TotalSeconds);

                    var oldUsers = userLinks.ToLookup(x => x.GroupId, x => x.UserId);
                    var oldGroups = groupLinks.ToLookup(x => x.ParentId, x => x.ChildId);

                    int oldAddedU = usersAdded;
                    int oldRemovedU = usersRemoved;
                    int oldAddedG = groupsAdded;
                    int oldRemovedG = groupsRemoved;
                    var diffWatch = System.Diagnostics.Stopwatch.StartNew();

                    // Avoid EF6 DetectChanges scanning all tracked entities on every Attach.
                    // Always restore the original setting before SaveChangesAsync.
                    bool previousAutoDetectChanges =
                        _activeDirectoryDB.Configuration.AutoDetectChangesEnabled;

                    try
                    {
                        _activeDirectoryDB.Configuration.AutoDetectChangesEnabled = false;

                        foreach (var plan in batch)
                        {
                            var parent = plan.Parent;

                            var existingUsers =
                                new HashSet<long>(oldUsers[parent.GroupId]);

                            var existingGroups =
                                new HashSet<long>(oldGroups[parent.GroupId]);

                            foreach (long id in plan.UserIds.Except(existingUsers))
                            {
                                stateManager.ChangeRelationshipState(
                                    parent,
                                    GetUser(id),
                                    nameof(DirectoryGroup.DirectoryUsers),
                                    System.Data.Entity.EntityState.Added);

                                usersAdded++;
                            }

                            foreach (long id in existingUsers.Except(plan.UserIds))
                            {
                                stateManager.ChangeRelationshipState(
                                    parent,
                                    GetUser(id),
                                    nameof(DirectoryGroup.DirectoryUsers),
                                    System.Data.Entity.EntityState.Deleted);

                                usersRemoved++;
                            }

                            foreach (long id in plan.ChildGroupIds.Except(existingGroups))
                            {
                                stateManager.ChangeRelationshipState(
                                    parent,
                                    groupsById[id],
                                    nameof(DirectoryGroup.DirectoryGroups),
                                    System.Data.Entity.EntityState.Added);

                                groupsAdded++;
                            }

                            foreach (long id in existingGroups.Except(plan.ChildGroupIds))
                            {
                                stateManager.ChangeRelationshipState(
                                    parent,
                                    groupsById[id],
                                    nameof(DirectoryGroup.DirectoryGroups),
                                    System.Data.Entity.EntityState.Deleted);

                                groupsRemoved++;
                            }
                        }
                    }
                    finally
                    {
                        _activeDirectoryDB.Configuration.AutoDetectChangesEnabled =
                            previousAutoDetectChanges;
                    }

                    Log.Information(
                        "[MEMBERSHIP][DIFF DONE] Batch={Batch}, UsersAdded={UA}, UsersRemoved={UR}, " +
                        "GroupsAdded={GA}, GroupsRemoved={GR}, Seconds={Seconds:F2}",
                        batchNumber,
                        usersAdded - oldAddedU, usersRemoved - oldRemovedU,
                        groupsAdded - oldAddedG, groupsRemoved - oldRemovedG,
                        diffWatch.Elapsed.TotalSeconds);

                    stage = "Saving membership batch " + batchNumber;
                    var saveWatch = System.Diagnostics.Stopwatch.StartNew();
                    Log.Information("[MEMBERSHIP][SQL SAVE START] Batch={Batch}, Groups={Count}",
                        batchNumber, batch.Count);
                    await _activeDirectoryDB.SaveChangesAsync();
                    Log.Information(
                        "[MEMBERSHIP][SQL SAVE DONE] Batch={Batch}, Seconds={Seconds:F2}, " +
                        "BatchTotalSeconds={BatchTotalSeconds:F2}",
                        batchNumber, saveWatch.Elapsed.TotalSeconds, batchWatch.Elapsed.TotalSeconds);

                    System.Diagnostics.Debug.WriteLine(
                        $"[MEMBERSHIP] Batch {batchNumber} saved. Groups={batch.Count}");
                }

                watch.Stop();
                Log.Information(
                    "[MEMBERSHIP][ALL SQL BATCHES COMPLETE] Batches={Batches}, " +
                    "Plans={Plans}, Seconds={Seconds:F2}",
                    batchNumber, plans.Count, watch.Elapsed.TotalSeconds);

                Log.Information(
                    "[MEMBERSHIP SYNC] Processed={Processed}, " +
                    "Ranges={Ranges}, Missing={Missing}, Unresolved={Unresolved}, " +
                    "UsersAdded={UA}, UsersRemoved={UR}, " +
                    "GroupsAdded={GA}, GroupsRemoved={GR}, Seconds={Seconds:F2}",
                    plans.Count, skippedRanges, emptyGroups,
                    skippedUnresolved, usersAdded, usersRemoved,
                    groupsAdded, groupsRemoved, watch.Elapsed.TotalSeconds);

                System.Diagnostics.Debug.WriteLine(
                    $"[MEMBERSHIP SYNC DONE] Processed={plans.Count}, " +
                    $"Ranges={skippedRanges}, Missing={emptyGroups}, " +
                    $"Unresolved={skippedUnresolved}, " +
                    $"Users +{usersAdded}/-{usersRemoved}, " +
                    $"Groups +{groupsAdded}/-{groupsRemoved}, " +
                    $"Time={watch.Elapsed.TotalSeconds:F2}s");
            }
            catch (Exception ex)
            {
                Log.Error(ex,
                    "[MEMBERSHIP SYNC FAILED] Stage={Stage}, Batch={Batch}, " +
                    "ElapsedSeconds={Seconds:F2}", stage, batchNumber, watch.Elapsed.TotalSeconds);

                System.Diagnostics.Debug.WriteLine(
                    $"[MEMBERSHIP ERROR] Batch={batchNumber}, " +
                    $"Cause={ex.GetBaseException().Message}");

                throw;
            }
        }

    }
}