﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace ADGlobalService.Services.SyncAdDB.UserPhotos
{
    internal static class PhotoResolutionSettings
    {
        private static readonly HashSet<string> Supported = new HashSet<string>(
            new[] { "48x48", "64x64", "96x96", "120x120", "240x240", "360x360", "432x432", "504x504", "648x648" },
            StringComparer.OrdinalIgnoreCase);

        public static bool IsValid(string resolution)
        {
            return !string.IsNullOrWhiteSpace(resolution) && Supported.Contains(resolution.Trim());
        }

        public static string[] GetSyncResolutions()
        {
            var raw = ConfigurationManager.AppSettings["PhotoSync:Resolutions"];

            var sizes = (string.IsNullOrWhiteSpace(raw) ? "48x48" : raw)
                .Split(',')
                .Select(s => s.Trim().ToLowerInvariant())
                .Where(s => s.Length > 0)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToArray();

            if (sizes.Length == 0 || sizes.Any(s => !IsValid(s)))
                throw new InvalidOperationException("Invalid PhotoSync:Resolutions configuration.");

            return sizes;
        }
    }
}
