﻿
using ADGlobalService.Abstractions;
using ADGlobalService.Data;
using ADGlobalService.Models.SyncAdDBDtos;
using ADGlobalService.Services.EmailService;
using ADGlobalService.Services.ProfileImageService;
using Serilog;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;

namespace ADGlobalService.Services.SyncAdDB.UserPhotos
{
    public sealed class UserPhotosService : IUserPhotosService
    {
        private readonly ActiveDirectoryDBEntities _db;
        private readonly SyncEmailNotifier _syncEmailNotifier;
        private readonly IProfileImageService _profileImageService;
        private const int MaxPageSize = 27000;
        private const int MaxConcurrentGraphCalls = 4;
        private const int MaxPhotoSizeBytes = 5 * 1024 * 1024;

        public UserPhotosService(
            ActiveDirectoryDBEntities db,
            IProfileImageService profileImageService,
            SyncEmailNotifier syncEmailNotifier)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
            _profileImageService = profileImageService
                ?? throw new ArgumentNullException(nameof(profileImageService));

            _db.Configuration.LazyLoadingEnabled = false;
            _db.Configuration.ProxyCreationEnabled = false;
            _db.Database.CommandTimeout = 120;
            _syncEmailNotifier = syncEmailNotifier;
        }





        public async Task<Result<PhotoSyncSummaryDto>> SyncAllAsync(int pageSize = 100)
        {
            if (pageSize < 1 || pageSize > 100)
            {
                return Result.Failure<PhotoSyncSummaryDto>(
                    new Error("Photos.InvalidPageSize", "Invalid page size."));
            }

            PhotoSyncSummaryDto total = new PhotoSyncSummaryDto();

            SyncEmailReport report = new SyncEmailReport
            {
                SyncName = "AD-Photos",
                ItemName = "Users",
                Status = SyncEmailStatus.Started,
                StartedAtUtc = DateTime.UtcNow,
                Stage = "Starting Photo Sync"
            };

            report.Details["Resolution"] = "48x48";
            report.Details["Page size"] = pageSize.ToString();
            report.Details["Source"] = "Microsoft Graph";
            report.Details["Destination"] = "DirectoryUserPhotos";

            int page = 1;

            try
            {
                // EMAIL 1: STARTED
                await _syncEmailNotifier.TrySendAsync(report);

                while (true)
                {
                    report.Stage = $"Synchronizing photos - Page {page}";

                    var result = await SyncBatchAsync(page, pageSize);

                    if (result.IsFailure)
                    {
                        report.Status = SyncEmailStatus.Failed;
                        report.FailureReason = result.Error.Description;

                        return Result.Failure<PhotoSyncSummaryDto>(
                            result.Error);
                    }

                    var batch = result.Value;

                    total.TotalEligibleUsers = batch.TotalEligibleUsers;
                    total.ProcessedUsers += batch.ProcessedUsers;
                    total.InsertedPhotos += batch.InsertedPhotos;
                    total.UpdatedPhotos += batch.UpdatedPhotos;
                    total.UnchangedPhotos += batch.UnchangedPhotos;
                    total.MissingPhotos += batch.MissingPhotos;
                    total.FailedPhotos += batch.FailedPhotos;

                    if (batch.Errors != null)
                        total.Errors.AddRange(batch.Errors);

                    // Update report metrics
                    report.TotalItems = total.TotalEligibleUsers;
                    report.ProcessedItems = total.ProcessedUsers;

                    if (batch.ProcessedUsers > 0)
                        report.CompletedBatches++;

                    report.TotalBatches = (int)Math.Ceiling(
                        total.TotalEligibleUsers / (double)pageSize);

                    report.Metrics["Inserted Photos"] =
                        total.InsertedPhotos.ToString("N0");

                    report.Metrics["Updated Photos"] =
                        total.UpdatedPhotos.ToString("N0");

                    report.Metrics["Unchanged Photos"] =
                        total.UnchangedPhotos.ToString("N0");

                    report.Metrics["Missing Photos"] =
                        total.MissingPhotos.ToString("N0");

                    report.Metrics["Failed Photos"] =
                        total.FailedPhotos.ToString("N0");

                    if (batch.ProcessedUsers < pageSize)
                        break;

                    page++;
                }

                report.Status = SyncEmailStatus.Succeeded;
                report.Stage = "Photo Sync completed";

                report.Note = total.FailedPhotos > 0
                    ? $"All batches completed, but {total.FailedPhotos:N0} photo requests failed. Review the application logs."
                    : "All photo Sync batches completed successfully.";

                return Result.Success(total);
            }
            catch (Exception ex)
            {
                report.Status = SyncEmailStatus.Failed;
                report.FailureReason =
                    ex.GetType().Name + ": " + ex.Message;

                Trace.TraceError(
                    "[PHOTO SYNC] " + ex);

                return Result.Failure<PhotoSyncSummaryDto>(
                    new Error(
                        "Photos.SyncFailed",
                        "Photo Sync failed. Check server logs."));
            }
            finally
            {
                // EMAIL 2: SUCCEEDED or FAILED
                await _syncEmailNotifier.TrySendAsync(report);
            }
        }



        public async Task<Result<PhotoSyncSummaryDto>> SyncBatchAsync(int page = 1, int pageSize = 50)
        {
            if (page < 1 || pageSize < 1 || pageSize > MaxPageSize ||
                ((long)page - 1) * pageSize > int.MaxValue)
            {
                return Result.Failure<PhotoSyncSummaryDto>(
                    new Error("Photos.InvalidRequest", "Invalid pagination values."));
            }

            try
            {
                string[] resolutions = PhotoResolutionSettings.GetSyncResolutions();

                // Uses Email because this property is confirmed in your DirectoryUser EDMX.
                // If Email differs from Entra UPN, map to the correct UPN/Entra object ID here.
                IQueryable<DirectoryUser> query = _db.DirectoryUsers
                    .AsNoTracking()
                    .Where(u => !u.IsDeleted && u.Email != null && u.Email != "");

                int total = await query.CountAsync();
                var users = await query
                    .OrderBy(u => u.UserId)
                    .Skip((page - 1) * pageSize)
                    .Take(pageSize)
                    .Select(u => new PhotoUser { UserId = u.UserId, Identifier = u.Email })
                    .ToListAsync();

                return Result.Success(await SyncSelectedUsersAsync(users, resolutions, total));
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Photo batch synchronization failed (page={Page}, size={PageSize})", page, pageSize);
                return Result.Failure<PhotoSyncSummaryDto>(
                    new Error("Photos.SyncFailed", "Photo batch synchronization failed; check server logs."));
            }
        }


        public async Task<Result<StoredUserPhotoDto>> GetPhotoAsync(
            long userId, string resolution = "96x96")
        {
            if (userId <= 0)
                return Result.Failure<StoredUserPhotoDto>(
                    new Error("Photos.InvalidRequest", "UserId must be positive."));

            resolution = (resolution ?? "96x96").Trim().ToLowerInvariant();
            if (!PhotoResolutionSettings.IsValid(resolution))
                return Result.Failure<StoredUserPhotoDto>(
                    new Error("Photos.InvalidResolution", "Unsupported image resolution."));

            try
            {
                // Single photo only. No Microsoft Graph call in GET requests.
                StoredUserPhotoDto photo = await _db.DirectoryUserPhotos
                    .AsNoTracking()
                    .Where(p => p.UserId == userId && p.Resolution == resolution)
                    .Select(p => new StoredUserPhotoDto
                    {
                        Photo = p.Photo,
                        ContentType = p.ContentType,
                        Resolution = p.Resolution,
                        LastSyncedAt = p.LastSyncedAt
                    })
                    .FirstOrDefaultAsync();

                if (photo == null)
                    return Result.Failure<StoredUserPhotoDto>(
                        new Error("Photos.NotFound", "No stored photo for this user and resolution."));

                return Result.Success(photo);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Failed to read stored photo for user {UserId}", userId);
                return Result.Failure<StoredUserPhotoDto>(
                    new Error("Photos.ReadFailed", "Could not retrieve stored photo; check server logs."));
            }
        }

        private async Task<PhotoSyncSummaryDto> SyncSelectedUsersAsync(
            List<PhotoUser> users, 
            string[] resolutions, 
            int totalEligibleUsers)
        {
            var summary = new PhotoSyncSummaryDto
            {
                TotalEligibleUsers = totalEligibleUsers,
                ProcessedUsers = users.Count
            };

            if (users.Count == 0)
                return summary;

            // IMPORTANT: Download Graph content concurrently, but do not use EF's DbContext
            // concurrently. EF work happens sequentially after downloads complete.
            List<PhotoDownload> downloads;
            using (var throttle = new SemaphoreSlim(MaxConcurrentGraphCalls))
            {
                var requests = users
                    .SelectMany(u => resolutions.Select(r => DownloadPhotoAsync(u, r, throttle)))
                    .ToArray();

                downloads = (await Task.WhenAll(requests)).ToList();
            }

            var userIds = users.Select(u => u.UserId).ToList();
            var existingPhotos = await _db.DirectoryUserPhotos
                .Where(p => userIds.Contains(p.UserId) && resolutions.Contains(p.Resolution))
                .ToListAsync();

            var existingLookup = existingPhotos.ToDictionary(
                x => PhotoKey(x.UserId, x.Resolution),
                x => x,
                StringComparer.OrdinalIgnoreCase);

            foreach (PhotoDownload download in downloads)
            {
                if (download.Error != null)
                {
                    summary.FailedPhotos++;
                    summary.Errors.Add(new PhotoSyncErrorDto
                    {
                        UserId = download.UserId,
                        Resolution = download.Resolution,
                        Message = "Photo request failed; see application logs."
                    });
                    continue;
                }

                if (download.Bytes == null)
                {
                    summary.MissingPhotos++;
                    // Do not delete an old photo because Graph currently returns 404.
                    continue;
                }

                byte[] hash;
                using (var sha = SHA256.Create())
                    hash = sha.ComputeHash(download.Bytes);

                string key = PhotoKey(download.UserId, download.Resolution);
                DirectoryUserPhoto saved;
                if (!existingLookup.TryGetValue(key, out saved))
                {
                    saved = new DirectoryUserPhoto
                    {
                        UserId = download.UserId,
                        Resolution = download.Resolution,
                        Photo = download.Bytes,
                        ContentType = download.ContentType,
                        PhotoHash = hash,
                        LastSyncedAt = DateTime.UtcNow
                    };
                    _db.DirectoryUserPhotos.Add(saved);
                    existingLookup.Add(key, saved);
                    summary.InsertedPhotos++;
                }
                else if (saved.PhotoHash == null || !saved.PhotoHash.SequenceEqual(hash))
                {
                    saved.Photo = download.Bytes;
                    saved.ContentType = download.ContentType;
                    saved.PhotoHash = hash;
                    saved.LastSyncedAt = DateTime.UtcNow;
                    summary.UpdatedPhotos++;
                }
                else
                {
                    summary.UnchangedPhotos++;
                    // No DB UPDATE needed for identical image bytes.
                }
            }

            // A single EF6 SaveChanges call is transactional for the current batch.
            await _db.SaveChangesAsync();
            return summary;
        }


        private async Task<PhotoDownload> DownloadPhotoAsync(
            PhotoUser user,
            string resolution,
            SemaphoreSlim throttle)
        {
            const int maxAttempts = 3;

            for (int attempt = 1; attempt <= maxAttempts; attempt++)
            {
                Exception failure = null;

                await throttle.WaitAsync();

                try
                {
                    byte[] photo = await _profileImageService
                        .FetchUserPhotoBytesAsync(
                            user.Identifier,
                            resolution);

                    if (photo == null || photo.Length == 0)
                    {
                        return new PhotoDownload
                        {
                            UserId = user.UserId,
                            Resolution = resolution
                        };
                    }

                    if (photo.Length > MaxPhotoSizeBytes)
                    {
                        throw new InvalidOperationException(
                            "Photo exceeds maximum allowed size.");
                    }

                    return new PhotoDownload
                    {
                        UserId = user.UserId,
                        Resolution = resolution,
                        Bytes = photo,
                        ContentType = DetectImageContentType(photo)
                    };
                }
                catch (Exception ex)
                {
                    failure = ex;
                }
                finally
                {
                    throttle.Release();
                }

                // Retry network failures only.
                if (attempt == maxAttempts ||
                    !IsTransientNetworkError(failure))
                {
                    Log.Warning(
                        failure,
                        "Photo download failed permanently. UserId={UserId}, Resolution={Resolution}, Attempt={Attempt}",
                        user.UserId,
                        resolution,
                        attempt);

                    return new PhotoDownload
                    {
                        UserId = user.UserId,
                        Resolution = resolution,
                        Error = failure
                    };
                }

                int delaySeconds = attempt == 1 ? 2 : 5;

                Log.Warning(
                    failure,
                    "Temporary Graph connection failure. UserId={UserId}, Attempt={Attempt}. Retrying in {Delay}s",
                    user.UserId,
                    attempt,
                    delaySeconds);

                await Task.Delay(TimeSpan.FromSeconds(delaySeconds));
            }

            throw new InvalidOperationException(
                "Unexpected photo download state.");
        }

        private static bool IsTransientNetworkError(Exception exception)
        {
            for (Exception ex = exception; ex != null; ex = ex.InnerException)
            {
                if (ex is HttpRequestException ||
                    ex is TaskCanceledException ||
                    ex is TimeoutException)
                {
                    return true;
                }

                var webException = ex as WebException;

                if (webException != null)
                {
                    switch (webException.Status)
                    {
                        case WebExceptionStatus.ConnectFailure:
                        case WebExceptionStatus.ConnectionClosed:
                        case WebExceptionStatus.Timeout:
                        case WebExceptionStatus.SendFailure:
                        case WebExceptionStatus.ReceiveFailure:
                        case WebExceptionStatus.KeepAliveFailure:
                        case WebExceptionStatus.NameResolutionFailure:
                        case WebExceptionStatus.ProxyNameResolutionFailure:
                            return true;
                    }
                }

                var win32 = ex as System.ComponentModel.Win32Exception;

                if (win32 != null &&
                    (win32.NativeErrorCode == 12002 ||
                     win32.NativeErrorCode == 12029 ||
                     win32.NativeErrorCode == 12030 ||
                     win32.NativeErrorCode == 12031))
                {
                    return true;
                }
            }

            return false;
        }


        private static string PhotoKey(long userId, string resolution)
        {
            return userId + "|" + resolution;
        }

        private static string DetectImageContentType(byte[] bytes)
        {
            if (bytes.Length >= 3 && bytes[0] == 0xFF && bytes[1] == 0xD8 && bytes[2] == 0xFF)
                return "image/jpeg";
            if (bytes.Length >= 8 && bytes[0] == 0x89 && bytes[1] == 0x50 &&
                bytes[2] == 0x4E && bytes[3] == 0x47 && bytes[4] == 0x0D &&
                bytes[5] == 0x0A && bytes[6] == 0x1A && bytes[7] == 0x0A)
                return "image/png";
            if (bytes.Length >= 6 && bytes[0] == 0x47 && bytes[1] == 0x49 && bytes[2] == 0x46 && bytes[3] == 0x38)
                return "image/gif";
            throw new InvalidOperationException("Unsupported image data returned from Graph.");
        }

        private sealed class PhotoUser
        {
            public long UserId { get; set; }
            public string Identifier { get; set; }
        }

        private sealed class PhotoDownload
        {
            public long UserId { get; set; }
            public string Resolution { get; set; }
            public byte[] Bytes { get; set; }
            public string ContentType { get; set; }
            public Exception Error { get; set; }
        }
    }
}
