﻿using ADGlobalService.Abstractions;
using ADGlobalService.Models.SyncAdDBDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADGlobalService.Services.SyncAdDB.UserPhotos
{
    public interface IUserPhotosService
    {
        Task<Result<PhotoSyncSummaryDto>> SyncBatchAsync(int page = 1, int pageSize = 50);
        Task<Result<StoredUserPhotoDto>> GetPhotoAsync(long userId, string resolution = "96x96");

        Task<Result<PhotoSyncSummaryDto>> SyncAllAsync(int pageSize = 100);
    }
}
