﻿using ADGlobalService.Abstractions;
using ADGlobalService.Data;
using ADGlobalService.Models.SyncAdDBDtos;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;

namespace ADGlobalService.Services.SyncAdDB
{
    public class GroupsService : IGroupsService
    {
        private readonly ActiveDirectoryDBEntities _db;

        public GroupsService(ActiveDirectoryDBEntities db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));

            _db.Configuration.LazyLoadingEnabled = false;
            _db.Configuration.ProxyCreationEnabled = false;
            _db.Database.CommandTimeout = 60;
        }


        // ============================================
        // GET GROUPS
        // ============================================

        public async Task<Result<GroupsPagedResponseDto>> GetGroupsAsync(
            string search = null,
            string searchField = "all",
            int page = 1,
            int pageSize = 50)
        {
            if (page < 1 || pageSize < 1 || pageSize > 100 ||
                ((long)page - 1) * pageSize > int.MaxValue)
            {
                return Result.Failure<GroupsPagedResponseDto>(
                    new Error(
                        "Groups.InvalidPagination",
                        "Invalid pagination values."));
            }

            IQueryable<DirectoryGroup> groups =
                _db.DirectoryGroups
                    .AsNoTracking()
                    .Where(x => !x.IsDeleted);

            search = (search ?? "").Trim();

            searchField = (searchField ?? "all")
                .Trim()
                .ToLowerInvariant();

            if (!string.IsNullOrWhiteSpace(search))
            {
                switch (searchField)
                {
                    case "name":
                        groups = groups.Where(x =>
                            x.DLName.StartsWith(search));
                        break;

                    case "displayname":
                        groups = groups.Where(x =>
                            x.DLDisplayName.StartsWith(search));
                        break;

                    case "email":
                        groups = groups.Where(x =>
                            x.DLEmail.StartsWith(search));
                        break;

                    case "nt":
                        groups = groups.Where(x =>
                            x.DLNT.StartsWith(search));
                        break;

                    case "alias":
                        groups = groups.Where(x =>
                            x.DLAlias.StartsWith(search));
                        break;

                    case "managedby":
                        groups = groups.Where(x =>
                            x.DLManagedBy.Contains(search));
                        break;

                    case "all":
                        groups = groups.Where(x =>
                            x.DLName.StartsWith(search) ||
                            x.DLDisplayName.StartsWith(search) ||
                            x.DLEmail.StartsWith(search) ||
                            x.DLNT.StartsWith(search) ||
                            x.DLAlias.StartsWith(search));
                        break;

                    default:
                        return Result.Failure<GroupsPagedResponseDto>(
                            new Error(
                                "Groups.InvalidSearchField",
                                "Invalid searchField. Allowed: all, name, " +
                                "displayname, email, nt, alias, managedby."));
                }
            }

            int totalCount = await groups.CountAsync();

            var items = await groups
                .OrderBy(x => x.DLName)
                .ThenBy(x => x.GroupId)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(x => new
                {
                    x.GroupId,
                    x.DLObjectGuid,
                    x.DLName,
                    x.DLDisplayName,
                    x.DLNT,
                    x.DLEmail,
                    x.DLAlias,
                    x.DLDescription,
                    x.DLDistinguishedName,
                    x.DLManagedBy
                })
                .ToListAsync();

            return Result.Success(new GroupsPagedResponseDto
            {
                Items = items,
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize
            });
        }


        // ============================================
        // GET GROUP MEMBERS
        // ============================================

        public async Task<Result<GroupsPagedResponseDto>> GetGroupMembersAsync(
            long groupId,
            int page = 1,
            int pageSize = 50,
            string search = null,
            string searchField = "email")
        {
            if (groupId <= 0 ||
                page < 1 ||
                pageSize < 1 ||
                pageSize > 100 ||
                ((long)page - 1) * pageSize > int.MaxValue)
            {
                return Result.Failure<GroupsPagedResponseDto>(
                    new Error(
                        "Groups.InvalidParameters",
                        "Invalid group or paging parameters."));
            }

            bool groupExists = await _db.DirectoryGroups
                .AsNoTracking()
                .AnyAsync(x =>
                    x.GroupId == groupId &&
                    !x.IsDeleted);

            if (!groupExists)
            {
                return Result.Failure<GroupsPagedResponseDto>(
                    new Error(
                        "Groups.NotFound",
                        "Group not found."));
            }

            IQueryable<DirectoryUser> users = _db.DirectoryUsers
                    .AsNoTracking()
                    .Where(u => !u.IsDeleted && u.DirectoryGroups
                            .Any(g => g.GroupId == groupId));


            search = (search ?? "").Trim();

            searchField = (searchField ?? "email")
                .Trim()
                .ToLowerInvariant();

            if (!string.IsNullOrWhiteSpace(search))
            {
                switch (searchField)
                {
                    case "email":
                        users = users.Where(u =>
                            u.Email.StartsWith(search));
                        break;

                    case "userid":
                        long userId;

                        if (!long.TryParse(search, out userId) ||
                            userId <= 0)
                        {
                            return Result.Failure<GroupsPagedResponseDto>(
                                new Error(
                                    "Groups.InvalidUserId",
                                    "UserId must be a valid positive number."));
                        }

                        users = users.Where(u =>
                            u.UserId == userId);
                        break;

                    default:
                        return Result.Failure<GroupsPagedResponseDto>(
                            new Error(
                                "Groups.InvalidSearchField",
                                "Invalid searchField. Allowed: email, userid."));
                }
            }

            int totalCount = await users.CountAsync();

            var items = await users
                .OrderBy(u => u.DisplayName)
                .ThenBy(u => u.UserId)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(u => new
                {
                    u.UserId,
                    u.DisplayName,
                    u.FullName,
                    u.NT,
                    u.Email,
                    u.Department,
                    u.JobTitle,
                    u.ManagerUserId,
                    u.IsEnabled
                })
                .ToListAsync();

            // Get nested groups (ParentGroupId -> ChildGroupId)
            var nestedGroupsQuery = _db.DirectoryGroups
                .AsNoTracking()
                .Where(g => g.GroupId == groupId)
                .SelectMany(g => g.DirectoryGroups)
                .Where(g => !g.IsDeleted);

            int totalNestedGroups = await nestedGroupsQuery.CountAsync();

            var nestedGroups = await nestedGroupsQuery
                .OrderBy(g => g.DLName)
                .ThenBy(g => g.GroupId)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(g => new NestedGroupDto
                {
                    ParentGroupId = groupId,
                    ChildGroupId = g.GroupId,
                    GroupName = g.DLName,
                    DisplayName = g.DLDisplayName
                })
                .ToListAsync();


            return Result.Success(new GroupsPagedResponseDto
            {
                Items = items,
                TotalCount = totalCount,
                Page = page,
                PageSize = pageSize,

                NestedGroups = nestedGroups,
                TotalNestedGroups = totalNestedGroups


            });
        }
    }

    public class NestedGroupDto
    {
        public long ParentGroupId { get; set; }
        public long ChildGroupId { get; set; }
        public string GroupName { get; set; }
        public string DisplayName { get; set; }
    }
}