﻿using ADGlobalService.Abstractions;
using ADGlobalService.Models.SyncAdDBDtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADGlobalService.Services.SyncAdDB
{
    public interface IGroupsService
    {
        Task<Result<GroupsPagedResponseDto>> GetGroupsAsync(
           string search = null,
           string searchField = "all",
           int page = 1,
           int pageSize = 50);

        Task<Result<GroupsPagedResponseDto>> GetGroupMembersAsync(
            long groupId,
            int page = 1,
            int pageSize = 50,
            string search = null,
            string searchField = "email");
    }
}
