﻿using ActiveDirectory.DTOs;
using ADGlobalService.Abstractions;
using ADGlobalService.Models.SyncAdDBDtos;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ADGlobalService.Services.SyncAdDB
{
    public interface ISyncAdDBService : IDisposable
    {
        Task<Result<JArray>> GetMembersFromAdAsync(string department);

        Task<Result<DirectorySyncSummaryDto>> SyncDirectoryChangesAsync();



        Task<Result<List<DirectoryUserHierarchyNode>>> GetUsersByDepartmentAsync(
             string department = null,
             bool hierarchical = false);


        Task<Result<object>> GetDepartmentChangesAsync(string department);

        Task<Result<PagedResultDto<DirectoryUserItemDto>>> SearchUsersAsync(
             string search,
             string searchField = "all",
             string department = null,
             int page = 1,
             int pageSize = 20);

        Task<Result<List<DirectoryUserItemDto>>> GetUserAncestorsAsync(
            long userId);


        Task<Result<PagedResultDto<DirectoryUserItemDto>>> GetDirectReportsAsync(
                long managerUserId,
                int page = 1,
                int pageSize = 20,
                string department = null);


        Task<Result<PagedResultDto<DirectoryUserItemDto>>> GetRootUsersAsync(
            string department = null,
            int page = 1,
            int pageSize = 20);


        Task<Result<PagedResultDto<DirectoryUserItemDto>>> GetDirectoryUsersAsync(
                string search = null,
                string department = null,
                string subDepartment = null,
                bool? isEnabled = null,
                int page = 1,
                int pageSize = 50,
                string searchField = "all");


        Task<Result<DirectoryUserItemDto>> GetHierarchyRootAsync();
        Task<Result<List<DirectoryDepartmentDto>>> GetDepartmentsAsync();

        Task<Result<DirectoryUserDetailsDto>> GetUserByIdAsync(
            long userId);



        Task<Result<DirectoryUpsertSummaryDto>> UpsertDirectoryUsersAsync(
            JArray adUsers);


        Task<Result<List<DirectoryUserItemDto>>> GetHierarchyChildrenAsync(long userId);


        Task<Result<DirectoryDepartmentResponseDto>> GetUsersByDepartmentAsync(
                string department,
                bool hierarchical,
                string direction,
                string email);

        Task<Result<PagedResultDto<DirectoryUserDto>>> SearchDirectoryUsersAsync(
          string search,
          string searchField,
          int page,
          int pageSize,
          string relations = "none");

        Task<Result<List<DepartmentWithSubDepartmentsDto>>> GetDepartmentsWithSubDepartmentsAsync(
            string department = null);

        Task<Result<GroupsUpsertSummaryDto>> SyncGroupsAsync();

        Task<Result<SoftDeleteSyncDto>> SyncDeletedObjectsAsync(
          bool dryRun = true);
    }
}
