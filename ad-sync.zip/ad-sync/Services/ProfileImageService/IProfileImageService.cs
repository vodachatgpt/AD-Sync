﻿using ADGlobalService.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ADGlobalService.Services.ProfileImageService
{
    public interface IProfileImageService
    {
        Task<string> FetchUserPhotoBase64Async(
            string email,
            string resolution);

        Task PopulateImagesParallelAsync(
            IEnumerable<ActiveDirectoryMember> members,
            string resolution);


        Task<byte[]> FetchUserPhotoBytesAsync(string userPrincipalName, string resolution);

    }
}
