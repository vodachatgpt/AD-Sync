﻿using ADGlobalService.Models;
using ADGlobalService.Services.GraphClientFactory;
using Microsoft.Graph;
using Microsoft.Kiota.Abstractions;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace ADGlobalService.Services.ProfileImageService
{
    public class ProfileImageService : IProfileImageService
    {
        private readonly IGraphClientFactory _graphClientFactory;
        private readonly GraphServiceClient _graphClient;
        private static readonly HashSet<string> _validResolutions = new HashSet<string>(StringComparer.OrdinalIgnoreCase)
        {
            "48x48",
            "64x64",
            "96x96",
            "120x120",
            "240x240",
            "360x360",
            "432x432",
            "504x504",
            "648x648"
        };

        public ProfileImageService(IGraphClientFactory graphClientFactory)
        {
            if (graphClientFactory == null)
                throw new ArgumentNullException(nameof(graphClientFactory));

            _graphClient = graphClientFactory.CreateAppClient();
        }
        public async Task<string> FetchUserPhotoBase64Async(string email, string resolution)
        {
            try
            {
                Stream photoStream;
               //var graphClient = _graphClientFactory.CreateAppClient();

                if (string.IsNullOrEmpty(resolution))
                {
                    photoStream = await _graphClient.Users[email]
                                       .Photo
                                       .Content
                                       .GetAsync();
                }
                else
                {
                    if (!_validResolutions.Contains(resolution))
                    {
                        resolution = "48x48";
                    }
                    photoStream = await _graphClient.Users[email]
                                       .Photos[resolution]
                                       .Content
                                       .GetAsync();
                }

                if (photoStream != null)
                {
                    using (var memoryStream = new MemoryStream())
                    {
                        await photoStream.CopyToAsync(memoryStream);
                        byte[] photoBytes = memoryStream.ToArray();
                        return Convert.ToBase64String(photoBytes);
                    }
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }

            return null;
        }


        public async Task PopulateImagesParallelAsync(IEnumerable<ActiveDirectoryMember> members, string resolution)
        {
            var eligibleMembers = members.Where(m => m != null && !string.IsNullOrEmpty(m.Email)).ToList();

            var tasks = eligibleMembers.Select(async member =>
            {
                member.PhotoBase64 = await FetchUserPhotoBase64Async(member.Email, resolution);
                member.HasPhoto = !string.IsNullOrEmpty(member.PhotoBase64);
            });

            await Task.WhenAll(tasks);
        }


        public async Task<byte[]> FetchUserPhotoBytesAsync(
            string userPrincipalName,
            string resolution)
        {
            if (string.IsNullOrWhiteSpace(userPrincipalName))
            {
                throw new ArgumentException(
                    "User principal name is required.",
                    nameof(userPrincipalName));
            }

            if (!string.IsNullOrWhiteSpace(resolution) &&
                !_validResolutions.Contains(resolution))
            {
                throw new ArgumentException(
                    "Unsupported image resolution.",
                    nameof(resolution));
            }

            try
            {
                using (Stream stream = string.IsNullOrWhiteSpace(resolution)
                    ? await _graphClient.Users[userPrincipalName]
                        .Photo.Content.GetAsync()
                    : await _graphClient.Users[userPrincipalName]
                        .Photos[resolution].Content.GetAsync())
                {
                    if (stream == null)
                    {
                        return null;

                    }

                    using (var memory = new MemoryStream())
                    {
                        await stream.CopyToAsync(memory);

                        return memory.Length == 0
                            ? null
                            : memory.ToArray();
                    }
                }
            }
            catch (ApiException ex) when (ex.ResponseStatusCode == 404)
            {
                // User does not have a photo.
                return null;
            }

            // Other exceptions propagate to DownloadPhotoAsync
            // where transient network failures can be retried.
        }


    }
}