using ADGlobalService.Models;
using Serilog;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.DirectoryServices.Protocols;
using System.Globalization;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Web.Configuration;
using System.Web.Script.Serialization;
using System.Web.Security;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    /// <summary>
    /// V2 sync. It shares the LDAP paging-session manager with the legacy API,
    /// while scoping page tokens to v2 and protecting durable checkpoints.
    /// </summary>
    public sealed class DirectoryIncrementalSyncService : IDirectoryIncrementalSyncService
    {
        private const string ContractVersion = "2";

        private const string TokenPurpose = "ADGlobalService.DirectorySync.V2";
        private static readonly string[] Attributes = new[]
        {
            "objectGUID", "userAccountControl", "whenChanged", "sAMAccountName",
            "userPrincipalName", "mail", "displayName", "fullname",
            "department", "jobTitle", "mobile", "extensionattribute1", "extensionAttribute10",
            "gweinternaluser"
        };

        private readonly DirectorySyncPager _pager;
        private string _baseDn;
        private string _domainController;
        private string _domainName;
        private NetworkCredential _credentials;
        private readonly ConcurrentDictionary<Guid, SyncRunState> _runs =
            new ConcurrentDictionary<Guid, SyncRunState>();

        public DirectoryIncrementalSyncService(DirectorySyncPager pager)
        {
            _pager = pager;
        }

        private void EnsureConfigured()
        {
            if (_credentials != null) return;
            string ldapUrl = WebConfigurationManager.AppSettings["ADFUrl"];
            string user = WebConfigurationManager.AppSettings["ADLoginUser"];
            string password = WebConfigurationManager.AppSettings["ADLoginPass"];
            _domainController = WebConfigurationManager.AppSettings["DirectorySyncDomainController"];
            if (string.IsNullOrWhiteSpace(ldapUrl) || string.IsNullOrWhiteSpace(user)
                || string.IsNullOrWhiteSpace(password) || string.IsNullOrWhiteSpace(_domainController))
            {
                throw new InvalidOperationException(
                    "ADFUrl, ADLoginUser, ADLoginPass, and DirectorySyncDomainController must be configured for v2 directory synchronization.");
            }

            _baseDn = ldapUrl.StartsWith("LDAP://", StringComparison.OrdinalIgnoreCase)
                ? ldapUrl.Substring("LDAP://".Length) : ldapUrl;
            _baseDn = _baseDn.Trim().Trim('/');
            var components = _baseDn.Split(',').Select(x => x.Trim())
                .Where(x => x.StartsWith("DC=", StringComparison.OrdinalIgnoreCase))
                .Select(x => x.Substring(3)).ToArray();
            if (components.Length == 0)
                throw new InvalidOperationException("ADFUrl must contain a valid distinguished-name search scope.");

            _domainName = string.Join(".", components);
            _credentials = new NetworkCredential(user, password, _domainName);
        }

        public Task<DirectoryIncrementalSyncPage> GetUsersForSyncAsync(
            int pageSize = 500, string pageToken = null,
            DirectorySyncAudience audience = DirectorySyncAudience.All)
        {
            return ReadAsync(SyncMode.Full, null, pageSize, pageToken, audience);
        }

        public Task<DirectoryIncrementalSyncPage> GetChangedUsersAsync(
            string syncToken, int pageSize = 500, string pageToken = null,
            DirectorySyncAudience audience = DirectorySyncAudience.All)
        {
            if (pageToken != null && !string.IsNullOrWhiteSpace(syncToken))
                throw new ArgumentException("syncToken cannot be supplied when continuing with pageToken.", nameof(syncToken));
            if (pageToken == null && string.IsNullOrWhiteSpace(syncToken))
                throw new ArgumentException("syncToken is required when starting an incremental synchronization.", nameof(syncToken));
            return ReadAsync(SyncMode.Incremental, syncToken, pageSize, pageToken, audience);
        }

        private async Task<DirectoryIncrementalSyncPage> ReadAsync(
            SyncMode mode, string syncToken, int pageSize, string pageToken,
            DirectorySyncAudience audience)
        {
            EnsureConfigured();
            if (pageToken != null && (string.IsNullOrWhiteSpace(pageToken) || pageToken.Length > 256))
                throw new ArgumentException("Invalid pageToken.", nameof(pageToken));

            CleanupRuns();
            if (pageToken != null)
            {
                if (audience != DirectorySyncAudience.All)
                    throw new ArgumentException("The audience cannot change while continuing with pageToken.", nameof(audience));
                string sessionPurpose = GetPageTokenPurpose(pageToken);
                var continuedPage = await _pager.ReadPageAsync(
                    () => { throw new InvalidOperationException("A page token must reference an existing session."); },
                    pageSize, pageToken, sessionPurpose).ConfigureAwait(false);
                SyncRunState continuedRun;
                if (!_runs.TryGetValue(continuedPage.SyncRunId, out continuedRun))
                    throw new DirectorySyncExpiredException();
                continuedRun.ExpiresAtUtc = continuedPage.ExpiresAtUtc;
                return ToV2Page(continuedPage, continuedRun.CompletedSyncToken);
            }

            var metadata = await ReadDirectoryMetadataAsync().ConfigureAwait(false);
            long lowerExclusive = 0;
            if (mode == SyncMode.Incremental)
            {
                var checkpoint = UnprotectCheckpoint(syncToken);
                ValidateCheckpoint(checkpoint, metadata, audience);
                lowerExclusive = checkpoint.HighestCommittedUsn;
            }

            long upperInclusive = metadata.HighestCommittedUsn;
            // The full pass deliberately has no USN upper bound. Objects modified while
            // it is being enumerated are still imported with their current values; the
            // watermark captured above remains the lower bound for the next delta.
            string filter = mode == SyncMode.Full
                ? DirectorySyncFilterFactory.CreateUserFilter(audience)
                : DirectorySyncFilterFactory.CreateIncrementalFilter(lowerExclusive, upperInclusive, audience);
            string completedSyncToken = ProtectCheckpoint(new DirectorySyncCheckpoint
            {
                ContractVersion = ContractVersion,
                DomainController = Normalize(_domainController),
                InvocationId = metadata.InvocationId,
                SearchBase = _baseDn,
                Audience = audience.ToString(),
                HighestCommittedUsn = upperInclusive
            });

            var page = await _pager.ReadPageAsync(
                () => new LdapDirectorySyncReader(_domainController, _baseDn, _credentials,
                    Attributes, pageSize, MapUser, filter),
                pageSize, null, DirectorySyncAudienceParser.ToPageTokenPurpose(audience)).ConfigureAwait(false);
            var run = new SyncRunState { CompletedSyncToken = completedSyncToken, ExpiresAtUtc = page.ExpiresAtUtc };
            _runs[page.SyncRunId] = run;
            return ToV2Page(page, run.CompletedSyncToken);
        }

        private static DirectoryIncrementalSyncPage ToV2Page(DirectorySyncPage page, string completedSyncToken)
        {
            return new DirectoryIncrementalSyncPage
            {
                SyncRunId = page.SyncRunId,
                SyncStartedAtUtc = page.SyncStartedAtUtc,
                ExpiresAtUtc = page.ExpiresAtUtc,
                Items = page.Items.Select(MapToContract).ToList(),
                NextPageToken = page.NextPageToken,
                CompletedSyncToken = page.HasMore ? null : completedSyncToken
            };
        }

        internal static DirectoryIncrementalSyncUser MapToContract(DirectorySyncUser user)
        {
            return new DirectoryIncrementalSyncUser
            {
                DirectoryObjectId = user.AdObjectGuid,
                UserName = user.Profile.NTAccount,
                UserPrincipalName = user.Profile.UserPrincipalName,
                Email = user.Profile.Email,
                DisplayName = user.Profile.DisplayName,
                AdFullName = user.Profile.FullName,
                Department = user.Profile.Department,
                JobTitle = user.Profile.JobTitle,
                Mobile = user.Profile.Mobile,
                StaffId = user.Profile.StaffId,
                SapId = user.Profile.SapId,
                EmploymentType = user.Profile.EmploymentType,
                IsInternalUser = user.Profile.IsInternalUser,
                IsEnabled = user.IsEnabled,
                ModifiedAt = user.AdLastModifiedAtUtc
            };
        }

        private DirectorySyncUser MapUser(SearchResultEntry entry)
        {
            byte[] objectGuid = GetBytes(entry, "objectGUID");
            int accountControl;
            if (objectGuid == null || objectGuid.Length != 16
                || !int.TryParse(GetString(entry, "userAccountControl"), out accountControl))
            {
                Log.Warning(
                    "Skipping directory user with missing identity or account status during incremental sync. DistinguishedName: {DistinguishedName}, HasObjectGuid: {HasObjectGuid}, UserAccountControl: {UserAccountControl}",
                    entry.DistinguishedName,
                    objectGuid != null && objectGuid.Length == 16,
                    GetString(entry, "userAccountControl"));
                return null;
            }

            string upn = TrimOrNull(GetString(entry, "userPrincipalName"));
            string mail = TrimOrNull(GetString(entry, "mail"));
            bool isInternalUser = string.Equals(
                GetString(entry, "gweinternaluser"), "True", StringComparison.OrdinalIgnoreCase);
            return new DirectorySyncUser
            {
                AdObjectGuid = new Guid(objectGuid),
                IsEnabled = (accountControl & 0x0002) == 0,
                AdLastModifiedAtUtc = ParseWhenChanged(GetString(entry, "whenChanged")),
                Profile = new ActiveDirectoryMember
                {
                    NTAccount = GetString(entry, "sAMAccountName"),
                    UserPrincipalName = upn,
                    Email = mail ?? upn,
                    DisplayName = GetString(entry, "displayName"),
                    FullName = GetString(entry, "fullname"),
                    Department = GetString(entry, "department"),
                    JobTitle = GetString(entry, "jobTitle"),
                    Mobile = GetString(entry, "mobile"),
                    StaffId = GetString(entry, "extensionattribute1"),
                    SapId = GetString(entry, "extensionAttribute10"),
                    EmploymentType = isInternalUser ? EmploymentType.Internal.ToString() : EmploymentType.Outsource.ToString(),
                    IsInternalUser = isInternalUser
                }
            };
        }

        private async Task<DirectoryMetadata> ReadDirectoryMetadataAsync()
        {
            using (var connection = CreateConnection(_domainController))
            {
                var rootDse = await SendSearchAsync(connection, new SearchRequest("", "(objectClass=*)",
                    SearchScope.Base, new[] { "dsServiceName", "highestCommittedUSN" })).ConfigureAwait(false);
                if (rootDse == null || rootDse.ResultCode != ResultCode.Success || rootDse.Entries.Count != 1)
                    throw new InvalidOperationException("The configured domain controller did not return synchronization metadata.");

                var rootEntry = rootDse.Entries[0];
                var rootMetadata = DirectorySyncMetadataParser.ParseRootDse(
                    GetString(rootEntry, "dsServiceName"), GetString(rootEntry, "highestCommittedUSN"));

                var ntdsSettings = await SendSearchAsync(connection, new SearchRequest(
                    rootMetadata.NtdsSettingsDistinguishedName, "(objectClass=*)", SearchScope.Base,
                    new[] { "invocationID" })).ConfigureAwait(false);
                if (ntdsSettings == null || ntdsSettings.ResultCode != ResultCode.Success || ntdsSettings.Entries.Count != 1)
                    throw new InvalidOperationException("The domain controller did not return its NTDS Settings object.");

                return new DirectoryMetadata
                {
                    InvocationId = DirectorySyncMetadataParser.ParseInvocationId(
                        GetBytes(ntdsSettings.Entries[0], "invocationID")),
                    HighestCommittedUsn = rootMetadata.HighestCommittedUsn
                };
            }
        }

        private static async Task<SearchResponse> SendSearchAsync(LdapConnection connection, SearchRequest request)
        {
            return (SearchResponse)await Task.Factory.FromAsync(
                (callback, state) => connection.BeginSendRequest(request,
                    PartialResultProcessing.NoPartialResultSupport, callback, state),
                result => connection.EndSendRequest(result), null).ConfigureAwait(false);
        }

        private LdapConnection CreateConnection(string server)
        {
            var connection = new LdapConnection(server);
            connection.Credential = _credentials;
            connection.AuthType = AuthType.Kerberos;
            connection.Timeout = TimeSpan.FromSeconds(60);
            connection.SessionOptions.ProtocolVersion = 3;
            connection.SessionOptions.Signing = true;
            connection.SessionOptions.Sealing = true;
            connection.SessionOptions.AutoReconnect = false;
            connection.SessionOptions.ReferralChasing = ReferralChasingOptions.None;
            return connection;
        }

        private void ValidateCheckpoint(
            DirectorySyncCheckpoint checkpoint, DirectoryMetadata metadata, DirectorySyncAudience audience)
        {
            if (checkpoint == null || checkpoint.ContractVersion != ContractVersion)
                throw new DirectorySyncResyncRequiredException("The synchronization checkpoint is from an incompatible contract version.");
            string checkpointAudience = string.IsNullOrWhiteSpace(checkpoint.Audience)
                ? DirectorySyncAudience.All.ToString()
                : checkpoint.Audience;
            if (!string.Equals(checkpointAudience, audience.ToString(), StringComparison.Ordinal))
                throw new DirectorySyncResyncRequiredException(
                    "The synchronization checkpoint was created for a different audience. Run a full import for the selected audience.");
            if (!string.Equals(checkpoint.DomainController, Normalize(_domainController), StringComparison.Ordinal)
                || !string.Equals(checkpoint.SearchBase, _baseDn, StringComparison.OrdinalIgnoreCase)
                || checkpoint.InvocationId != metadata.InvocationId
                || checkpoint.HighestCommittedUsn > metadata.HighestCommittedUsn)
            {
                throw new DirectorySyncResyncRequiredException(
                    "The synchronization checkpoint no longer matches this directory controller or search scope. Run a full import.");
            }
        }

        private static string ProtectCheckpoint(DirectorySyncCheckpoint checkpoint)
        {
            byte[] plainText = Encoding.UTF8.GetBytes(new JavaScriptSerializer().Serialize(checkpoint));
            return ToBase64Url(MachineKey.Protect(plainText, TokenPurpose, ContractVersion));
        }

        private static DirectorySyncCheckpoint UnprotectCheckpoint(string syncToken)
        {
            try
            {
                byte[] protectedBytes = FromBase64Url(syncToken);
                byte[] plainText = MachineKey.Unprotect(protectedBytes, TokenPurpose, ContractVersion);
                if (plainText == null) throw new ArgumentException();
                return new JavaScriptSerializer().Deserialize<DirectorySyncCheckpoint>(Encoding.UTF8.GetString(plainText));
            }
            catch (Exception ex) when (ex is FormatException || ex is CryptographicException
                || ex is ArgumentException || ex is InvalidOperationException)
            {
                throw new ArgumentException("Invalid syncToken.", nameof(syncToken));
            }
        }

        private void CleanupRuns()
        {
            DateTime now = DateTime.UtcNow;
            foreach (var pair in _runs.Where(x => x.Value.ExpiresAtUtc <= now))
            {
                SyncRunState ignored;
                _runs.TryRemove(pair.Key, out ignored);
            }
        }

        private static DateTime? ParseWhenChanged(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            DateTime result;
            if (!DateTime.TryParseExact(value, new[] { "yyyyMMddHHmmss.FFFFFFF'Z'", "yyyyMMddHHmmss'Z'" },
                CultureInfo.InvariantCulture, DateTimeStyles.AssumeUniversal | DateTimeStyles.AdjustToUniversal, out result))
                throw new InvalidOperationException("A directory user has an invalid modification timestamp.");
            return result;
        }

        private static string GetString(SearchResultEntry entry, string name)
        {
            if (entry == null || !entry.Attributes.Contains(name) || entry.Attributes[name].Count != 1) return null;
            object value = entry.Attributes[name][0];
            return value == null ? null : value.ToString();
        }

        private static byte[] GetBytes(SearchResultEntry entry, string name)
        {
            if (entry == null || !entry.Attributes.Contains(name) || entry.Attributes[name].Count != 1) return null;
            return entry.Attributes[name][0] as byte[];
        }

        private static string TrimOrNull(string value)
        {
            return string.IsNullOrWhiteSpace(value) ? null : value.Trim();
        }

        private static string Normalize(string value)
        {
            return value.Trim().ToLowerInvariant();
        }

        private static string GetPageTokenPurpose(string pageToken)
        {
            int separator = pageToken == null ? -1 : pageToken.IndexOf('.');
            if (separator <= 0)
                throw new ArgumentException("Invalid pageToken.", nameof(pageToken));

            DirectorySyncAudience audience;
            if (!DirectorySyncAudienceParser.TryParsePageTokenPurpose(
                pageToken.Substring(0, separator), out audience))
            {
                throw new ArgumentException("Invalid pageToken.", nameof(pageToken));
            }
            return DirectorySyncAudienceParser.ToPageTokenPurpose(audience);
        }

        private static string ToBase64Url(byte[] bytes)
        {
            return Convert.ToBase64String(bytes).TrimEnd('=').Replace('+', '-').Replace('/', '_');
        }

        private static byte[] FromBase64Url(string value)
        {
            if (string.IsNullOrWhiteSpace(value)) throw new FormatException();
            string padded = value.Replace('-', '+').Replace('_', '/');
            padded = padded.PadRight(padded.Length + ((4 - padded.Length % 4) % 4), '=');
            return Convert.FromBase64String(padded);
        }

        private enum SyncMode { Full, Incremental }
        private sealed class DirectoryMetadata { public Guid InvocationId; public long HighestCommittedUsn; }
        private sealed class SyncRunState { public string CompletedSyncToken; public DateTime ExpiresAtUtc; }
        private sealed class DirectorySyncCheckpoint
        {
            public string ContractVersion { get; set; }
            public string DomainController { get; set; }
            public Guid InvocationId { get; set; }
            public string SearchBase { get; set; }
            public long HighestCommittedUsn { get; set; }
            public string Audience { get; set; }
        }
    }

    public sealed class DirectorySyncResyncRequiredException : Exception
    {
        public DirectorySyncResyncRequiredException(string message) : base(message) { }
    }
}
