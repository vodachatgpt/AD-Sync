using ADGlobalService.DependencyInjectionConfigs;
using ADGlobalService.Models;
using ADGlobalService.Models.SyncAdDBDtos;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    public interface IActiveDirectoryService : IInjectable
    {
        Task<bool> IsUserInGroupAsync(string groupName, string accountIdentifier, IdentifierType type);
        Task<IEnumerable<ActiveDirectoryMember>> GetGroupMembers(string identifier, IdentifierType type, bool includeProfileImage = false, string imageResolution = "48x48");
        Task<string> GetGroupNameByEmailAsync(string email);
        Task<string> GetEmailByGroupNameAsync(string groupName);
        Task<ActiveDirectoryMember> GetUserAsync(
            string identifier,
            FilterType filterType,
            bool includeExtendedData = true,
            bool includeProfileImage = false,
            string imageResolution = null,
            bool includeGroubMail = false);

        Task<ActiveDirectoryMember> FindUserAsync(string searchQuery,
            bool includeExtendedData = true,
            bool includeProfileImage = false,
            string imageResolution = "48x48",
            bool includeGroubMail = false);
        Task<ActiveDirectoryMemberV2> GetUserSelectiveAsync(
            string identifier,
            UserIdentifierType identifierType,
            IEnumerable<UserField> fieldsToLoad,
            bool includeDls = false,
            bool includeDlEmails = false,
            bool includeSubordinates = false);

        Task<IEnumerable<string>> GetAllDepartmentsAsync();
        Task<IEnumerable<string>> GetSubDepartmentsAsync(string parentDepartment);
        Task<IEnumerable<ActiveDirectoryMember>> GetMembersByDepartmentAsync(string department);
        Task<IEnumerable<ActiveDirectoryMember>> GetNewHiresAsync(DateTime? date = null);
        Task<List<ActiveDirectoryMember>> SearchUsersForAutocompleteAsync(
            string searchQuery,
            int limit = 5,
            bool includeProfileImage = false,
            string imageResolution = "48x48"
            );
        Task<IEnumerable<string>> GetAllOUsAsync();
        Task<Dictionary<string, ActiveDirectoryMember>> GetManagersByEmailsAsync(List<string> employeeEmails, bool includeProfileImage = false, string imageResolution = "48x48");
        Task<Dictionary<string, ActiveDirectoryMember>> GetHodsByEmailsAsync(List<string> employeeEmails, bool includeProfileImage = false, string imageResolution = "48x48");
        Task<AccountStatusInfo> GetAccountStatusAsync(string userIdentifier);
        Task<bool> AddUserToGroupAsync(string userIdentifier, string groupIdentifier);
        Task<bool> RemoveUserFromGroupAsync(string userIdentifier, string groupIdentifier);
        Task<List<string>> GetUserDistributionListEmailsAsync(string userEmail);
        Task<List<string>> GetUserDirectDistributionListEmailsAsync(string userIdentifier);
        Task<Dictionary<string, object>> GetUserRawAttributesAsync(string userIdentifier);
        Task<bool> UpdateUserAttributeAsync(string userIdentifier, string attributeName, string value);
        Task<bool> EnableUserAccountAsync(string userIdentifier);
        Task<bool> UnlockUserAccountAsync(string userIdentifier);
        Task<List<ActiveDirectoryGroup>> SearchGroupsAsync(
           string query,
           int limit = 10,
           string groupType = null);
        Task<string> GetUserGenderAsync(string identifier);
        Task<DirectorySyncPage> GetUsersForSyncAsync(int pageSize = 500, string pageToken = null, string sessionPurpose = "legacy");
        Task<IEnumerable<ActiveDirectoryMember>> GetAllHodsAsync(
            HodFilter filters = null,
            bool includeProfileImage = false,
            string imageResolution = "96x96");
        Task<IEnumerable<ActiveDirectoryMember>> GetAllExcoAsync(
    HodFilter filters = null,
    bool includeProfileImage = false,
    string imageResolution = "96x96");


        Task<AdChangedGroupsResponseDto> GetChangedGroupsAsync(
                    long fromUsn,
                    string domainControllerName = null);

        Task<AdChangedUsersResponseDto> GetChangedUsersAsync(
           long fromUsn,
           string domainControllerName = null);


        Task<AdUsnInfoDto> GetAdUsnInfoAsync();

        Task<List<Dictionary<string, object>>> GetUsersRawAttributesByDepartmentAsync(string department);
        Task<AdExistingGuidsDto> GetExistingAdGuidsAsync(
            List<Guid> userGuids,
            List<Guid> groupGuids);

    }


}
