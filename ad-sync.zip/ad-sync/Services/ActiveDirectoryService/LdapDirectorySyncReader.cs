using ADGlobalService.Models;
using System;
using System.DirectoryServices.Protocols;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    internal sealed class LdapDirectorySyncReader : IDirectorySyncReader
    {
        private readonly LdapConnection _connection;
        private readonly SearchRequest _request;
        private readonly PageResultRequestControl _paging;
        private readonly Func<SearchResultEntry, DirectorySyncUser> _mapUser;

        public LdapDirectorySyncReader(string domainName, string baseDn, NetworkCredential credentials,
            string[] attributes, int pageSize, Func<SearchResultEntry, DirectorySyncUser> mapUser,
            string filter = "(&(objectCategory=person)(objectClass=user))")
        {
            _mapUser = mapUser;
            _connection = new LdapConnection(domainName);
            _connection.Credential = credentials;
            _connection.AuthType = AuthType.Kerberos;
            _connection.Timeout = TimeSpan.FromSeconds(60);
            _connection.SessionOptions.ProtocolVersion = 3;
            _connection.SessionOptions.Signing = true;
            _connection.SessionOptions.Sealing = true;
            _connection.SessionOptions.AutoReconnect = false;
            _connection.SessionOptions.ReferralChasing = ReferralChasingOptions.None;

            // The caller supplies the scope filter. The legacy default includes enabled
            // and disabled human accounts, while excluding computers.
            _request = new SearchRequest(baseDn, filter, SearchScope.Subtree, attributes);
            _request.TimeLimit = TimeSpan.FromSeconds(60);
            _paging = new PageResultRequestControl(pageSize) { IsCritical = true };
            _request.Controls.Add(_paging);
        }

        public async Task<DirectorySyncBatch> ReadAsync(byte[] cookie)
        {
            _paging.Cookie = cookie;
            var response = (SearchResponse)await Task.Factory.FromAsync(
                (callback, state) => _connection.BeginSendRequest(
                    _request, PartialResultProcessing.NoPartialResultSupport, callback, state),
                result => _connection.EndSendRequest(result), null).ConfigureAwait(false);

            if (response == null || response.ResultCode != ResultCode.Success)
                throw new InvalidOperationException("The directory did not return a complete successful page.");

            var pagingResponse = response.Controls.OfType<PageResultResponseControl>().SingleOrDefault();
            if (pagingResponse == null)
                throw new InvalidOperationException("The directory did not confirm paged results.");

            return new DirectorySyncBatch
            {
                Items = response.Entries.Cast<SearchResultEntry>()
                    .Select(_mapUser)
                    .Where(user => user != null)
                    .ToList(),
                Cookie = pagingResponse.Cookie ?? new byte[0]
            };
        }

        public void Dispose()
        {
            _connection.Dispose();
        }
    }
}
