using System;
using System.Globalization;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    internal static class DirectorySyncFilterFactory
    {
        internal const string UserFilter = "(&(objectCategory=person)(objectClass=user))";

        internal static string CreateUserFilter(DirectorySyncAudience audience)
        {
            return "(&(objectCategory=person)(objectClass=user)" + CreateAudienceClause(audience) + ")";
        }

        internal static string CreateIncrementalFilter(
            long lastCommittedUsn, long upperCommittedUsn, DirectorySyncAudience audience)
        {
            if (lastCommittedUsn < 0 || upperCommittedUsn < lastCommittedUsn)
                throw new ArgumentOutOfRangeException(nameof(lastCommittedUsn));

            // LDAP supports >= and <=, but not a standalone > operator.
            // A zero-width USN interval is represented by a guaranteed-empty filter.
            if (lastCommittedUsn == long.MaxValue || lastCommittedUsn == upperCommittedUsn)
                return "(!(objectClass=*))";

            return string.Format(CultureInfo.InvariantCulture,
                "(&(objectCategory=person)(objectClass=user){0}(uSNChanged>={1})(uSNChanged<={2}))",
                CreateAudienceClause(audience), lastCommittedUsn + 1, upperCommittedUsn);
        }

        private static string CreateAudienceClause(DirectorySyncAudience audience)
        {
            switch (audience)
            {
                case DirectorySyncAudience.Internal:
                    return "(gweinternaluser=True)";
                case DirectorySyncAudience.Outsource:
                    // Keep the filtering consistent with the existing profile mapping:
                    // only an explicit True value represents an internal user.
                    return "(!(gweinternaluser=True))";
                case DirectorySyncAudience.All:
                    return string.Empty;
                default: throw new ArgumentOutOfRangeException(nameof(audience));
            }
        }
    }
}
