using ADGlobalService.DependencyInjectionConfigs;
using ADGlobalService.Models;
using System.Threading.Tasks;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    public interface IDirectoryIncrementalSyncService : IInjectable
    {
        Task<DirectoryIncrementalSyncPage> GetUsersForSyncAsync(
            int pageSize = 500, string pageToken = null,
            DirectorySyncAudience audience = DirectorySyncAudience.All);

        Task<DirectoryIncrementalSyncPage> GetChangedUsersAsync(
            string syncToken, int pageSize = 500, string pageToken = null,
            DirectorySyncAudience audience = DirectorySyncAudience.All);
    }
}
