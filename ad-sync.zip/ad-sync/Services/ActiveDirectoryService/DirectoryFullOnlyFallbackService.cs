using ADGlobalService.DependencyInjectionConfigs;
using ADGlobalService.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    public interface IDirectoryFullOnlyFallbackService : IInjectable
    {
        bool IsEnabled { get; }
        Task<DirectoryIncrementalSyncPage> GetUsersForSyncAsync(int pageSize, string pageToken);
    }

    public sealed class DirectoryFullOnlyFallbackService : IDirectoryFullOnlyFallbackService
    {
        private readonly IActiveDirectoryService _legacySyncService;

        public DirectoryFullOnlyFallbackService(IActiveDirectoryService legacySyncService)
        {
            _legacySyncService = legacySyncService;
        }

        public bool IsEnabled
        {
            get
            {
                return string.IsNullOrWhiteSpace(
                    WebConfigurationManager.AppSettings["DirectorySyncDomainController"]);
            }
        }

        public async Task<DirectoryIncrementalSyncPage> GetUsersForSyncAsync(int pageSize, string pageToken)
        {
            DirectorySyncPage page = await _legacySyncService
                .GetUsersForSyncAsync(pageSize, pageToken, "v2fullonly").ConfigureAwait(false);

            return new DirectoryIncrementalSyncPage
            {
                SyncRunId = page.SyncRunId,
                SyncStartedAtUtc = page.SyncStartedAtUtc,
                ExpiresAtUtc = page.ExpiresAtUtc,
                Items = page.Items.Select(DirectoryIncrementalSyncService.MapToContract).ToList(),
                NextPageToken = page.NextPageToken,
                // The legacy reader has no DC-pinned watermark. Do not issue an
                // incremental checkpoint until a specific DC is configured.
                CompletedSyncToken = null
            };
        }
    }
}