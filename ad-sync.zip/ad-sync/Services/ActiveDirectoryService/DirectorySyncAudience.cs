using System;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    public enum DirectorySyncAudience
    {
        All,
        Internal,
        Outsource
    }

    internal static class DirectorySyncAudienceParser
    {
        internal static DirectorySyncAudience Parse(bool? isInternalUser, string employmentType)
        {
            DirectorySyncAudience? fromEmploymentType = null;
            if (!string.IsNullOrWhiteSpace(employmentType))
            {
                if (string.Equals(employmentType.Trim(), "Internal", StringComparison.OrdinalIgnoreCase))
                    fromEmploymentType = DirectorySyncAudience.Internal;
                else if (string.Equals(employmentType.Trim(), "Outsource", StringComparison.OrdinalIgnoreCase))
                    fromEmploymentType = DirectorySyncAudience.Outsource;
                else
                    throw new ArgumentException("employmentType must be Internal or Outsource.", nameof(employmentType));
            }

            DirectorySyncAudience? fromInternalFlag = isInternalUser.HasValue
                ? (isInternalUser.Value ? DirectorySyncAudience.Internal : DirectorySyncAudience.Outsource)
                : (DirectorySyncAudience?)null;
            if (fromEmploymentType.HasValue && fromInternalFlag.HasValue
                && fromEmploymentType.Value != fromInternalFlag.Value)
            {
                throw new ArgumentException("isInternalUser and employmentType cannot select different audiences.");
            }

            return fromEmploymentType ?? fromInternalFlag ?? DirectorySyncAudience.All;
        }

        internal static string ToPageTokenPurpose(DirectorySyncAudience audience)
        {
            switch (audience)
            {
                case DirectorySyncAudience.Internal: return "v2internal";
                case DirectorySyncAudience.Outsource: return "v2outsource";
                case DirectorySyncAudience.All: return "v2all";
                default: throw new ArgumentOutOfRangeException(nameof(audience));
            }
        }

        internal static bool TryParsePageTokenPurpose(string purpose, out DirectorySyncAudience audience)
        {
            switch (purpose)
            {
                case "v2all": audience = DirectorySyncAudience.All; return true;
                case "v2internal": audience = DirectorySyncAudience.Internal; return true;
                case "v2outsource": audience = DirectorySyncAudience.Outsource; return true;
                default: audience = DirectorySyncAudience.All; return false;
            }
        }
    }
}
