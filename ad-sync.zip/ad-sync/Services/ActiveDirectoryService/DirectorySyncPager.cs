using ADGlobalService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    /// <summary>
    /// Keeps each LDAP connection and cookie together across HTTP requests.
    /// Only the last page is cached, allowing delivery retries without advancing LDAP.
    /// </summary>
    public sealed class DirectorySyncPager : IDisposable
    {
        private readonly object _sync = new object();
        private readonly Dictionary<Guid, Session> _sessions = new Dictionary<Guid, Session>();
        private readonly TimeSpan _idleTimeout;
        private readonly int _maxSessions;
        private readonly Func<DateTime> _utcNow;
        private readonly Timer _cleanupTimer;
        private bool _disposed;

        public DirectorySyncPager() : this(TimeSpan.FromMinutes(15), 32, () => DateTime.UtcNow)
        {
        }

        internal DirectorySyncPager(TimeSpan idleTimeout, int maxSessions, Func<DateTime> utcNow)
        {
            _idleTimeout = idleTimeout;
            _maxSessions = maxSessions;
            _utcNow = utcNow;
            _cleanupTimer = new Timer(_ => CleanupExpired(), null,
                TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1));
        }

        internal async Task<DirectorySyncPage> ReadPageAsync(
            Func<IDirectorySyncReader> createReader, int pageSize, string pageToken,
            string sessionPurpose = "legacy")
        {
            if (pageSize < 1 || pageSize > 1000)
                throw new ArgumentOutOfRangeException(nameof(pageSize), "pageSize must be between 1 and 1000.");

            Session session;
            string requestToken;
            if (pageToken == null)
            {
                CleanupExpired();
                lock (_sync)
                {
                    if (_disposed) throw new ObjectDisposedException(nameof(DirectorySyncPager));
                    if (_sessions.Count >= _maxSessions)
                        throw new DirectorySyncCapacityException();
                    var id = Guid.NewGuid();
                    requestToken = CreateToken(sessionPurpose, id);
                    session = new Session
                    {
                        Id = id,
                        PageSize = pageSize,
                        Purpose = sessionPurpose,
                        StartedAtUtc = _utcNow(),
                        ExpiresAtUtc = _utcNow().Add(_idleTimeout),
                        ExpectedToken = requestToken,
                        Reader = createReader()
                    };
                    _sessions.Add(id, session);
                }
            }
            else
            {
                Guid id;
                Guid nonce;
                var parts = pageToken.Split('.');
                if (parts.Length != 3
                    || !string.Equals(parts[0], sessionPurpose, StringComparison.Ordinal)
                    || !Guid.TryParseExact(parts[1], "N", out id)
                    || !Guid.TryParseExact(parts[2], "N", out nonce))
                    throw new ArgumentException("Invalid pageToken.", nameof(pageToken));
                lock (_sync)
                {
                    if (!_sessions.TryGetValue(id, out session))
                        throw new DirectorySyncExpiredException();
                }
                requestToken = pageToken;
            }

            await session.Gate.WaitAsync().ConfigureAwait(false);
            try
            {
                if (session.Closed || session.ExpiresAtUtc <= _utcNow())
                {
                    CloseSession(session);
                    throw new DirectorySyncExpiredException();
                }
                if (pageSize != session.PageSize)
                    throw new ArgumentException("pageSize cannot change during a synchronization.", nameof(pageSize));

                if (requestToken == session.LastRequestToken)
                    return session.LastPage;
                if (requestToken != session.ExpectedToken)
                    throw new DirectorySyncExpiredException();

                DirectorySyncBatch batch;
                try
                {
                    batch = await session.Reader.ReadAsync(session.Cookie).ConfigureAwait(false);
                }
                catch
                {
                    // The server may already have advanced its cookie. Restart this scan,
                    // rather than risk silently skipping data on a retry.
                    CloseSession(session);
                    throw;
                }

                session.Cookie = batch.Cookie;
                session.ExpiresAtUtc = _utcNow().Add(_idleTimeout);
                string nextToken = batch.Cookie.Length == 0 ? null : CreateToken(session.Purpose, session.Id);
                var page = new DirectorySyncPage
                {
                    SyncRunId = session.Id,
                    SyncStartedAtUtc = session.StartedAtUtc,
                    ExpiresAtUtc = session.ExpiresAtUtc,
                    Items = batch.Items,
                    NextPageToken = nextToken
                };
                session.LastRequestToken = requestToken;
                session.LastPage = page;
                session.ExpectedToken = nextToken;
                if (nextToken == null)
                {
                    session.Reader.Dispose();
                    session.Reader = null;
                }
                return page;
            }
            finally
            {
                session.Gate.Release();
            }
        }

        private static string CreateToken(string purpose, Guid sessionId)
        {
            return purpose + "." + sessionId.ToString("N") + "." + Guid.NewGuid().ToString("N");
        }

        private void CloseSession(Session session)
        {
            session.Closed = true;
            session.Reader?.Dispose();
            session.Reader = null;
            lock (_sync) _sessions.Remove(session.Id);
        }

        private void CleanupExpired()
        {
            lock (_sync)
            {
                foreach (var session in _sessions.Values.ToArray())
                {
                    if (session.ExpiresAtUtc > _utcNow() || !session.Gate.Wait(0))
                        continue;
                    try { CloseSession(session); }
                    finally { session.Gate.Release(); }
                }
            }
        }

        public void Dispose()
        {
            _cleanupTimer.Dispose();
            Session[] sessions;
            lock (_sync)
            {
                _disposed = true;
                sessions = _sessions.Values.ToArray();
                _sessions.Clear();
            }
            foreach (var session in sessions)
            {
                session.Gate.Wait();
                try { CloseSession(session); }
                finally { session.Gate.Release(); }
            }
        }

        private sealed class Session
        {
            public Guid Id;
            public string Purpose;
            public int PageSize;
            public DateTime StartedAtUtc;
            public DateTime ExpiresAtUtc;
            public string ExpectedToken;
            public string LastRequestToken;
            public DirectorySyncPage LastPage;
            public byte[] Cookie = new byte[0];
            public IDirectorySyncReader Reader;
            public bool Closed;
            public readonly SemaphoreSlim Gate = new SemaphoreSlim(1, 1);
        }
    }

    internal interface IDirectorySyncReader : IDisposable
    {
        Task<DirectorySyncBatch> ReadAsync(byte[] cookie);
    }

    internal sealed class DirectorySyncBatch
    {
        public List<DirectorySyncUser> Items { get; set; }
        public byte[] Cookie { get; set; }
    }

    public sealed class DirectorySyncExpiredException : Exception
    {
        public DirectorySyncExpiredException()
            : base("The synchronization page has expired or is out of sequence. Restart from the first page.") { }
    }

    public sealed class DirectorySyncCapacityException : Exception
    {
        public DirectorySyncCapacityException()
            : base("Directory synchronization capacity is temporarily exhausted. Retry later.") { }
    }
}
