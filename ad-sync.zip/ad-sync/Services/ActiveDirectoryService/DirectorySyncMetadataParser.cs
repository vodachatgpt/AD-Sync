using System;
using System.Globalization;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    internal static class DirectorySyncMetadataParser
    {
        internal static DirectorySyncRootDseMetadata ParseRootDse(string dsServiceName, string highestCommittedUsn)
        {
            long highestUsn;
            if (string.IsNullOrWhiteSpace(dsServiceName)
                || !long.TryParse(highestCommittedUsn, NumberStyles.None,
                    CultureInfo.InvariantCulture, out highestUsn) || highestUsn < 0)
            {
                throw new InvalidOperationException("The configured domain controller returned invalid synchronization metadata.");
            }
            return new DirectorySyncRootDseMetadata
            {
                NtdsSettingsDistinguishedName = dsServiceName,
                HighestCommittedUsn = highestUsn
            };
        }

        internal static Guid ParseInvocationId(byte[] invocationId)
        {
            if (invocationId == null || invocationId.Length != 16)
                throw new InvalidOperationException("The domain controller returned an invalid invocationID.");
            return new Guid(invocationId);
        }
    }

    internal sealed class DirectorySyncRootDseMetadata
    {
        internal string NtdsSettingsDistinguishedName { get; set; }
        internal long HighestCommittedUsn { get; set; }
    }
}
