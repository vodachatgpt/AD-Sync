using ADGlobalService.Models;
using ADGlobalService.Models.SyncAdDBDtos;
using ADGlobalService.Services.ProfileImageService;
using Serilog;
using System;
using System.Collections.Generic;

using System.DirectoryServices.Protocols;
using System.Linq;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Web.Configuration;

namespace ADGlobalService.Services.ActiveDirectoryService
{
    public class ActiveDirectoryService : IActiveDirectoryService
    {
        const string LdapMatchingRuleInChain = "1.2.840.113556.1.4.1941";
        const string LdapMatchingRuleBitwise = "1.2.840.113556.1.4.803";
        private readonly string[] _autocompleteProperties = new[] { "samaccountname", "displayname", "mail", "userPrincipalName", "distinguishedname", "jobtitle" };
        private static readonly string[] _userProperties = new[]{
                "sAMAccountName",
                "mail",
                "userPrincipalName",
                "displayName",
                "manager",
                "department",
                "jobTitle",
                "VF-extensionAttribute04",// hod NtAcount
                "extensionattribute7",// manager NtAcount
                "extensionattribute6",// sub department
                "distinguishedName",
                "memberOf",
                "gwereportingto",
                "extensionattribute1" ,// staffID,
                "extensionAttribute10" ,// sapId,
                "extensionattribute5" ,// hiring date,
                "mobile",
                "fullname",
                "extensionAttribute3",
                "physicalDeliveryOfficeName",
                "company",
                "gweinternaluser",
                "extensionAttribute8",
            };
        private static readonly Dictionary<UserField, string[]> _userFieldProperties =
    new Dictionary<UserField, string[]>
{
    {
        UserField.NTAccount,
        new[] { "sAMAccountName" }
    },
    {
        UserField.Email,
        new[] { "mail", "userPrincipalName" }
    },
    {
        UserField.UserPrincipalName,
        new[] { "userPrincipalName" }
    },
    {
        UserField.DisplayName,
        new[] { "displayName" }
    },
    {
        UserField.JobTitle,
        new[] { "jobTitle" }
    },
    {
        UserField.IsInternalUser,
        new[] { "gweinternaluser" }
    },
    {
        UserField.EmploymentType,
        new[] { "gweinternaluser" }
    },
    {
        UserField.Department,
        new[] { "department" }
    },
    {
        UserField.Manager,
        new[] { "manager" }
    },
    {
        UserField.ManagerNT,
        new[] { "extensionattribute7" }
    },
    {
        UserField.SubDepartment,
        new[] { "extensionattribute6" }
    },
    {
        UserField.ReportTo,
        new[] { "gwereportingto" }
    },
    {
        UserField.StaffId,
        new[] { "extensionattribute1" }
    },
    {
        UserField.SapId,
        new[] { "extensionAttribute10" }
    },
    {
        UserField.FullName,
        new[] { "fullname" }
    },
    {
        UserField.Mobile,
        new[] { "mobile" }
    },
    {
        UserField.Company,
        new[] { "company" }
    },
    {
        UserField.Office,
        new[] { "physicalDeliveryOfficeName" }
    },
    {
        UserField.CostCenter,
        new[] { "extensionAttribute3" }
    },
    {
        UserField.HiringDate,
        new[] { "extensionattribute5" }
    },
    {
        UserField.Gender,
        new[] { "extensionAttribute8" }
    }
};
        private const string HodAttribute = "VF-extensionAttribute04";
        private const string HodAttributeValue = "Manager EXCO";
        private const string ExcoAttributeValue = " Manager CEO";
        private readonly string _ldapPath;
        private readonly string _ldapUser;
        private readonly string _ldapPass;
        private readonly string _baseDn;
        private readonly string _domainName;
        private readonly NetworkCredential _serviceAccountCredentials;
        private readonly IProfileImageService _profileImageService;
        private readonly DirectorySyncPager _directorySyncPager;


        public ActiveDirectoryService(IProfileImageService profileImageService, DirectorySyncPager directorySyncPager)
        {
            _profileImageService = profileImageService;
            _directorySyncPager = directorySyncPager;
            _ldapPath = WebConfigurationManager.AppSettings["ADFUrl"];
            _ldapUser = WebConfigurationManager.AppSettings["ADLoginUser"];
            _ldapPass = WebConfigurationManager.AppSettings["ADLoginPass"];

            if (string.IsNullOrEmpty(_ldapPath) || string.IsNullOrEmpty(_ldapUser) || string.IsNullOrEmpty(_ldapPass))
            {
                throw new InvalidOperationException("LDAP configuration settings are missing from Web.config.");
            }

            _baseDn = _ldapPath.Replace("LDAP://", "");
            string[] domainComponents = _baseDn.Split(',');
            _domainName = string.Join(".", domainComponents.Select(dc => dc.Split('=')[1]));

            _serviceAccountCredentials = new NetworkCredential(_ldapUser, _ldapPass, _domainName);

        }

        public Task<DirectorySyncPage> GetUsersForSyncAsync(int pageSize = 500, string pageToken = null, string sessionPurpose = "legacy")
        {
            if (pageToken != null && (string.IsNullOrWhiteSpace(pageToken) || pageToken.Length > 128))
                throw new ArgumentException("Invalid pageToken.", nameof(pageToken));

            string[] attributes = _userProperties
                .Where(property => !property.Equals("memberOf", StringComparison.OrdinalIgnoreCase))
                .Concat(new[] { "objectGUID", "userAccountControl", "whenChanged" })
                .ToArray();

            return _directorySyncPager.ReadPageAsync(
                () => new LdapDirectorySyncReader(_domainName, _baseDn,
                    _serviceAccountCredentials, attributes, pageSize, MapSyncUser),
                pageSize, pageToken, sessionPurpose);
        }

        private DirectorySyncUser MapSyncUser(SearchResultEntry entry)
        {
            byte[] guidBytes = entry.Attributes.Contains("objectGUID")
                && entry.Attributes["objectGUID"].Count == 1
                ? entry.Attributes["objectGUID"][0] as byte[] : null;
            int accountControl;
            if (guidBytes == null || guidBytes.Length != 16
                || !int.TryParse(GetProperty(entry, "userAccountControl"), out accountControl))
            {
                Log.Warning(
                    "Skipping directory user with missing identity or account status. DistinguishedName: {DistinguishedName}, HasObjectGuid: {HasObjectGuid}, UserAccountControl: {UserAccountControl}",
                    entry.DistinguishedName,
                    guidBytes != null && guidBytes.Length == 16,
                    GetProperty(entry, "userAccountControl"));
                return null;
            }

            string changed = GetProperty(entry, "whenChanged");
            DateTime parsedChanged;
            DateTime? changedAtUtc = null;
            if (!string.IsNullOrEmpty(changed))
            {
                if (!DateTime.TryParseExact(changed,
                    new[] { "yyyyMMddHHmmss.FFFFFFF'Z'", "yyyyMMddHHmmss'Z'" },
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.AssumeUniversal
                        | System.Globalization.DateTimeStyles.AdjustToUniversal, out parsedChanged))
                    throw new InvalidOperationException("A directory user has an invalid modification timestamp.");
                changedAtUtc = parsedChanged;
            }

            return new DirectorySyncUser
            {
                AdObjectGuid = new Guid(guidBytes),
                DistinguishedName = entry.DistinguishedName,
                IsEnabled = (accountControl & 0x0002) == 0,
                AdLastModifiedAtUtc = changedAtUtc,
                Profile = MapSearchResultToMember(entry, includeExtendedData: true)
            };
        }
        public async Task<string> GetUserGenderAsync(string identifier)
        {
            if (string.IsNullOrWhiteSpace(identifier))
                return "Unknown";

            string escapedQuery = EscapeLdapFilter(identifier);
            var filter = $"(&(objectClass=user)(|" +
                         $"(sAMAccountName={escapedQuery})" +
                         $"(mail={escapedQuery})" +
                         $"(userPrincipalName={escapedQuery})" +
                         $"(displayName={escapedQuery})" +
                         $"(extensionattribute1={escapedQuery})" +
                         $"(mobile={escapedQuery})" +
                         $"))";

            var entry = await FindSingleEntryByFilterAsync(filter, _userProperties);
            if (entry == null)
                return "Unknown";

            return DetermineGenderFromEntry(entry);
        }

        private string DetermineGenderFromEntry(SearchResultEntry entry)
        {
            if (entry == null) return "Unknown";

            string title = GetProperty(entry, "extensionAttribute8")?.Trim();
            if (!string.IsNullOrEmpty(title))
            {
                string t = title.ToUpperInvariant();
                if (t == "MRS." || t == "MRS" ||
                    t == "MS." || t == "MS" ||
                    t == "MISS" || t == "MISS.")
                {
                    return "Female";
                }
                if (t == "MR." || t == "MR" ||
                    t.StartsWith("MR.", StringComparison.OrdinalIgnoreCase) ||
                    t.StartsWith("MR ", StringComparison.OrdinalIgnoreCase))
                {
                    return "Male";
                }
            }

            return "Unknown";
        }
        public async Task<bool> IsUserInGroupAsync(string groupName, string accountIdentifier, IdentifierType type)
        {
            string groupDn = await GetGroupDistinguishedName(groupName, IdentifierType.GroupName);
            if (string.IsNullOrEmpty(groupDn))
            {
                return false;
            }

            string escapedIdentifier = EscapeLdapFilter(accountIdentifier);
            string identityFilter;
            if (type == IdentifierType.NtAccount)
            {
                identityFilter = $"(sAMAccountName={escapedIdentifier})";
            }
            else
            {
                identityFilter =
                    $"(|" +
                    $"(mail={escapedIdentifier})" +
                    $"(userPrincipalName={escapedIdentifier})" +
                    $")";
            }
            string filter =
                $"(&(objectClass=user)" +
                $"{identityFilter}" +
                $"(memberOf:{LdapMatchingRuleInChain}:={groupDn}))";
            var result = await FindSingleEntryByFilterAsync(filter, new[] { "cn" });
            return result != null;
        }

        public async Task<IEnumerable<ActiveDirectoryMember>> GetGroupMembers(string identifier, IdentifierType type, bool includeProfileImage = false, string imageResolution = "96x96")
        {
            string groupDn = await GetGroupDistinguishedName(identifier, type);
            if (string.IsNullOrEmpty(groupDn))
            {
                return Enumerable.Empty<ActiveDirectoryMember>();
            }
            var members = await GetMembersByGroupDnAsync(groupDn);

            if (includeProfileImage && members.Any())
            {
                await _profileImageService.PopulateImagesParallelAsync(members, imageResolution);
            }

            return members;
        }

        public async Task<ActiveDirectoryMember> GetUserAsync(string identifier,
            FilterType filterType,
            bool includeExtendedData = true,
            bool includeProfileImage = false,
            string imageResolution = null,
            bool includeGroubMail = false)
        {
            string userAttribute;
            SearchResultEntry entry;
            switch (filterType)
            {
                case FilterType.NtAccount:
                    entry = await FindSingleEntryByAttributeAsync(
                        "user",
                        "sAMAccountName",
                        identifier,
                        _userProperties);
                    break;
                case FilterType.CommonName:
                    entry = await FindSingleEntryByAttributeAsync(
                        "user",
                        "cn",
                        identifier,
                        _userProperties);
                    break;

                case FilterType.Email:
                default:
                    string escapedIdentifier = EscapeLdapFilter(identifier);

                    string emailFilter =
                        $"(&(objectClass=user)(|" +
                        $"(mail={escapedIdentifier})" +
                        $"(userPrincipalName={escapedIdentifier})" +
                        $"))";

                    entry = await FindSingleEntryByFilterAsync(
                        emailFilter,
                        _userProperties);
                    break;
            }
            if (entry == null) return null;


            var member = MapSearchResultToMember(entry, includeExtendedData);
            if (includeExtendedData)
            {
                string userDn = GetProperty(entry, "distinguishedName");
                if (!string.IsNullOrEmpty(userDn))
                {
                    member.SubordinateEmails = await GetSubordinateEmailsAsync(userDn);
                    member.IsManager = member.SubordinateEmails.Any();
                }
                if (includeGroubMail)
                {
                    member.DLs = await GetDirectDLMailAddressesAsync(entry);
                }
                else
                {
                    member.DLs = GetUserDLs(entry);
                }

            }
            if (includeProfileImage && !string.IsNullOrEmpty(member.Email))
            {
                member.PhotoBase64 = await _profileImageService.FetchUserPhotoBase64Async(member.Email, imageResolution);
                member.HasPhoto = !string.IsNullOrEmpty(member.PhotoBase64);
            }
            else
            {
                member.HasPhoto = false;
            }
            return member;
        }
        public async Task<ActiveDirectoryMember> FindUserAsync(string searchQuery,
            bool includeExtendedData = true,
            bool includeProfileImage = false,
            string imageResolution = null,
            bool includeGroubMail = false)
        {
            if (string.IsNullOrWhiteSpace(searchQuery))
            {
                return null;
            }
            string escapedQuery = EscapeLdapFilter(searchQuery);

            var filter = $"(&(objectClass=user)(| (sAMAccountName={escapedQuery})(mail={escapedQuery})(userPrincipalName={escapedQuery})(extensionAttribute10={escapedQuery})(displayName={escapedQuery})(extensionattribute1={escapedQuery})(mobile={escapedQuery})(fullname={escapedQuery}) ))";
            var entry = await FindSingleEntryByFilterAsync(filter, _userProperties);
            if (entry == null) return null;

            var member = MapSearchResultToMember(entry, includeExtendedData);

            if (includeExtendedData)
            {
                string userDn = GetProperty(entry, "distinguishedName");
                if (!string.IsNullOrEmpty(userDn))
                {
                    member.SubordinateEmails = await GetSubordinateEmailsAsync(userDn);
                    member.IsManager = member.SubordinateEmails.Any();
                }
                if (includeGroubMail)
                {
                    member.DLs = await GetDirectDLMailAddressesAsync(entry);
                }
                else
                {
                    member.DLs = GetUserDLs(entry);
                }
            }
            if (includeProfileImage && !string.IsNullOrEmpty(member.Email))
            {
                member.PhotoBase64 = await _profileImageService.FetchUserPhotoBase64Async(member.Email, imageResolution);
                member.HasPhoto = !string.IsNullOrEmpty(member.PhotoBase64);
            }
            else
            {
                member.HasPhoto = false;
            }
            return member;
        }

        public async Task<ActiveDirectoryMemberV2> GetUserSelectiveAsync(
            string identifier,
            UserIdentifierType identifierType,
            IEnumerable<UserField> fieldsToLoad,
            bool includeDls = false,
            bool includeDlEmails = false,
            bool includeSubordinates = false)
        {
            if (string.IsNullOrWhiteSpace(identifier))
                return null;

            identifier = identifier.Trim();

            var fieldSet = fieldsToLoad != null
                ? new HashSet<UserField>(fieldsToLoad)
                : new HashSet<UserField>();

            var propertiesToLoad = BuildSelectiveProperties(
                fieldSet,
                includeDls || includeDlEmails,
                includeSubordinates);

            SearchResultEntry entry;

            // Fastest path for manager hierarchy.
            // We already have the exact DN, so don't search the whole AD tree.
            if (identifierType == UserIdentifierType.DistinguishedName)
            {
                entry = await FindSingleEntryByFilterAsync(
                    "(objectClass=user)",
                    propertiesToLoad,
                    identifier,
                    SearchScope.Base);
            }
            else
            {
                string escapedIdentifier =
                    EscapeLdapFilter(identifier);

                string filter = BuildUserSearchFilter(
                    escapedIdentifier,
                    identifierType);

                entry = await FindSingleEntryByFilterAsync(
                    filter,
                    propertiesToLoad);
            }

            if (entry == null)
                return null;

            var member = MapSearchResultToMemberSelective(
                entry,
                fieldSet);

            if (includeDls)
            {
                member.DLs = GetUserDLs(entry);
            }
            if (includeDlEmails)
            {
                member.DLEmails =
                    await GetDirectDLMailAddressesAsync(entry);
            }
            if (includeSubordinates)
            {
                string userDn =
                    GetProperty(entry, "distinguishedName");

                if (string.IsNullOrWhiteSpace(userDn))
                {
                    userDn = entry.DistinguishedName;
                }

                if (!string.IsNullOrWhiteSpace(userDn))
                {
                    var subordinateEmails =
                        await GetSubordinateEmailsAsync(userDn);

                    member.SubordinateEmails =
                        subordinateEmails;

                    member.IsManager =
                        subordinateEmails != null &&
                        subordinateEmails.Any();
                }
            }

            return member;
        }
        public async Task<IEnumerable<string>> GetAllDepartmentsAsync()
        {
            var departments = new HashSet<string>(StringComparer.OrdinalIgnoreCase);


            string activeUserFilter = $"(!(userAccountControl:{LdapMatchingRuleBitwise}:=2))";


            var filter = $"(&(objectClass=user)(department=*) {activeUserFilter} )";

            // var entries = await FindAllEntriesByFilterAsync("(&(objectClass=user)(department=*))", new[] { "department" });
            var entries = await FindAllEntriesByFilterAsync(filter, new[] { "department" });
            foreach (var entry in entries)
            {
                string dept = GetProperty(entry, "department");
                if (!string.IsNullOrWhiteSpace(dept))
                {
                    departments.Add(dept.Trim());
                }
            }
            return departments.ToList();
        }
        public async Task<IEnumerable<string>> GetSubDepartmentsAsync(string parentDepartment)
        {
            var filter = $"(&(objectClass=organizationalUnit)(ou={EscapeLdapFilter(parentDepartment)}))";
            var parentEntry = await FindSingleEntryByFilterAsync(filter, new[] { "distinguishedName" });

            if (parentEntry == null)
            {
                return Enumerable.Empty<string>();
            }

            string parentDn = GetProperty(parentEntry, "distinguishedName");
            var subDepts = new List<string>();

            try
            {
                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;

                    var searchRequest = new SearchRequest(
                        parentDn,
                        "(objectClass=organizationalUnit)",
                        SearchScope.OneLevel,
                        new[] { "ou" }
                    );

                    SearchResponse response = (SearchResponse)await Task.Factory.FromAsync(
                        (asyncCallback, state) => connection.BeginSendRequest(searchRequest, PartialResultProcessing.ReturnPartialResults, asyncCallback, state),
                        (asyncResult) => connection.EndSendRequest(asyncResult),
                        null);

                    if (response != null && response.Entries.Count > 0)
                    {
                        foreach (SearchResultEntry entry in response.Entries)
                        {
                            string ouName = GetProperty(entry, "ou");
                            if (!string.IsNullOrEmpty(ouName))
                            {
                                subDepts.Add(ouName);
                            }
                        }
                    }
                }
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LDAP Exception in GetSubDepartmentsAsync: {ex.Message}");
            }
            return subDepts;
        }
        public async Task<string> GetGroupNameByEmailAsync(string email)
        {
            var filter = $"(&(objectClass=group)(|(mail={EscapeLdapFilter(email)})(proxyAddresses=SMTP:{EscapeLdapFilter(email)})))";
            var result = await FindSingleEntryByFilterAsync(filter, new[] { "cn" });
            return GetProperty(result, "cn");
        }
        public async Task<string> GetEmailByGroupNameAsync(string groupName)
        {
            var filter = $"(&(objectClass=group)(cn={EscapeLdapFilter(groupName)}))";

            var result = await FindSingleEntryByFilterAsync(
                filter,
                new[] { "mail" }
            );

            return GetProperty(result, "mail");
        }
        public async Task<IEnumerable<ActiveDirectoryMember>> GetMembersByDepartmentAsync(string department)
        {
            var members = new List<ActiveDirectoryMember>();
            var filter = $"(&(objectClass=user)(department={EscapeLdapFilter(department)})(mail=*))";
            var entries = await FindAllEntriesByFilterAsync(filter, _userProperties);

            foreach (var entry in entries)
            {
                members.Add(MapSearchResultToMember(entry, true));
            }
            return members;
        }
        public async Task<IEnumerable<ActiveDirectoryMember>> GetNewHiresAsync(DateTime? date = null)
        {
            var hires = new List<ActiveDirectoryMember>();
            DateTime targetDay = date ?? DateTime.Today.AddDays(-1);
            string hiringDateValue = targetDay.ToString("d-MMM-yy", System.Globalization.CultureInfo.InvariantCulture);

            var filter = $"(&(objectClass=user)(hiringDate={hiringDateValue}))";
            var entries = await FindAllEntriesByFilterAsync(filter, _userProperties);

            foreach (var entry in entries)
            {
                hires.Add(MapSearchResultToMember(entry, true));
            }
            return hires;
        }
        public async Task<IEnumerable<string>> GetAllOUsAsync()
        {
            var ous = new List<string>();
            var entries = await FindAllEntriesByFilterAsync("(objectClass=organizationalUnit)", new[] { "ou", "distinguishedName" });
            foreach (var entry in entries)
            {
                string ouName = GetProperty(entry, "ou") ?? "N/A";
                string dn = GetProperty(entry, "distinguishedName") ?? "N/A";
                ous.Add($"{ouName} - {dn}");
            }
            return ous;
        }


        public async Task<List<ActiveDirectoryMember>> SearchUsersForAutocompleteAsync(
            string searchQuery,
            int limit = 5,
            bool includeProfileImage = false,
            string imageResolution = "96x96")
        {
            if (string.IsNullOrWhiteSpace(searchQuery))
            {
                return new List<ActiveDirectoryMember>();
            }

            string escapedQuery = EscapeLdapFilter(searchQuery);

            var filter = $"(&(objectClass=user)(| (sAMAccountName={escapedQuery}*)(mail={escapedQuery}*)(displayName={escapedQuery}*)(extensionattribute1={escapedQuery}*)(mobile={escapedQuery}*)))";

            var entries = await FindMultipleEntriesByFilterAsync(filter, _autocompleteProperties, limit);

            if (entries == null || entries.Count == 0)
            {
                return new List<ActiveDirectoryMember>();
            }

            // 4. Map and Return
            var members = entries
                .Select(entry => MapSearchResultToMember(entry, includeExtendedData: false))
                .ToList();
            if (includeProfileImage && members.Any())
            {
                await _profileImageService.PopulateImagesParallelAsync(members, imageResolution);
            }
            return members;
        }



        public async Task<List<SearchResultEntry>> FindMultipleEntriesByFilterAsync(
            string filter,
            string[] propertiesToLoad,
            int limit)
        {
            if (limit <= 0) limit = 5;
            try
            {
                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;

                    var searchRequest = new SearchRequest(
                        _baseDn,
                        filter,
                        SearchScope.Subtree,
                        propertiesToLoad
                    );

                    searchRequest.SizeLimit = limit;

                    searchRequest.TimeLimit = new System.TimeSpan(0, 0, 5); // e.g., 5-second timeout

                    var response = await Task.Factory.FromAsync(
                        (asyncCallback, state) => connection.BeginSendRequest(searchRequest, PartialResultProcessing.ReturnPartialResults, asyncCallback, state),
                        (asyncResult) => connection.EndSendRequest(asyncResult),
                        null) as SearchResponse;

                    if (response?.Entries == null || response.Entries.Count == 0)
                    {
                        return new List<SearchResultEntry>();
                    }

                    return response.Entries.Cast<SearchResultEntry>().ToList();
                }
            }
            catch (LdapException ex)
            {
                return new List<SearchResultEntry>();
            }
            catch (Exception ex)
            {
                return new List<SearchResultEntry>();
            }
        }

        public async Task<bool> AddUserToGroupAsync(string userIdentifier, string groupIdentifier)
        {
            try
            {
                string escapedQuery = EscapeLdapFilter(userIdentifier);
                var userFilter = $"(&(objectClass=user)(| (sAMAccountName={escapedQuery})(mail={escapedQuery})(displayName={escapedQuery})(extensionattribute1={escapedQuery})(mobile={escapedQuery})))";
                var userEntry = await FindSingleEntryByFilterAsync(userFilter, new[] { "distinguishedName" });

                if (userEntry == null)
                {
                    return false;
                }

                string userDn = GetProperty(userEntry, "distinguishedName");
                if (string.IsNullOrEmpty(userDn))
                {
                    return false;
                }

                // 2. Resolve group's DistinguishedName
                var groupFilter = $"(&(objectClass=group)(| " +
                          $"(cn={EscapeLdapFilter(groupIdentifier)})" +                // group name (most common)
                          $"(mail={EscapeLdapFilter(groupIdentifier)})" +             // group email
                          $"(proxyAddresses=SMTP:{EscapeLdapFilter(groupIdentifier)})" + // SMTP alias
                          $"))";

                var groupEntry = await FindSingleEntryByFilterAsync(groupFilter, new[] { "distinguishedName", "member" });

                if (groupEntry == null)
                {
                    // Group not found
                    return false;
                }

                string groupDn = GetProperty(groupEntry, "distinguishedName");
                if (string.IsNullOrEmpty(groupDn))
                {
                    return false;
                }

                // 3. Optional: already a member? → consider success (idempotent)
                bool isAlreadyMember = false;
                if (groupEntry.Attributes.Contains("member"))
                {
                    var currentMembers = groupEntry.Attributes["member"].GetValues(typeof(string))?.Cast<string>();
                    isAlreadyMember = currentMembers?.Any(m => string.Equals(m, userDn, StringComparison.OrdinalIgnoreCase)) == true;
                }

                if (isAlreadyMember)
                {
                    return true; // already in group → success
                }

                // 4. Add user to group
                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;
                    connection.SessionOptions.ProtocolVersion = 3;

                    var modifyRequest = new ModifyRequest(
                        groupDn,
                        DirectoryAttributeOperation.Add,
                        "member",
                        userDn
                    );

                    var modifyResponse = (ModifyResponse)await Task.Factory.FromAsync(
                        (cb, s) => connection.BeginSendRequest(modifyRequest, PartialResultProcessing.NoPartialResultSupport, cb, s),
                        (ar) => connection.EndSendRequest(ar),
                        null);

                    if (modifyResponse.ResultCode != ResultCode.Success)
                    {
                        Console.WriteLine($"LDAP Add to group failed: {modifyResponse.ResultCode} - {modifyResponse.ErrorMessage}");
                        return false;
                    }
                }

                return true;
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LDAP Exception in AddUserToGroupAsync: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error in AddUserToGroupAsync: {ex.Message}");
                return false;
            }
        }
        public async Task<bool> RemoveUserFromGroupAsync(string userIdentifier, string groupIdentifier)
        {
            try
            {
                string escapedQuery = EscapeLdapFilter(userIdentifier);
                var userFilter = $"(&(objectClass=user)(| (sAMAccountName={escapedQuery})(mail={escapedQuery})(displayName={escapedQuery})(extensionattribute1={escapedQuery})(mobile={escapedQuery})))";

                var userEntry = await FindSingleEntryByFilterAsync(userFilter, new[] { "distinguishedName" });

                if (userEntry == null)
                {
                    // User not found
                    return false;
                }

                string userDn = GetProperty(userEntry, "distinguishedName");
                if (string.IsNullOrEmpty(userDn))
                {
                    return false;
                }

                // 2. Resolve group's DistinguishedName

                var groupFilter = $"(&(objectClass=group)(| " +
                         $"(cn={EscapeLdapFilter(groupIdentifier)})" +                // group name (most common)
                         $"(mail={EscapeLdapFilter(groupIdentifier)})" +             // group email
                         $"(proxyAddresses=SMTP:{EscapeLdapFilter(groupIdentifier)})" + // SMTP alias
                         $"))";
                var groupEntry = await FindSingleEntryByFilterAsync(groupFilter, new[] { "distinguishedName", "member" });

                if (groupEntry == null)
                {
                    // Group not found
                    return false;
                }

                string groupDn = GetProperty(groupEntry, "distinguishedName");
                if (string.IsNullOrEmpty(groupDn))
                {
                    return false;
                }

                // 3. Check if user is actually a member (optional but recommended)
                bool isMember = false;
                if (groupEntry.Attributes.Contains("member"))
                {
                    var members = groupEntry.Attributes["member"].GetValues(typeof(string))?.Cast<string>();
                    isMember = members?.Any(m => string.Equals(m, userDn, StringComparison.OrdinalIgnoreCase)) == true;
                }

                if (!isMember)
                {
                    // Already not a member → consider success (idempotent)
                    return true;
                }

                // 4. Remove user from group
                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;
                    connection.SessionOptions.ProtocolVersion = 3;

                    var modifyRequest = new ModifyRequest(
                        groupDn,
                        DirectoryAttributeOperation.Delete,
                        "member",
                        userDn
                    );

                    var modifyResponse = (ModifyResponse)await Task.Factory.FromAsync(
                        (cb, s) => connection.BeginSendRequest(modifyRequest, PartialResultProcessing.NoPartialResultSupport, cb, s),
                        (ar) => connection.EndSendRequest(ar),
                        null);

                    if (modifyResponse.ResultCode != ResultCode.Success)
                    {
                        Console.WriteLine($"LDAP Modify failed: {modifyResponse.ResultCode} - {modifyResponse.ErrorMessage}");
                        return false;
                    }
                }

                return true;
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LDAP Exception in RemoveUserFromGroupAsync: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error in RemoveUserFromGroupAsync: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Returns all Distribution List (DL) emails that the user is a member of (supports nested group membership).
        /// Uses LDAP_MATCHING_RULE_IN_CHAIN (1.2.840.113556.1.4.1941) to handle nested groups.
        /// Only returns groups that are in OU=DL or have "DL" in their name/path (as per your existing logic).
        /// </summary>
        /// <param name="userEmail">User's email address (mail attribute)</param>
        /// <returns>List of DL email addresses (mail attribute) the user belongs to</returns>
        public async Task<List<string>> GetUserDistributionListEmailsAsync(string userEmail)
        {
            if (string.IsNullOrWhiteSpace(userEmail))
            {
                return new List<string>();
            }

            // 1. Find the user's DistinguishedName first
            var userFilter = $"(&(objectClass=user)(mail={EscapeLdapFilter(userEmail)}))";
            var userEntry = await FindSingleEntryByFilterAsync(userFilter, new[] { "distinguishedName" });

            if (userEntry == null)
            {
                return new List<string>();
            }

            string userDn = GetProperty(userEntry, "distinguishedName");
            if (string.IsNullOrEmpty(userDn))
            {
                return new List<string>();
            }

            // 2. Find all groups (with mail) that the user is member of (including nested)
            var groupFilter = $"(&(objectClass=group)(mail=*)(member:{LdapMatchingRuleInChain}:={userDn}))";

            var properties = new[] { "mail", "cn", "distinguishedName" };
            var groupEntries = await FindAllEntriesByFilterAsync(groupFilter, properties);

            var dlEmails = new List<string>();

            var cnRegex = new Regex("^CN=([^,]+)", RegexOptions.IgnoreCase);

            foreach (var entry in groupEntries)
            {
                string groupDn = GetProperty(entry, "distinguishedName");
                string groupMail = GetProperty(entry, "mail");

                if (string.IsNullOrEmpty(groupMail))
                {
                    continue;
                }

                // Apply same DL detection logic as in your existing GetUserDLs method
                if (groupDn.IndexOf("OU=DL", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    dlEmails.Add(groupMail);
                    continue;
                }

                // Fallback: check CN starts with DL- or contains DL (your current logic style)
                Match match = cnRegex.Match(groupDn);
                if (match.Success)
                {
                    string cn = match.Groups[1].Value;
                    if (cn.StartsWith("DL-", StringComparison.OrdinalIgnoreCase) ||
                        cn.IndexOf("DL", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        dlEmails.Add(groupMail);
                    }
                }
            }

            // Remove duplicates and sort (optional but nice)
            return dlEmails
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(e => e)
                .ToList();
        }

        /// <summary>
        /// Returns only direct Distribution List emails from the user's memberOf attribute.
        /// </summary>
        public async Task<List<string>> GetUserDirectDistributionListEmailsAsync(string userIdentifier)
        {
            if (string.IsNullOrWhiteSpace(userIdentifier))
            {
                return new List<string>();
            }
            string escapedQuery = EscapeLdapFilter(userIdentifier);
            var userFilter = $"(&(objectClass=user)(|" +
                             $"(sAMAccountName={escapedQuery})" +
                             $"(mail={escapedQuery})" +
                             $"(displayName={escapedQuery})" +
                             $"(extensionattribute1={escapedQuery})" +
                             $"(mobile={escapedQuery})" +
                             $"))";
            var userEntry = await FindSingleEntryByFilterAsync(userFilter, new[] { "memberOf" });
            if (userEntry == null)
            {
                return new List<string>();
            }
            var dlEmails = await GetDirectDLMailAddressesAsync(userEntry);
            return dlEmails
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(e => e)
                .ToList();
        }

        private List<string> GetUserDLs(SearchResultEntry userEntry)
        {
            if (userEntry is null) return null;
            var dlList = new List<string>();
            var cnRegex = new Regex("^CN=([^,]+)", RegexOptions.IgnoreCase);

            if (userEntry?.Attributes.Contains("memberOf") == true)
            {
                foreach (string groupDnStr in userEntry.Attributes["memberOf"].GetValues(typeof(string)))
                {
                    if (groupDnStr.IndexOf("OU=DL", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        Match match = cnRegex.Match(groupDnStr);
                        if (match.Success)
                        {
                            dlList.Add(match.Groups[1].Value);
                        }
                    }
                }
            }
            return dlList;
        }
        private async Task<List<string>> GetDirectDLMailAddressesAsync(SearchResultEntry userEntry)
        {
            var candidateGroupDns = GetCandidateDistributionListDNs(userEntry);

            if (candidateGroupDns.Count == 0)
            {
                return new List<string>();
            }
            var filterBuilder = new StringBuilder("(&(objectClass=group)(|");
            foreach (var dn in candidateGroupDns)
            {
                filterBuilder.Append("(distinguishedName=");
                filterBuilder.Append(EscapeLdapFilter(dn));
                filterBuilder.Append(")");
            }
            filterBuilder.Append("))");

            var groupEntries = await FindAllEntriesByFilterAsync(
                        filterBuilder.ToString(),
                        new[] { "mail", "proxyAddresses" }
                    );

            var dlEmails = new HashSet<string>(StringComparer.OrdinalIgnoreCase
                        );
            foreach (var groupEntry in groupEntries)
            {
                string email = GetPrimaryEmailAddress(groupEntry);

                if (!string.IsNullOrWhiteSpace(email))
                {
                    dlEmails.Add(email);
                    string normalized = GetNormalizedDomain(email);
                    if (normalized != null)
                    {
                        dlEmails.Add(normalized);
                    }
                }
            }
            return dlEmails.ToList();
        }
        private string GetNormalizedDomain(string email)
        {
            if (string.IsNullOrEmpty(email))
                return email;

            int atIndex = email.LastIndexOf('@');
            if (atIndex <= 0)
                return email;

            // Fast case-insensitive compare
            if (email.EndsWith("@voda.com", StringComparison.OrdinalIgnoreCase) ||
                email.EndsWith("@vodafone.eg", StringComparison.OrdinalIgnoreCase) ||
                email.EndsWith("@voda.com.eg", StringComparison.OrdinalIgnoreCase))
            {
                // Don't normalize if already correct
                if (email.EndsWith("@vodafone.com.eg", StringComparison.OrdinalIgnoreCase))
                {
                    return null;
                }

                return email.Substring(0, atIndex) + "@vodafone.com.eg";
            }

            return email;
        }
        private List<string> GetCandidateDistributionListDNs(SearchResultEntry userEntry)
        {
            var memberOfDns = GetMultiValueProperty(userEntry, "memberOf");
            var candidateDns = new List<string>();

            foreach (var dn in memberOfDns)
            {
                // Filter for distribution list patterns
                if (dn.Contains("OU=DL") ||
                    dn.Contains("CN=DL-") ||
                    dn.Contains(",DL,"))
                {
                    candidateDns.Add(dn);
                }
            }

            return candidateDns;
        }
        private string GetPrimaryEmailAddress(SearchResultEntry entry)
        {
            string mail = GetProperty(entry, "mail")?.Trim();
            if (!string.IsNullOrWhiteSpace(mail) && IsValidEmail(mail))
            {
                return mail;
            }
            var proxyAddresses = GetMultiValueProperty(entry, "proxyAddresses");
            if (proxyAddresses != null && proxyAddresses.Any())
            {
                var primarySmtp = proxyAddresses
                    .FirstOrDefault(addr => addr.StartsWith("SMTP:", StringComparison.Ordinal));


                if (primarySmtp != null)
                {
                    string email = primarySmtp.Substring(5).Trim(); // Remove "SMTP:" prefix
                    if (IsValidEmail(email))
                    {
                        return email;
                    }
                }
                var anySmtp = proxyAddresses
           .FirstOrDefault(addr => addr.StartsWith("SMTP:", StringComparison.OrdinalIgnoreCase));

                if (anySmtp != null)
                {
                    string email = anySmtp.Substring(5).Trim();
                    if (IsValidEmail(email))
                    {
                        return email;
                    }
                }

            }
            return null;

        }
        private bool IsValidEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return false;

            // Basic check: contains @ and domain
            return email.Contains("@") && email.IndexOf("@") < email.Length - 1;
        }
        private List<string> GetMultiValueProperty(SearchResultEntry entry, string attributeName)
        {
            var values = new List<string>();

            if (entry.Attributes.Contains(attributeName))
            {
                var attr = entry.Attributes[attributeName];
                for (int i = 0; i < attr.Count; i++)
                {
                    string value = attr[i]?.ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        values.Add(value);
                    }
                }
            }

            return values;
        }





        private async Task<IEnumerable<ActiveDirectoryMember>> GetMembersByGroupDnAsync(string groupDn)
        {
            var members = new List<ActiveDirectoryMember>();
            var filter = $"(&(objectClass=user)(memberOf:{LdapMatchingRuleInChain}:={groupDn}))";

            try
            {
                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;

                    var searchRequest = new SearchRequest(
                        _baseDn,
                        filter,
                        SearchScope.Subtree,
                        _userProperties
                    );

                    SearchResponse response = (SearchResponse)await Task.Factory.FromAsync(
                        (asyncCallback, state) => connection.BeginSendRequest(searchRequest, PartialResultProcessing.ReturnPartialResults, asyncCallback, state),
                        (asyncResult) => connection.EndSendRequest(asyncResult),
                        null);

                    if (response != null && response.Entries.Count > 0)
                    {
                        foreach (SearchResultEntry entry in response.Entries)
                        {
                            members.Add(MapSearchResultToMember(entry, true));
                        }
                    }
                }
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LDAP Exception in GetMembersByGroupDnAsync: {ex.Message}");
            }
            return members;
        }
        private async Task<string> GetGroupDistinguishedName(string identifier, IdentifierType type)
        {
            string filter;
            if (type == IdentifierType.Email)
            {
                filter = $"(&(objectClass=group)(|(mail={EscapeLdapFilter(identifier)})(proxyAddresses=SMTP:{EscapeLdapFilter(identifier)})))";
            }
            else // Default to GroupName (cn)
            {
                filter = $"(&(objectClass=group)(cn={EscapeLdapFilter(identifier)}))";
            }

            var result = await FindSingleEntryByFilterAsync(filter, new[] { "distinguishedName" });
            return GetProperty(result, "distinguishedName");
        }
        private ActiveDirectoryMember MapSearchResultToMember(SearchResultEntry entry, bool includeExtendedData = false)
        {
            if (entry == null) return null;
            string internalFlag = GetProperty(entry, "gweinternaluser");
            var IsInternalUser = string.Equals(internalFlag, "True", StringComparison.OrdinalIgnoreCase);
            string employmentType;
            if (IsInternalUser)
            {
                employmentType = EmploymentType.Internal.ToString();
            }
            else
            {
                employmentType = EmploymentType.Outsource.ToString(); ;
            }
            string userPrincipalName = GetProperty(entry, "userPrincipalName");

            if (!string.IsNullOrWhiteSpace(userPrincipalName))
            {
                userPrincipalName = userPrincipalName.Trim();
            }

            var member = new ActiveDirectoryMember
            {
                NTAccount = GetProperty(entry, "sAMAccountName"),
                Email = GetEffectiveEmail(entry),
                UserPrincipalName = userPrincipalName,
                IsInternalUser = IsInternalUser,
                DisplayName = GetProperty(entry, "displayName"),
                JobTitle = GetProperty(entry, "jobtitle"),
                EmploymentType = employmentType,
                HodNT = ResolveHodNt(entry)
            };

            if (includeExtendedData)
            {
                member.Department = GetProperty(entry, "department");
                member.Manager = GetProperty(entry, "manager");
                member.ManagerNT = GetProperty(entry, "extensionattribute7");
                //     member.JobTitle = GetProperty(entry, "jobTitle");
                member.SubDepartment = GetProperty(entry, "extensionattribute6");
                member.ReportTo = GetProperty(entry, "gwereportingto");
                member.StaffId = GetProperty(entry, "extensionattribute1");
                member.FullName = GetProperty(entry, "fullname");
                member.Mobile = GetProperty(entry, "mobile");
                member.Company = GetProperty(entry, "company");
                member.Office = GetProperty(entry, "physicalDeliveryOfficeName");
                member.CostCenter = GetProperty(entry, "extensionAttribute3");
                member.SapId = GetProperty(entry, "extensionAttribute10");
                member.HiringDate = GetProperty(entry, "extensionattribute5");
                member.Gender = DetermineGenderFromEntry(entry);
            }
            return member;
        }

        private string EscapeLdapFilter(string value)
        {
            if (string.IsNullOrEmpty(value))
            {
                return value;
            }

            return value.Replace(@"\", @"\5c")
                        .Replace("*", @"\2a")
                        .Replace("(", @"\28")
                        .Replace(")", @"\29")
                        .Replace("/", @"\2f")
                        .Replace("&", @"\26")
                        .Replace("|", @"\7c")
                        .Replace("!", @"\21")
                        .Replace("=", @"\3d")
                        .Replace(">", @"\3e")
                        .Replace("<", @"\3c")
                        .Replace("~", @"\7e")
                        .Replace("'", @"\27")
                        .Replace("\"", @"\22")
                        .Replace("+", @"\2b")
                        .Replace(",", @"\2c")
                        .Replace(";", @"\3b");
        }
        private async Task<List<string>> GetSubordinateEmailsAsync(string managerDn)
        {
            var emails = new List<string>();
            if (string.IsNullOrEmpty(managerDn))
            {
                return emails;
            }

            var filter = $"(&(objectClass=user)(manager={managerDn})(mail=*))";
            var entries = await FindAllEntriesByFilterAsync(filter, new[] { "mail" });

            foreach (var entry in entries)
            {
                emails.Add(GetProperty(entry, "mail"));
            }
            return emails;
        }
        private string GetProperty(SearchResultEntry entry, string propertyName)
        {
            if (entry == null || !entry.Attributes.Contains(propertyName))
            {
                return null;
            }
            return entry.Attributes[propertyName].GetValues(typeof(string))?[0].ToString();
        }
        private async Task<IEnumerable<SearchResultEntry>> FindAllEntriesByFilterAsync(string filter, string[] propertiesToLoad)
        {
            const int PageSize = 1000;
            var entries = new List<SearchResultEntry>();
            byte[] cookie = null;
            try
            {
                using (var connection = new LdapConnection(_domainName))
                {
                    connection.SessionOptions.ProtocolVersion = 3;
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;
                    do
                    {
                        var pageRequestControl = new PageResultRequestControl(PageSize) { Cookie = cookie };


                        var searchRequest = new SearchRequest(
                            _baseDn,
                            filter,
                            SearchScope.Subtree,
                            propertiesToLoad
                        );

                        SearchOptionsControl SearchOptionsControl = new SearchOptionsControl(System.DirectoryServices.Protocols.SearchOption.DomainScope);

                        searchRequest.Controls.Add(pageRequestControl);
                        searchRequest.Controls.Add(SearchOptionsControl);

                        var response = await Task.Factory.FromAsync(
                            (cb, s) => connection.BeginSendRequest(searchRequest, PartialResultProcessing.NoPartialResultSupport, cb, s),
                            (ar) => connection.EndSendRequest(ar),
                            null) as SearchResponse;

                        if (response == null || response?.Entries == null) break;
                        entries.AddRange(response.Entries.Cast<SearchResultEntry>());



                        var pageResponseControl = response.Controls.OfType<PageResultResponseControl>()
                                                                                .FirstOrDefault();
                        if (pageResponseControl == null)
                        {
                            Console.WriteLine("No PageResultResponseControl found - this may indicate all results retrieved");
                            break;
                        }

                        cookie = pageResponseControl?.Cookie;

                    } while (cookie != null && cookie.Length > 0);
                }
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LDAP Exception: {ex.Message}");
            }
            return entries;
        }
        private async Task<SearchResultEntry> FindSingleEntryByAttributeAsync(string objectClass, string attributeName, string attributeValue, string[] propertiesToLoad)
        {
            string filter = $"(&(objectClass={objectClass})({attributeName}={EscapeLdapFilter(attributeValue)}))";
            return await FindSingleEntryByFilterAsync(filter, propertiesToLoad);
        }
        private async Task<SearchResultEntry> FindSingleEntryByFilterAsync(string filter, string[] propertiesToLoad, string searchBase = null, SearchScope searchScope = SearchScope.Subtree)
        {
            try
            {
                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;

                    var searchRequest = new SearchRequest(
                        searchBase ?? _baseDn,
                        filter,
                        searchScope,
                        propertiesToLoad
                    );
                    searchRequest.SizeLimit = 1;

                    var response = await Task.Factory.FromAsync(
                        (asyncCallback, state) => connection.BeginSendRequest(searchRequest, PartialResultProcessing.ReturnPartialResults, asyncCallback, state),
                        (asyncResult) => connection.EndSendRequest(asyncResult),
                        null) as SearchResponse;

                    return response?.Entries.Count > 0 ? response.Entries[0] : null;
                }
            }
            catch (LdapException ex)
            {
                Log.Error($"LDAP Exception: {ex.Message}");
                return null;
            }
        }



        public async Task<Dictionary<string, ActiveDirectoryMember>> GetManagersByEmailsAsync(List<string> employeeEmails, bool includeProfileImage = false, string imageResolution = "96x96")
        {
            if (employeeEmails == null || !employeeEmails.Any())
            {
                return new Dictionary<string, ActiveDirectoryMember>();
            }

            var emailFilters = employeeEmails
                .Select(email => $"(mail={EscapeLdapFilter(email)})")
                .ToList();

            var userSearchFilter = $"(&(objectClass=user)(|{string.Join("", emailFilters)}))";

            var propertiesToLoad = new[] { "mail", "manager", "distinguishedName" };
            var userEntries = await FindAllEntriesByFilterAsync(userSearchFilter, propertiesToLoad);

            if (userEntries == null || !userEntries.Any())
            {
                return new Dictionary<string, ActiveDirectoryMember>();
            }

            var managerDnByEmail = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var uniqueManagerDns = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            foreach (var entry in userEntries)
            {
                string email = GetProperty(entry, "mail");
                string managerDn = GetProperty(entry, "manager");

                if (!string.IsNullOrEmpty(email))
                {
                    managerDnByEmail[email] = managerDn;

                    if (!string.IsNullOrEmpty(managerDn))
                    {
                        uniqueManagerDns.Add(managerDn);
                    }
                }
            }

            if (!uniqueManagerDns.Any())
            {
                return managerDnByEmail
                    .ToDictionary(kvp => kvp.Key, kvp => (ActiveDirectoryMember)null, StringComparer.OrdinalIgnoreCase);
            }


            var managerFilters = uniqueManagerDns
                .Select(dn => $"(distinguishedName={EscapeLdapFilter(dn)})")
                .ToList();

            var managerSearchFilter = $"(&(objectClass=user)(|{string.Join("", managerFilters)}))";


            var managerEntries = await FindAllEntriesByFilterAsync(managerSearchFilter, _userProperties);


            var managerByDn = new Dictionary<string, ActiveDirectoryMember>(StringComparer.OrdinalIgnoreCase);
            foreach (var entry in managerEntries)
            {
                string dn = GetProperty(entry, "distinguishedName");
                if (!string.IsNullOrEmpty(dn))
                {
                    managerByDn[dn] = MapSearchResultToMember(entry, includeExtendedData: false);
                }
            }

            var finalResult = new Dictionary<string, ActiveDirectoryMember>(StringComparer.OrdinalIgnoreCase);
            foreach (var kvp in managerDnByEmail)
            {
                string email = kvp.Key;
                string managerDn = kvp.Value;

                if (string.IsNullOrEmpty(managerDn))
                {
                    finalResult[email] = null;
                }
                else
                {

                    managerByDn.TryGetValue(managerDn, out var managerMember);
                    finalResult[email] = managerMember;
                }
            }

            if (includeProfileImage && finalResult.Any())
            {
                var managersFound = finalResult.Values.Where(m => m != null).ToList();

                await _profileImageService.PopulateImagesParallelAsync(managersFound, imageResolution);
            }
            return finalResult;
        }

        public async Task<Dictionary<string, ActiveDirectoryMember>> GetHodsByEmailsAsync(List<string> employeeEmails, bool includeProfileImage = false, string imageResolution = "96x96")
        {
            if (employeeEmails == null || !employeeEmails.Any())
            {
                return new Dictionary<string, ActiveDirectoryMember>();
            }

            var emailFilters = employeeEmails
                .Select(email => $"(mail={EscapeLdapFilter(email)})")
                .ToList();

            var userSearchFilter = $"(&(objectClass=user)(|{string.Join("", emailFilters)}))";

            var userEntries = await FindAllEntriesByFilterAsync(userSearchFilter, new[] { "mail", "distinguishedName" });

            var dnByEmail = userEntries
                .ToDictionary(entry => GetProperty(entry, "mail"),
                              entry => GetProperty(entry, "distinguishedName"),
                              StringComparer.OrdinalIgnoreCase);


            var finalResult = new Dictionary<string, ActiveDirectoryMember>(StringComparer.OrdinalIgnoreCase);

            var hodCache = new Dictionary<string, ActiveDirectoryMember>();

            foreach (var email in employeeEmails)
            {
                if (dnByEmail.TryGetValue(email, out var userDn))
                {
                    var visitedDns = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

                    finalResult[email] = await FindHodRecursiveAsync(userDn, visitedDns, hodCache);
                }
                else
                {
                    finalResult[email] = null;
                }
            }

            if (includeProfileImage && finalResult.Any())
            {
                var managersFound = finalResult.Values.Where(m => m != null).ToList();

                await _profileImageService.PopulateImagesParallelAsync(managersFound, imageResolution);
            }
            return finalResult;
        }

        public async Task<AccountStatusInfo> GetAccountStatusAsync(string userIdentifier)
        {
            if (string.IsNullOrEmpty(userIdentifier)) return null;

            string escapedQuery = EscapeLdapFilter(userIdentifier);

            var filter = $"(&(objectClass=user)(| (sAMAccountName={escapedQuery})(mail={escapedQuery})(displayName={escapedQuery})(extensionattribute1={escapedQuery})(mobile={escapedQuery})))";


            //  string filter = $"(&(objectClass=user)(mail={EscapeLdapFilter(email)}))";

            string[] propertiesToLoad = new[] { "userAccountControl", "lockoutTime", "pwdLastSet", "mail" };

            var entry = await FindSingleEntryByFilterAsync(filter, propertiesToLoad);

            if (entry == null) return null;

            var status = new AccountStatusInfo
            {
                Email = GetProperty(entry, "mail"),
                IsEnabled = true,
                IsLocked = false,
                IsPasswordExpired = false
            };

            // 1. Check UserAccountControl (UAC)
            string uacStr = GetProperty(entry, "userAccountControl");
            if (int.TryParse(uacStr, out int uac))
            {
                // 0x0002 is the bit flag for ADS_UF_ACCOUNTDISABLE
                // If the bit is set, the account is disabled
                if ((uac & 0x0002) == 0x0002)
                {
                    status.IsEnabled = false;
                }
            }

            // 2. Check LockoutTime
            string lockoutTimeStr = GetProperty(entry, "lockoutTime");
            if (long.TryParse(lockoutTimeStr, out long lockoutFileTime))
            {
                // If lockoutTime is 0, it's not locked. 
                if (lockoutFileTime > 0)
                {
                    status.LockoutTime = DateTime.FromFileTime(lockoutFileTime);
                    status.IsLocked = true;
                }
            }
            // 3. Check Password Last Set 
            string pwdLastSetStr = GetProperty(entry, "pwdLastSet");
            if (long.TryParse(pwdLastSetStr, out long pwdLastSetFileTime))
            {
                if (pwdLastSetFileTime == 0)
                {
                    // 0 usually means "User must change password at next logon"
                    status.IsPasswordExpired = true;
                }
                else if (pwdLastSetFileTime > 0)
                {
                    status.PasswordLastSet = DateTime.FromFileTime(pwdLastSetFileTime);
                }
            }

            return status;
        }


        private async Task<ActiveDirectoryMember> FindHodRecursiveAsync(
            string currentUserDn,
            HashSet<string> visitedDns,
            Dictionary<string, ActiveDirectoryMember> hodCache)
        {
            if (string.IsNullOrEmpty(currentUserDn))
            {
                return null;
            }

            if (hodCache.TryGetValue(currentUserDn, out var cachedHod))
            {
                return cachedHod;
            }

            if (!visitedDns.Add(currentUserDn))
            {
                return null;
            }

            var filter = $"(&(objectClass=user)(distinguishedName={EscapeLdapFilter(currentUserDn)}))";
            var entry = await FindSingleEntryByFilterAsync(filter, _userProperties);

            if (entry == null)
            {
                return null;
            }

            var member = MapSearchResultToMember(entry, includeExtendedData: true);

            ActiveDirectoryMember result = null;
            string jobTitle = member.JobTitle ?? "";

            if (jobTitle.IndexOf("Director", StringComparison.OrdinalIgnoreCase) >= 0 ||
                jobTitle.IndexOf("CEO", StringComparison.OrdinalIgnoreCase) >= 0 ||
                jobTitle.IndexOf("Chief", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                result = null;
            }
            else if (jobTitle.IndexOf("Head", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                result = member;
            }
            else
            {
                string managerDn = member.Manager;
                if (string.IsNullOrEmpty(managerDn))
                {
                    result = null;
                }
                else
                {
                    var managerFilter = $"(&(objectClass=user)(distinguishedName={EscapeLdapFilter(managerDn)}))";

                    var managerEntry = await FindSingleEntryByFilterAsync(managerFilter, new[] { "jobTitle" });
                    string managerJobTitle = GetProperty(managerEntry, "jobTitle") ?? "";

                    if (managerJobTitle.IndexOf("Director", StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        result = member;
                    }
                    else
                    {
                        result = await FindHodRecursiveAsync(member.Manager, visitedDns, hodCache);
                    }
                }
            }
            hodCache[currentUserDn] = result;
            return result;
        }

        /// <summary>
        /// Returns all raw Active Directory attributes for a user as a dictionary.
        /// Suitable for inspection/debugging via Postman.
        /// Multi-value attributes are returned as string arrays; single values as strings.
        /// </summary>
        /// <param name="userIdentifier">Email, sAMAccountName, displayName, staffId, or mobile</param>
        /// <returns>Dictionary of attribute name → value (string or string[])</returns>
        public async Task<Dictionary<string, object>> GetUserRawAttributesAsync(string userIdentifier)
        {
            if (string.IsNullOrWhiteSpace(userIdentifier))
                return null;

            string escapedQuery = EscapeLdapFilter(userIdentifier);

            var filter = $"(&(objectClass=user)(|" +
                         $"(sAMAccountName={escapedQuery})" +
                         $"(mail={escapedQuery})" +
                         $"(displayName={escapedQuery})" +
                         $"(extensionattribute1={escapedQuery})" +
                         $"(mobile={escapedQuery})" +
                         $"))";

            try
            {
                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;
                    connection.SessionOptions.ProtocolVersion = 3;

                    // Pass null (or empty array) to retrieve ALL attributes
                    var searchRequest = new SearchRequest(
                        _baseDn,
                        filter,
                        SearchScope.Subtree,
                        (string[])null   // <-- null = return all attributes
                    );
                    searchRequest.SizeLimit = 1;

                    var response = await Task.Factory.FromAsync(
                        (cb, s) => connection.BeginSendRequest(
                            searchRequest,
                            PartialResultProcessing.ReturnPartialResults,
                            cb, s),
                        ar => connection.EndSendRequest(ar),
                        null) as SearchResponse;

                    if (response == null || response.Entries.Count == 0)
                        return null;

                    var entry = response.Entries[0];
                    var result = new Dictionary<string, object>(StringComparer.OrdinalIgnoreCase);

                    // Always include the DN — it's not in the attribute collection
                    result["distinguishedName"] = entry.DistinguishedName;

                    foreach (DirectoryAttribute attr in entry.Attributes.Values)
                    {
                        var values = new List<string>();

                        for (int i = 0; i < attr.Count; i++)
                        {
                            var raw = attr[i];

                            if (raw is byte[] bytes)
                            {
                                // Binary attributes (e.g. thumbnailPhoto, objectGUID, objectSid)
                                // Return as Base64 so JSON stays valid
                                values.Add(Convert.ToBase64String(bytes));
                            }
                            else
                            {
                                values.Add(raw?.ToString() ?? string.Empty);
                            }
                        }

                        // Single value → plain string; multi-value → array
                        // This keeps the JSON clean and easy to read in Postman
                        result[attr.Name] = values.Count == 1
                            ? (object)values[0]
                            : values.ToArray();
                    }

                    return result;
                }
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LDAP Exception in GetUserRawAttributesAsync: {ex.Message}");
                return null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error in GetUserRawAttributesAsync: {ex.Message}");
                return null;
            }
        }




        /// <summary>
        /// Updates a single attribute on a user object in Active Directory.
        /// Pass null or empty string to clear the attribute.
        /// </summary>
        public async Task<bool> UpdateUserAttributeAsync(string userIdentifier, string attributeName, string value)
        {
            if (string.IsNullOrWhiteSpace(userIdentifier) || string.IsNullOrWhiteSpace(attributeName))
                return false;

            string escapedQuery = EscapeLdapFilter(userIdentifier);
            var filter = $"(&(objectClass=user)(|" +
                         $"(sAMAccountName={escapedQuery})" +
                         $"(mail={escapedQuery})" +
                         $"(displayName={escapedQuery})" +
                         $"(extensionattribute1={escapedQuery})" +
                         $"(mobile={escapedQuery})" +
                         $"))";

            try
            {
                var userEntry = await FindSingleEntryByFilterAsync(filter, new[] { "distinguishedName" });
                if (userEntry == null)
                {
                    Console.WriteLine($"UpdateUserAttributeAsync: User not found for identifier '{userIdentifier}'.");
                    return false;
                }

                string userDn = GetProperty(userEntry, "distinguishedName");
                if (string.IsNullOrEmpty(userDn))
                    return false;

                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;
                    connection.SessionOptions.ProtocolVersion = 3;

                    DirectoryAttributeModification mod;

                    if (string.IsNullOrEmpty(value))
                    {
                        // Clear the attribute entirely
                        mod = new DirectoryAttributeModification
                        {
                            Name = attributeName,
                            Operation = DirectoryAttributeOperation.Delete
                        };
                    }
                    else
                    {
                        // Replace existing value (works whether attribute exists or not)
                        mod = new DirectoryAttributeModification
                        {
                            Name = attributeName,
                            Operation = DirectoryAttributeOperation.Replace
                        };
                        mod.Add(value);
                    }

                    var modifyRequest = new ModifyRequest(userDn, mod);

                    var response = await Task.Factory.FromAsync(
                        (cb, s) => connection.BeginSendRequest(
                            modifyRequest,
                            PartialResultProcessing.NoPartialResultSupport,
                            cb, s),
                        ar => connection.EndSendRequest(ar),
                        null) as ModifyResponse;

                    if (response == null || response.ResultCode != ResultCode.Success)
                    {
                        Console.WriteLine($"UpdateUserAttributeAsync failed: {response?.ResultCode} - {response?.ErrorMessage}");
                        return false;
                    }

                    return true;
                }
            }
            catch (DirectoryOperationException ex)
            {
                // Thrown when e.g. the attribute name is invalid or schema violation
                Console.WriteLine($"DirectoryOperationException in UpdateUserAttributeAsync: {ex.Message} | Result: {ex.Response?.ErrorMessage}");
                return false;
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LdapException in UpdateUserAttributeAsync: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error in UpdateUserAttributeAsync: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Enables a disabled Active Directory user account
        /// by clearing the ADS_UF_ACCOUNTDISABLE bit (0x0002) from userAccountControl.
        /// </summary>
        public async Task<bool> EnableUserAccountAsync(string userIdentifier)
        {
            return await SetAccountEnabledStateAsync(userIdentifier, enabled: true);
        }



        /// <summary>
        /// Unlocks a locked-out Active Directory user account
        /// by setting lockoutTime to 0.
        /// Does NOT reset the password or change any other attribute.
        /// </summary>
        public async Task<bool> UnlockUserAccountAsync(string userIdentifier)
        {
            if (string.IsNullOrWhiteSpace(userIdentifier))
                return false;

            string escapedQuery = EscapeLdapFilter(userIdentifier);
            var filter = $"(&(objectClass=user)(|" +
                         $"(sAMAccountName={escapedQuery})" +
                         $"(mail={escapedQuery})" +
                         $"(displayName={escapedQuery})" +
                         $"(extensionattribute1={escapedQuery})" +
                         $"(mobile={escapedQuery})" +
                         $"))";

            try
            {
                var userEntry = await FindSingleEntryByFilterAsync(filter, new[] { "distinguishedName", "lockoutTime" });
                if (userEntry == null)
                {
                    Console.WriteLine($"UnlockUserAccountAsync: User not found for '{userIdentifier}'.");
                    return false;
                }

                string userDn = GetProperty(userEntry, "distinguishedName");
                if (string.IsNullOrEmpty(userDn))
                    return false;

                // Check if actually locked before hitting AD with a write
                string lockoutTimeStr = GetProperty(userEntry, "lockoutTime");
                if (long.TryParse(lockoutTimeStr, out long lockoutTime) && lockoutTime == 0)
                {
                    // Already unlocked — idempotent success
                    return true;
                }

                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;
                    connection.SessionOptions.ProtocolVersion = 3;

                    // Setting lockoutTime to "0" unlocks the account in AD
                    var mod = new DirectoryAttributeModification
                    {
                        Name = "lockoutTime",
                        Operation = DirectoryAttributeOperation.Replace
                    };
                    mod.Add("0");

                    var modifyRequest = new ModifyRequest(userDn, mod);

                    var response = await Task.Factory.FromAsync(
                        (cb, s) => connection.BeginSendRequest(
                            modifyRequest,
                            PartialResultProcessing.NoPartialResultSupport,
                            cb, s),
                        ar => connection.EndSendRequest(ar),
                        null) as ModifyResponse;

                    if (response == null || response.ResultCode != ResultCode.Success)
                    {
                        Console.WriteLine($"UnlockUserAccountAsync failed: {response?.ResultCode} - {response?.ErrorMessage}");
                        return false;
                    }

                    return true;
                }
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LdapException in UnlockUserAccountAsync: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error in UnlockUserAccountAsync: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Searches AD groups by name (cn), email, or description.
        /// Returns lightweight group objects suitable for autocomplete or admin UIs.
        /// </summary>
        /// <param name="query">Partial or full group name, email, or description</param>
        /// <param name="limit">Max results to return (default 10)</param>
        /// <param name="groupType">Optional filter: "security", "distribution", or null for all</param>
        public async Task<List<ActiveDirectoryGroup>> SearchGroupsAsync(
            string query,
            int limit = 10,
            string groupType = null)
        {
            if (string.IsNullOrWhiteSpace(query))
                return new List<ActiveDirectoryGroup>();

            if (limit <= 0) limit = 10;

            string escapedQuery = EscapeLdapFilter(query);

            // groupType filter using groupType attribute bit flags:
            // Security group       = bit 0x80000000 set in groupType
            // Distribution group   = bit 0x80000000 NOT set
            string groupTypeFilter = string.Empty;
            if (!string.IsNullOrWhiteSpace(groupType))
            {
                if (groupType.Equals("security", StringComparison.OrdinalIgnoreCase))
                {
                    // Security groups have the high bit set (value is negative in AD, e.g. -2147483646)
                    groupTypeFilter = $"(groupType:{LdapMatchingRuleBitwise}:=2147483648)";
                }
                else if (groupType.Equals("distribution", StringComparison.OrdinalIgnoreCase))
                {
                    // Distribution groups do NOT have 0x80000000 set
                    groupTypeFilter = $"(!(groupType:{LdapMatchingRuleBitwise}:=2147483648))";
                }
            }

            var filter = $"(&(objectClass=group){groupTypeFilter}(|" +
                         $"(cn={escapedQuery}*)" +
                         $"(mail={escapedQuery}*)" +
                         $"(description={escapedQuery}*)" +
                         $"))";

            string[] properties = { "cn", "mail", "description", "groupType", "distinguishedName", "memberOf", "member" };

            var entries = await FindMultipleEntriesByFilterAsync(filter, properties, limit);

            if (entries == null || entries.Count == 0)
                return new List<ActiveDirectoryGroup>();

            return entries.Select(MapSearchResultToGroup).ToList();
        }

        public async Task<IEnumerable<ActiveDirectoryMember>> GetAllHodsAsync(
            HodFilter filters = null,
            bool includeProfileImage = false,
            string imageResolution = "96x96")
        {
            return await GetUsersByManagementLevelAsync(
               HodAttributeValue,
                filters,
                includeProfileImage,
                imageResolution);
        }
        public async Task<IEnumerable<ActiveDirectoryMember>> GetAllExcoAsync(
    HodFilter filters = null,
    bool includeProfileImage = false,
    string imageResolution = "96x96")
        {
            return await GetUsersByManagementLevelAsync(
               ExcoAttributeValue,
                filters,
                includeProfileImage,
                imageResolution);
        }


        public async Task<AdChangedGroupsResponseDto> GetChangedGroupsAsync(
            long fromUsn,
            string domainControllerName = null)
        {
            var totalWatch = System.Diagnostics.Stopwatch.StartNew();
            string stage = "Validation";
            int pageNumber = 0;
            int ldapResultCount = 0;

            Log.Information(
                "[GROUP LDAP][START] FromUSN={FromUSN}, RequestedDC={DC}, Utc={Utc}",
                fromUsn, domainControllerName ?? "(discovery)", DateTime.UtcNow);

            try
            {
                if (fromUsn < 0 || fromUsn == long.MaxValue)
                    throw new ArgumentOutOfRangeException(nameof(fromUsn));

                string server = string.IsNullOrWhiteSpace(domainControllerName)
                    ? _domainName
                    : domainControllerName.Trim();

                var groups = new List<Dictionary<string, object>>();
                Log.Information("[GROUP LDAP][CONNECT START] Server={Server}", server);
                var stepWatch = System.Diagnostics.Stopwatch.StartNew();

                using (var connection = new LdapConnection(server))
                {
                    connection.SessionOptions.ProtocolVersion = 3;
                    connection.SessionOptions.ReferralChasing = ReferralChasingOptions.None;
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;
                    connection.Timeout = TimeSpan.FromMinutes(3);
                    connection.Bind();

                    Log.Information("[GROUP LDAP][CONNECT DONE] Seconds={Seconds:F2}",
                        stepWatch.Elapsed.TotalSeconds);

                    // 1. RootDSE checkpoint metadata.
                    stage = "RootDSE";
                    stepWatch.Restart();
                    Log.Information("[GROUP LDAP][ROOTDSE START]");
                    var rootRequest = new SearchRequest(
                        "",
                        "(objectClass=*)",
                        SearchScope.Base,
                        "dnsHostName",
                        "highestCommittedUSN",
                        "dsServiceName",
                        "defaultNamingContext");

                    var rootResponse = await SendLdapRequestAsync(connection, rootRequest);
                    Log.Information("[GROUP LDAP][ROOTDSE RESPONSE] Entries={Count}, Seconds={Seconds:F2}",
                        rootResponse.Entries.Count, stepWatch.Elapsed.TotalSeconds);

                    if (rootResponse.Entries.Count != 1)
                        throw new InvalidOperationException("RootDSE not found.");

                    var root = rootResponse.Entries[0];
                    string dcName = GetRequiredAttribute(root, "dnsHostName");
                    string serviceDn = GetRequiredAttribute(root, "dsServiceName");
                    long toUsn = long.Parse(
                        GetRequiredAttribute(root, "highestCommittedUSN"),
                        System.Globalization.CultureInfo.InvariantCulture);

                    Log.Information(
                        "[GROUP LDAP][ROOTDSE DONE] DC={DC}, FromUSN={FromUSN}, ToUSN={ToUSN}, " +
                        "SearchBase={SearchBase}, Seconds={Seconds:F2}",
                        dcName, fromUsn, toUsn, _baseDn, stepWatch.Elapsed.TotalSeconds);

                    if (toUsn < fromUsn)
                        throw new InvalidOperationException("Invalid USN watermark.");

                    if (!string.IsNullOrWhiteSpace(domainControllerName) &&
                        !string.Equals(dcName, domainControllerName,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        throw new InvalidOperationException("Connected to a different Domain Controller.");
                    }

                    // 2. DC invocation ID.
                    stage = "Invocation ID";
                    stepWatch.Restart();
                    Log.Information("[GROUP LDAP][INVOCATION START]");
                    var invocationRequest = new SearchRequest(
                        serviceDn, "(objectClass=*)", SearchScope.Base, "invocationID");
                    var invocationResponse = await SendLdapRequestAsync(connection, invocationRequest);

                    if (invocationResponse.Entries.Count != 1)
                        throw new InvalidOperationException("NTDS Settings not found.");

                    var invocationAttribute =
                        invocationResponse.Entries[0].Attributes["invocationID"];

                    if (invocationAttribute == null ||
                        invocationAttribute.Count == 0 ||
                        !(invocationAttribute[0] is byte[] invocationBytes) ||
                        invocationBytes.Length != 16)
                    {
                        throw new InvalidOperationException("Invalid invocationID.");
                    }

                    Guid invocationId = new Guid(invocationBytes);
                    Log.Information(
                        "[GROUP LDAP][INVOCATION DONE] InvocationId={InvocationId}, Seconds={Seconds:F2}",
                        invocationId, stepWatch.Elapsed.TotalSeconds);

                    // 3. Full or Incremental filter.
                    string filter = fromUsn == 0
                        ? "(objectCategory=group)"
                        : "(&(objectCategory=group)" +
                          "(uSNChanged>=" + (fromUsn + 1) + ")" +
                          "(uSNChanged<=" + toUsn + "))";

                    string[] propertiesToLoad =
                     {
                        // Identity
                        "objectGUID",
                        "distinguishedName",
                        "name",
                        "displayName",
                        "sAMAccountName",

                        // Details
                        "description",
                        "managedBy",

                        // Email
                        "mail",

                        // Incremental tracking
                        "uSNChanged",

                        // Relationships
                        "member",
                        "memberOf"
                    };

                    const int pageSize = 1000;
                    byte[] cookie = null;
                    Log.Information(
                        "[GROUP LDAP][SEARCH PREPARED] Mode={Mode}, BaseDN={BaseDN}, " +
                        "Filter={Filter}, PageSize={PageSize}, AttributeCount={AttributeCount}",
                        fromUsn == 0 ? "Full" : "Incremental", _baseDn,
                        filter, pageSize, propertiesToLoad.Length);

                    // 4. LDAP paged read and mapping.
                    stage = "LDAP paged group search";
                    var pagingWatch = System.Diagnostics.Stopwatch.StartNew();
                    if (fromUsn == 0 || fromUsn < toUsn)
                    {
                        do
                        {
                            pageNumber++;
                            int previousCount = groups.Count;
                            var pageWatch = System.Diagnostics.Stopwatch.StartNew();
                            Log.Information(
                                "[GROUP LDAP][PAGE START] Page={Page}, CookieBytes={CookieBytes}, " +
                                "TotalSoFar={Total}",
                                pageNumber, cookie?.Length ?? 0, previousCount);

                            var request = new SearchRequest(
                                _baseDn, filter, SearchScope.Subtree, propertiesToLoad);

                            request.Controls.Add(
                                new PageResultRequestControl(pageSize) { Cookie = cookie });
                            request.Controls.Add(
                                new SearchOptionsControl(
                                    System.DirectoryServices.Protocols.SearchOption.DomainScope));

                            var response = await SendLdapRequestAsync(connection, request);
                            Log.Information(
                                "[GROUP LDAP][PAGE LDAP DONE] Page={Page}, Entries={Count}, " +
                                "ResultCode={ResultCode}, LdapSeconds={Seconds:F2}",
                                pageNumber, response.Entries.Count, response.ResultCode,
                                pageWatch.Elapsed.TotalSeconds);

                            ldapResultCount += response.Entries.Count;

                            // Mapping timer is separate so LDAP latency and CPU mapping are distinguishable.
                            var mappingWatch = System.Diagnostics.Stopwatch.StartNew();
                            foreach (SearchResultEntry entry in response.Entries)
                            {
                                var group = new Dictionary<string, object>(
                                    StringComparer.OrdinalIgnoreCase);

                                foreach (DirectoryAttribute attr in entry.Attributes.Values)
                                {
                                    var values = new List<string>();
                                    for (int i = 0; i < attr.Count; i++)
                                    {
                                        object raw = attr[i];

                                        if (raw is byte[] bytes)
                                        {
                                            if (attr.Name.Equals("objectGUID",
                                                StringComparison.OrdinalIgnoreCase) && bytes.Length == 16)
                                            {
                                                values.Add(new Guid(bytes).ToString());
                                            }
                                            else if (attr.Name.Equals("uSNChanged",
                                                StringComparison.OrdinalIgnoreCase))
                                            {
                                                values.Add(System.Text.Encoding.UTF8.GetString(bytes));
                                            }
                                            else
                                            {
                                                values.Add(Convert.ToBase64String(bytes));
                                            }
                                        }
                                        else
                                        {
                                            values.Add(raw?.ToString() ?? "");
                                        }
                                    }

                                    group[attr.Name] = values.Count == 1
                                        ? (object)values[0]
                                        : values.ToArray();
                                }

                                group["distinguishedName"] = entry.DistinguishedName;
                                groups.Add(group);
                            }

                            Log.Information(
                                "[GROUP LDAP][PAGE MAPPING DONE] Page={Page}, Mapped={Count}, " +
                                "MappingSeconds={Seconds:F2}",
                                pageNumber, groups.Count - previousCount,
                                mappingWatch.Elapsed.TotalSeconds);

                            var paging = response.Controls
                                .OfType<PageResultResponseControl>()
                                .FirstOrDefault();

                            if (paging == null)
                                throw new InvalidOperationException("LDAP paging response is missing.");

                            cookie = paging.Cookie;
                            Log.Information(
                                "[GROUP LDAP][PAGE COMPLETE] Page={Page}, Total={Total}, " +
                                "NextCookieBytes={NextCookieBytes}, PageTotalSeconds={Seconds:F2}",
                                pageNumber, groups.Count, cookie?.Length ?? 0,
                                pageWatch.Elapsed.TotalSeconds);
                        }
                        while (cookie != null && cookie.Length > 0);
                    }
                    else
                    {
                        Log.Information("[GROUP LDAP][NO USN WINDOW] Search skipped: FromUSN={From} ToUSN={To}",
                            fromUsn, toUsn);
                    }

                    Log.Information(
                        "[GROUP LDAP][ALL PAGES COMPLETE] Pages={Pages}, Entries={Entries}, " +
                        "Groups={Groups}, Seconds={Seconds:F2}",
                        pageNumber, ldapResultCount, groups.Count, pagingWatch.Elapsed.TotalSeconds);
                    System.Diagnostics.Debug.WriteLine(
                        $"[GROUP LDAP][ALL PAGES COMPLETE] Pages={pageNumber}, Groups={groups.Count}, " +
                        $"Time={pagingWatch.Elapsed.TotalSeconds:F2}s");

                    // 5. Validate data shape before SQL upsert.
                    stage = "Validating LDAP attributes";
                    var validationWatch = System.Diagnostics.Stopwatch.StartNew();
                    int withName = groups.Count(g =>
                        g.TryGetValue("name", out var value) &&
                        !string.IsNullOrWhiteSpace(Convert.ToString(value)));
                    int withMail = groups.Count(g =>
                        g.TryGetValue("mail", out var value) &&
                        !string.IsNullOrWhiteSpace(Convert.ToString(value)));
                    int withDisplayName = groups.Count(g =>
                        g.TryGetValue("displayName", out var value) &&
                        !string.IsNullOrWhiteSpace(Convert.ToString(value)));
                    int rangedGroups = groups.Count(g =>
                        g.Keys.Any(k => k.StartsWith("member;range=",
                            StringComparison.OrdinalIgnoreCase)));
                    int withMembers = groups.Count(g => g.ContainsKey("member"));
                    int withoutMembers = groups.Count - withMembers - rangedGroups;

                    Log.Information(
                        "[GROUP LDAP][ATTRIBUTES CHECK] Groups={Groups}, Name={Names}, " +
                        "DisplayName={DisplayNames}, Mail={Mails}, Member={WithMembers}, " +
                        "Ranged={Ranged}, NoMember={NoMember}, Seconds={Seconds:F2}",
                        groups.Count, withName, withDisplayName, withMail,
                        withMembers, rangedGroups, withoutMembers,
                        validationWatch.Elapsed.TotalSeconds);

                    if (withName != groups.Count)
                        throw new InvalidOperationException(
                            $"AD returned {groups.Count - withName} groups without a valid name. Sync cancelled.");

                    // 6. Finish ranged members. No extra LDAP search if none are ranged.
                    stage = "Completing member ranges";
                    var rangesWatch = System.Diagnostics.Stopwatch.StartNew();
                    Log.Information("[GROUP LDAP][RANGES START] GroupsNeedingCompletion={Count}", rangedGroups);
                    await CompleteGroupMemberRangesAsync(connection, groups);
                    Log.Information(
                        "[GROUP LDAP][RANGES COMPLETE] Seconds={Seconds:F2}, RemainingRanged={Remaining}",
                        rangesWatch.Elapsed.TotalSeconds,
                        groups.Count(g => g.Keys.Any(k => k.StartsWith("member;range=",
                            StringComparison.OrdinalIgnoreCase))));

                    // This marker means RootDSE + InvocationID + all paged LDAP + all member ranges finished.
                    Log.Information(
                        "[GROUP LDAP][ALL REQUESTS COMPLETE] Groups={Groups}, Pages={Pages}, " +
                        "RangedGroups={Ranged}, TotalSeconds={Seconds:F2}",
                        groups.Count, pageNumber, rangedGroups, totalWatch.Elapsed.TotalSeconds);
                    System.Diagnostics.Debug.WriteLine(
                        $"[GROUP LDAP][ALL REQUESTS COMPLETE] Groups={groups.Count}, " +
                        $"Pages={pageNumber}, Total={totalWatch.Elapsed.TotalSeconds:F2}s");

                    return new AdChangedGroupsResponseDto
                    {
                        Groups = groups,
                        FromUsn = fromUsn,
                        ToUsn = toUsn,
                        DomainControllerName = dcName,
                        InvocationId = invocationId
                    };
                }
            }
            catch (Exception ex)
            {
                Log.Error(ex,
                    "[GROUP LDAP][FAILED] Stage={Stage}, Page={Page}, Received={Received}, " +
                    "ElapsedSeconds={Seconds:F2}",
                    stage, pageNumber, ldapResultCount, totalWatch.Elapsed.TotalSeconds);
                throw;
            }
        }


        public async Task<AdChangedUsersResponseDto> GetChangedUsersAsync(
            long fromUsn,
            string domainControllerName = null)
        {
            if (fromUsn < 0 || fromUsn == long.MaxValue)
                throw new ArgumentException("Invalid fromUsn.");

            const int pageSize = 500;


            var users = new List<Dictionary<string, object>>();

            string server = string.IsNullOrWhiteSpace(domainControllerName)
                ? _domainName
                : domainControllerName.Trim();



            using (var connection = new LdapConnection(server))
            {
                connection.SessionOptions.ProtocolVersion = 3;
                connection.Credential = _serviceAccountCredentials;
                connection.AuthType = AuthType.Kerberos;
                connection.Timeout = TimeSpan.FromMinutes(3);

                connection.SessionOptions.ReferralChasing = ReferralChasingOptions.None;

                connection.Bind();

                // STEP 1: Read the current DC information.
                // Both metadata and users are read on the same connection.


                var rootRequest = new SearchRequest(
                    "",
                    "(objectClass=*)",
                    SearchScope.Base,
                    "dnsHostName",
                    "highestCommittedUSN",
                    "dsServiceName",
                    "defaultNamingContext"
                );


                SearchResponse rootResponse =
                    await SendLdapRequestAsync(connection, rootRequest);





                if (rootResponse.Entries.Count != 1)
                    throw new InvalidOperationException(
                        "Unable to read RootDSE.");

                SearchResultEntry root = rootResponse.Entries[0];

                string searchBaseDn =
                        GetRequiredAttribute(root, "defaultNamingContext");

                string dcName = GetRequiredAttribute(root, "dnsHostName");





                if (!string.IsNullOrWhiteSpace(domainControllerName) &&
                    !string.Equals(
                        dcName,
                        domainControllerName,
                        StringComparison.OrdinalIgnoreCase))
                {
                    throw new InvalidOperationException(
                        "Connected to a different Domain Controller.");
                }



                string serviceDn = GetRequiredAttribute(root, "dsServiceName");

                long toUsn = long.Parse(
                    GetRequiredAttribute(root, "highestCommittedUSN"),
                    System.Globalization.CultureInfo.InvariantCulture
                );

                if (fromUsn > toUsn)
                    throw new ArgumentException(
                        "fromUsn exceeds the current DC USN.");

                // STEP 2: Read the invocation ID.

                var invocationRequest = new SearchRequest(
                    serviceDn,
                    "(objectClass=*)",
                    SearchScope.Base,
                    "invocationID"
                );


                SearchResponse invocationResponse =
                    await SendLdapRequestAsync(connection, invocationRequest);

                if (invocationResponse.Entries.Count != 1)
                    throw new InvalidOperationException(
                        "Unable to read NTDS Settings.");

                var invocationAttribute =
                    invocationResponse.Entries[0].Attributes["invocationID"];

                if (invocationAttribute == null ||
                    invocationAttribute.Count == 0)
                {
                    throw new InvalidOperationException(
                        "Missing invocationID.");
                }

                byte[] invocationBytes =
                    invocationAttribute[0] as byte[];

                if (invocationBytes == null ||
                    invocationBytes.Length != 16)
                {
                    throw new InvalidOperationException(
                        "Invalid invocationID.");
                }

                Guid invocationId = new Guid(invocationBytes);


                // STEP 3: Build LDAP Filter.


                string filter;

                if (fromUsn == 0)
                {
                    filter =
                        "(&(objectCategory=person)" +
                        "(objectClass=user)" +
                        "(!(sAMAccountName=krbtgt*)))";
                }
                else
                {
                    filter =
                        "(&(objectCategory=person)" +
                        "(objectClass=user)" +
                        "(!(sAMAccountName=krbtgt*))" +
                        "(uSNChanged>=" + (fromUsn + 1) + ")" +
                        "(uSNChanged<=" + toUsn + "))";
                }


                string[] propertiesToLoad =
                {
                    "*",
                    "objectGUID",
                    "objectSid",
                    "uSNChanged"
                };

                byte[] cookie = new byte[0];
                int pageNumber = 0;

                // STEP 4: Read all LDAP pages.
                if (fromUsn == 0 || fromUsn < toUsn)
                {
                    do
                    {
                        pageNumber++;

                        var request = new SearchRequest(
                            searchBaseDn,
                            filter,
                            SearchScope.Subtree,
                            propertiesToLoad
                        );

                        request.Controls.Add(
                            new PageResultRequestControl(500)
                            {
                                Cookie = cookie,
                                IsCritical = true
                            });

                        request.Controls.Add(
                           new SearchOptionsControl(System.DirectoryServices.Protocols.SearchOption.DomainScope));


                        SearchResponse response =
                            await SendLdapRequestAsync(connection, request);


                        System.Diagnostics.Debug.WriteLine(
                            "Connected DC: " + dcName);

                        System.Diagnostics.Debug.WriteLine(
                            "Search Base: " + request.DistinguishedName);

                        System.Diagnostics.Debug.WriteLine(
                            "LDAP Filter: " + request.Filter);

                        System.Diagnostics.Debug.WriteLine(
                            "Requested Page Size: " + pageSize);

                        System.Diagnostics.Debug.WriteLine(
                            "Request SizeLimit: " + request.SizeLimit);

                        System.Diagnostics.Debug.WriteLine(
                            "Returned Users: " + response.Entries.Count);

                        System.Diagnostics.Debug.WriteLine(
                            "LDAP Result Code: " + response.ResultCode);

                        System.Diagnostics.Debug.WriteLine(
                            "LDAP Error: " + response.ErrorMessage);

                        var pagingResponse = response.Controls
                            .OfType<PageResultResponseControl>()
                            .FirstOrDefault();

                        System.Diagnostics.Debug.WriteLine(
                            "Paging Control Exists: " + (pagingResponse != null));

                        System.Diagnostics.Debug.WriteLine(
                            "Cookie Length: " +
                            (pagingResponse == null ||
                             pagingResponse.Cookie == null
                                ? 0
                                : pagingResponse.Cookie.Length));



                        foreach (SearchResultEntry entry in response.Entries)
                        {
                            users.Add(MapAdEntry(entry));
                        }

                        PageResultResponseControl pageResponse =
                            response.Controls
                                .OfType<PageResultResponseControl>()
                                .FirstOrDefault();

                        if (pageResponse == null)
                        {
                            throw new InvalidOperationException(
                                "LDAP paging control was not returned.");
                        }

                        cookie = pageResponse.Cookie;

                        System.Diagnostics.Debug.WriteLine(
                            "LDAP Page: " + pageNumber +
                            " | Page Users: " + response.Entries.Count +
                            " | Total Users: " + users.Count +
                            " | Cookie Length: " +
                            (cookie == null ? 0 : cookie.Length)
                        );

                    } while (cookie != null && cookie.Length > 0);
                }

                System.Diagnostics.Debug.WriteLine(
                    "LDAP SEARCH FINISHED. Total Users: " + users.Count);

                return new AdChangedUsersResponseDto
                {
                    DomainControllerName = dcName,
                    InvocationId = invocationId,
                    FromUsn = fromUsn,
                    ToUsn = toUsn,
                    ChangedUsersCount = users.Count,
                    Users = users
                };

            }
        }


        public async Task<AdUsnInfoDto> GetAdUsnInfoAsync()
        {
            using (var connection = new LdapConnection(_domainName))
            {
                connection.SessionOptions.ProtocolVersion = 3;
                connection.Credential = _serviceAccountCredentials;
                connection.AuthType = AuthType.Kerberos;

                connection.Timeout = TimeSpan.FromSeconds(30);

                connection.Bind();

                // STEP 1: Read RootDSE
                var rootRequest = new SearchRequest(
                    string.Empty,
                    "(objectClass=*)",
                    SearchScope.Base,
                    "dnsHostName",
                    "highestCommittedUSN",
                    "defaultNamingContext",
                    "dsServiceName"
                );

                var rootResponse = await SendLdapRequestAsync(
                    connection,
                    rootRequest);

                if (rootResponse.Entries.Count != 1)
                {
                    throw new InvalidOperationException(
                        "Unable to read Active Directory RootDSE.");
                }

                SearchResultEntry root = rootResponse.Entries[0];

                string domainControllerName =
                    GetRequiredAttribute(root, "dnsHostName");

                string defaultNamingContext =
                    GetRequiredAttribute(root, "defaultNamingContext");

                string dsServiceName =
                    GetRequiredAttribute(root, "dsServiceName");

                long highestCommittedUsn = long.Parse(
                    GetRequiredAttribute(root, "highestCommittedUSN"),
                    System.Globalization.CultureInfo.InvariantCulture
                );

                // STEP 2: Read invocationID
                // from the connected DC's NTDS Settings object.
                var invocationRequest = new SearchRequest(
                    dsServiceName,
                    "(objectClass=*)",
                    SearchScope.Base,
                    "invocationID"
                );

                var invocationResponse = await SendLdapRequestAsync(
                    connection,
                    invocationRequest);

                if (invocationResponse.Entries.Count != 1)
                {
                    throw new InvalidOperationException(
                        "Unable to read NTDS Settings.");
                }

                SearchResultEntry invocationEntry =
                    invocationResponse.Entries[0];

                if (!invocationEntry.Attributes.Contains("invocationID"))
                {
                    throw new InvalidOperationException(
                        "invocationID attribute was not returned.");
                }

                byte[] invocationBytes =
                    invocationEntry.Attributes["invocationID"][0] as byte[];

                if (invocationBytes == null || invocationBytes.Length != 16)
                {
                    throw new InvalidOperationException(
                        "Invalid invocationID format.");
                }

                return new AdUsnInfoDto
                {
                    DomainControllerName = domainControllerName,

                    DefaultNamingContext = defaultNamingContext,

                    HighestCommittedUsn = highestCommittedUsn,

                    InvocationId = new Guid(invocationBytes),

                    RetrievedAtUtc = DateTime.UtcNow
                };
            }
        }


        public async Task<List<Dictionary<string, object>>> GetUsersRawAttributesByDepartmentAsync(string department)
        {
            if (string.IsNullOrWhiteSpace(department))
                throw new ArgumentException("Department is required.");

            string escapedDepartment = EscapeLdapFilter(department.Trim());

            string filter = string.Format(
                "(&(objectCategory=person)(objectClass=user)(department={0}))",
                escapedDepartment
            );

            string[] propertiesToLoad = { "*", "objectGUID", "objectSid" };

            IEnumerable<SearchResultEntry> entries =
                await FindAllEntriesByFilterAsync(filter, propertiesToLoad);

            var users = new List<Dictionary<string, object>>();

            foreach (SearchResultEntry entry in entries)
            {
                var user = new Dictionary<string, object>(
                    StringComparer.OrdinalIgnoreCase);

                user["distinguishedName"] = entry.DistinguishedName;

                foreach (DirectoryAttribute attr in entry.Attributes.Values)
                {
                    var values = new List<string>();

                    for (int i = 0; i < attr.Count; i++)
                    {
                        object raw = attr[i];

                        if (raw is byte[])
                        {
                            byte[] bytes = (byte[])raw;

                            if (attr.Name.Equals("objectGUID",
                                StringComparison.OrdinalIgnoreCase) &&
                                bytes.Length == 16)
                            {
                                values.Add(new Guid(bytes).ToString());
                            }
                            else if (attr.Name.Equals("objectSid",
                                StringComparison.OrdinalIgnoreCase))
                            {
                                values.Add(
                                    new System.Security.Principal.SecurityIdentifier(
                                        bytes, 0).Value);
                            }
                            else
                            {
                                values.Add(Convert.ToBase64String(bytes));
                            }
                        }
                        else
                        {
                            values.Add(raw == null
                                ? string.Empty
                                : raw.ToString());
                        }
                    }

                    user[attr.Name] = values.Count == 1
                        ? (object)values[0]
                        : values.ToArray();
                }

                users.Add(user);
            }

            return users;
        }



        public async Task<AdExistingGuidsDto> GetExistingAdGuidsAsync(
            List<Guid> userGuids,
            List<Guid> groupGuids)
        {
            var result = new AdExistingGuidsDto();

            using (var connection = new LdapConnection(_domainName))
            {
                connection.SessionOptions.ProtocolVersion = 3;
                connection.SessionOptions.ReferralChasing =
                    ReferralChasingOptions.None;

                connection.Credential = _serviceAccountCredentials;
                connection.AuthType = AuthType.Kerberos;
                connection.Timeout = TimeSpan.FromMinutes(3);

                connection.Bind();

                result.UserGuids = await FindExistingGuidsAsync(
                    connection,
                    userGuids,
                    "(&(objectCategory=person)(objectClass=user)(!(sAMAccountName=krbtgt*)))");

                result.GroupGuids = await FindExistingGuidsAsync(
                    connection,
                    groupGuids,
                    "(objectCategory=group)");
            }

            return result;
        }

        private async Task<HashSet<Guid>> FindExistingGuidsAsync(
            LdapConnection connection,
            List<Guid> guids,
            string objectFilter)
        {
            const int batchSize = 100;

            var existing = new HashSet<Guid>();

            for (int i = 0; i < guids.Count; i += batchSize)
            {
                var batch = guids.Skip(i).Take(batchSize).ToList();
                var batchSet = new HashSet<Guid>(batch);

                var guidFilters = batch.Select(guid =>
                    "(objectGUID=" +
                    string.Concat(guid.ToByteArray()
                        .Select(b => "\\" + b.ToString("X2"))) +
                    ")");

                string filter =
                    "(&" + objectFilter +
                    "(|" + string.Concat(guidFilters) + "))";

                byte[] cookie = null;

                do
                {
                    var request = new SearchRequest(
                        _baseDn,
                        filter,
                        SearchScope.Subtree,
                        "objectGUID");

                    request.Controls.Add(
                        new PageResultRequestControl(200)
                        {
                            Cookie = cookie,
                            IsCritical = true
                        });

                    request.Controls.Add(
                        new SearchOptionsControl(
                            SearchOption.DomainScope));

                    var response = await SendLdapRequestAsync(
                        connection,
                        request);

                    if (response.ResultCode != ResultCode.Success)
                        throw new InvalidOperationException(
                            "LDAP GUID validation failed: " +
                            response.ResultCode);

                    foreach (SearchResultEntry entry in response.Entries)
                    {
                        var attr = entry.Attributes["objectGUID"];

                        if (attr == null ||
                            attr.Count != 1 ||
                            !(attr[0] is byte[] bytes) ||
                            bytes.Length != 16)
                        {
                            throw new InvalidOperationException(
                                "Invalid objectGUID returned from AD.");
                        }

                        var foundGuid = new Guid(bytes);

                        if (!batchSet.Contains(foundGuid))
                            throw new InvalidOperationException(
                                "Unexpected objectGUID returned from AD.");

                        existing.Add(foundGuid);
                    }

                    var paging = response.Controls
                        .OfType<PageResultResponseControl>()
                        .FirstOrDefault();

                    if (paging == null)
                        throw new InvalidOperationException(
                            "LDAP paging response is missing.");

                    cookie = paging.Cookie;

                } while (cookie != null && cookie.Length > 0);

                Log.Information(
                    "[AD DELETE CHECK] Checked={Checked}, FoundSoFar={Found}",
                    Math.Min(i + batchSize, guids.Count),
                    existing.Count);
            }

            return existing;
        }







        //======================== Helper method =======================
        private async Task<IEnumerable<ActiveDirectoryMember>> GetUsersByManagementLevelAsync(
    string managementLevel,
    HodFilter filters = null,
    bool includeProfileImage = false,
    string imageResolution = "96x96")
        {
            filters = filters ?? new HodFilter();

            var filterBuilder = new StringBuilder();

            filterBuilder.Append("(&");
            filterBuilder.Append("(objectCategory=person)");
            filterBuilder.Append("(objectClass=user)");

            // Mandatory management-level rule
            filterBuilder.Append(
                $"(VF-extensionAttribute04={EscapeLdapFilter(managementLevel)})");

            // Active users only by default
            if (!filters.IncludeDisabledUsers)
            {
                filterBuilder.Append(
                    $"(!(userAccountControl:{LdapMatchingRuleBitwise}:=2))");
            }

            if (!string.IsNullOrWhiteSpace(filters.Department))
            {
                filterBuilder.Append(
                    $"(department={EscapeLdapFilter(filters.Department.Trim())})");
            }

            if (!string.IsNullOrWhiteSpace(filters.SubDepartment))
            {
                filterBuilder.Append(
                    $"(extensionAttribute6={EscapeLdapFilter(filters.SubDepartment.Trim())})");
            }

            if (!string.IsNullOrWhiteSpace(filters.Company))
            {
                filterBuilder.Append(
                    $"(company={EscapeLdapFilter(filters.Company.Trim())})");
            }

            if (!string.IsNullOrWhiteSpace(filters.Office))
            {
                filterBuilder.Append(
                    $"(physicalDeliveryOfficeName={EscapeLdapFilter(filters.Office.Trim())})");
            }

            if (!string.IsNullOrWhiteSpace(filters.CostCenter))
            {
                filterBuilder.Append(
                    $"(extensionAttribute3={EscapeLdapFilter(filters.CostCenter.Trim())})");
            }

            if (!string.IsNullOrWhiteSpace(filters.JobTitle))
            {
                filterBuilder.Append(
                    $"(jobTitle=*{EscapeLdapFilter(filters.JobTitle.Trim())}*)");
            }

            if (!string.IsNullOrWhiteSpace(filters.NTAccount))
            {
                filterBuilder.Append(
                    $"(sAMAccountName={EscapeLdapFilter(filters.NTAccount.Trim())})");
            }

            if (!string.IsNullOrWhiteSpace(filters.Email))
            {
                string email = EscapeLdapFilter(filters.Email.Trim());

                filterBuilder.Append("(|");
                filterBuilder.Append($"(mail={email})");
                filterBuilder.Append($"(userPrincipalName={email})");
                filterBuilder.Append(")");
            }

            if (filters.IsInternalUser.HasValue)
            {
                filterBuilder.Append(
                    $"(gweinternaluser={(filters.IsInternalUser.Value ? "True" : "False")})");
            }

            if (!string.IsNullOrWhiteSpace(filters.Search))
            {
                string search =
                    EscapeLdapFilter(filters.Search.Trim());

                filterBuilder.Append("(|");
                filterBuilder.Append($"(displayName=*{search}*)");
                filterBuilder.Append($"(sAMAccountName=*{search}*)");
                filterBuilder.Append($"(mail=*{search}*)");
                filterBuilder.Append($"(userPrincipalName=*{search}*)");
                filterBuilder.Append($"(fullname=*{search}*)");
                filterBuilder.Append(")");
            }

            filterBuilder.Append(")");

            var entries = await FindAllEntriesByFilterAsync(
                filterBuilder.ToString(),
                _userProperties);

            if (entries == null)
            {
                return Enumerable.Empty<ActiveDirectoryMember>();
            }

            var members = entries
                .Select(entry =>
                    MapSearchResultToMember(
                        entry,
                        includeExtendedData: true))
                .Where(x => x != null)
                .OrderBy(x => x.DisplayName)
                .ToList();

            if (includeProfileImage && members.Any())
            {
                await _profileImageService.PopulateImagesParallelAsync(
                    members,
                    imageResolution);
            }

            return members;
        }
        // ─────────────────────────────────────────────
        // Private helpers
        // ─────────────────────────────────────────────

        /// <summary>
        /// Shared core for Enable/Disable — reads current UAC, flips the bit, writes back.
        /// </summary>
        private async Task<bool> SetAccountEnabledStateAsync(string userIdentifier, bool enabled)
        {
            if (string.IsNullOrWhiteSpace(userIdentifier))
                return false;

            string escapedQuery = EscapeLdapFilter(userIdentifier);
            var filter = $"(&(objectClass=user)(|" +
                         $"(sAMAccountName={escapedQuery})" +
                         $"(mail={escapedQuery})" +
                         $"(displayName={escapedQuery})" +
                         $"(extensionattribute1={escapedQuery})" +
                         $"(mobile={escapedQuery})" +
                         $"))";

            try
            {
                var userEntry = await FindSingleEntryByFilterAsync(filter, new[] { "distinguishedName", "userAccountControl" });
                if (userEntry == null)
                {
                    Console.WriteLine($"SetAccountEnabledStateAsync: User not found for '{userIdentifier}'.");
                    return false;
                }

                string userDn = GetProperty(userEntry, "distinguishedName");
                if (string.IsNullOrEmpty(userDn))
                    return false;

                string uacStr = GetProperty(userEntry, "userAccountControl");
                if (!int.TryParse(uacStr, out int currentUac))
                {
                    Console.WriteLine($"SetAccountEnabledStateAsync: Could not parse userAccountControl value '{uacStr}'.");
                    return false;
                }

                const int disableBit = 0x0002; // ADS_UF_ACCOUNTDISABLE

                int newUac;
                if (enabled)
                {
                    // Idempotent: already enabled, nothing to do
                    if ((currentUac & disableBit) == 0)
                        return true;

                    newUac = currentUac & ~disableBit; // clear the bit
                }
                else
                {
                    // Idempotent: already disabled, nothing to do
                    if ((currentUac & disableBit) == disableBit)
                        return true;

                    newUac = currentUac | disableBit; // set the bit
                }

                using (var connection = new LdapConnection(_domainName))
                {
                    connection.Credential = _serviceAccountCredentials;
                    connection.AuthType = AuthType.Kerberos;
                    connection.SessionOptions.ProtocolVersion = 3;

                    var mod = new DirectoryAttributeModification
                    {
                        Name = "userAccountControl",
                        Operation = DirectoryAttributeOperation.Replace
                    };
                    mod.Add(newUac.ToString());

                    var modifyRequest = new ModifyRequest(userDn, mod);

                    var response = await Task.Factory.FromAsync(
                        (cb, s) => connection.BeginSendRequest(
                            modifyRequest,
                            PartialResultProcessing.NoPartialResultSupport,
                            cb, s),
                        ar => connection.EndSendRequest(ar),
                        null) as ModifyResponse;

                    if (response == null || response.ResultCode != ResultCode.Success)
                    {
                        Console.WriteLine($"SetAccountEnabledStateAsync failed: {response?.ResultCode} - {response?.ErrorMessage}");
                        return false;
                    }

                    return true;
                }
            }
            catch (LdapException ex)
            {
                Console.WriteLine($"LdapException in SetAccountEnabledStateAsync: {ex.Message}");
                return false;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error in SetAccountEnabledStateAsync: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Maps a SearchResultEntry to a lightweight ActiveDirectoryGroup model.
        /// </summary>
        private ActiveDirectoryGroup MapSearchResultToGroup(SearchResultEntry entry)
        {
            if (entry == null) return null;

            string groupTypeStr = GetProperty(entry, "groupType");
            int.TryParse(groupTypeStr, out int groupTypeValue);

            // High bit 0x80000000 set = Security group; otherwise Distribution
            bool isSecurity = (groupTypeValue & unchecked((int)0x80000000)) != 0;

            int memberCount = entry.Attributes.Contains("member")
                ? entry.Attributes["member"].Count
                : 0;

            return new ActiveDirectoryGroup
            {
                Name = GetProperty(entry, "cn"),
                Email = GetProperty(entry, "mail"),
                Description = GetProperty(entry, "description"),
                DistinguishedName = GetProperty(entry, "distinguishedName"),
                GroupType = isSecurity ? "Security" : "Distribution",
                MemberCount = memberCount
            };
        }

        private string GetEffectiveEmail(SearchResultEntry entry)
        {
            string mail = GetProperty(entry, "mail");

            if (!string.IsNullOrWhiteSpace(mail))
            {
                return mail.Trim();
            }

            string userPrincipalName = GetProperty(entry, "userPrincipalName");

            return string.IsNullOrWhiteSpace(userPrincipalName)
                ? null
                : userPrincipalName.Trim();
        }
        private string[] BuildSelectiveProperties(
            HashSet<UserField> fields,
            bool includeDls,
            bool includeSubordinates)
        {
            var properties =
                new HashSet<string>(
                    StringComparer.OrdinalIgnoreCase);

            foreach (var field in fields)
            {
                string[] attributes;

                if (!_userFieldProperties.TryGetValue(
                    field,
                    out attributes))
                {
                    continue;
                }

                foreach (var attribute in attributes)
                {
                    properties.Add(attribute);
                }
            }

            if (includeDls)
            {
                properties.Add("memberOf");
            }

            if (includeSubordinates)
            {
                properties.Add("distinguishedName");
            }

            // Safety: SearchRequest should have at least one requested property.
            if (properties.Count == 0)
            {
                properties.Add("distinguishedName");
            }

            return properties.ToArray();
        }

        private ActiveDirectoryMemberV2 MapSearchResultToMemberSelective(
            SearchResultEntry entry,
            HashSet<UserField> fields)
        {
            if (entry == null)
            {
                return null;
            }

            var member = new ActiveDirectoryMemberV2();

            if (fields.Contains(UserField.NTAccount))
            {
                member.NTAccount =
                    GetProperty(entry, "sAMAccountName");
            }

            if (fields.Contains(UserField.Email))
            {
                member.Email =
                    GetEffectiveEmail(entry);
            }

            if (fields.Contains(UserField.UserPrincipalName))
            {
                string upn =
                    GetProperty(entry, "userPrincipalName");

                member.UserPrincipalName =
                    string.IsNullOrWhiteSpace(upn)
                        ? null
                        : upn.Trim();
            }

            if (fields.Contains(UserField.DisplayName))
            {
                member.DisplayName =
                    GetProperty(entry, "displayName");
            }

            if (fields.Contains(UserField.JobTitle))
            {
                member.JobTitle =
                    GetProperty(entry, "jobTitle");
            }

            if (fields.Contains(UserField.IsInternalUser) ||
                fields.Contains(UserField.EmploymentType))
            {
                string internalFlag =
                    GetProperty(entry, "gweinternaluser");

                bool isInternal =
                    string.Equals(
                        internalFlag,
                        "True",
                        StringComparison.OrdinalIgnoreCase);

                if (fields.Contains(UserField.IsInternalUser))
                {
                    member.IsInternalUser = isInternal;
                }

                if (fields.Contains(UserField.EmploymentType))
                {
                    member.EmploymentType =
                        isInternal
                            ? EmploymentType.Internal.ToString()
                            : EmploymentType.Outsource.ToString();
                }
            }

            if (fields.Contains(UserField.Department))
            {
                member.Department =
                    GetProperty(entry, "department");
            }

            if (fields.Contains(UserField.Manager))
            {
                member.Manager =
                    GetProperty(entry, "manager");
            }

            if (fields.Contains(UserField.ManagerNT))
            {
                member.ManagerNT =
                    GetProperty(entry, "extensionattribute7");
            }

            if (fields.Contains(UserField.SubDepartment))
            {
                member.SubDepartment =
                    GetProperty(entry, "extensionattribute6");
            }

            if (fields.Contains(UserField.ReportTo))
            {
                member.ReportTo =
                    GetProperty(entry, "gwereportingto");
            }

            if (fields.Contains(UserField.StaffId))
            {
                member.StaffId =
                    GetProperty(entry, "extensionattribute1");
            }

            if (fields.Contains(UserField.SapId))
            {
                member.SapId =
                    GetProperty(entry, "extensionAttribute10");
            }

            if (fields.Contains(UserField.FullName))
            {
                member.FullName =
                    GetProperty(entry, "fullname");
            }

            if (fields.Contains(UserField.Mobile))
            {
                member.Mobile =
                    GetProperty(entry, "mobile");
            }

            if (fields.Contains(UserField.Company))
            {
                member.Company =
                    GetProperty(entry, "company");
            }

            if (fields.Contains(UserField.Office))
            {
                member.Office =
                    GetProperty(
                        entry,
                        "physicalDeliveryOfficeName");
            }

            if (fields.Contains(UserField.CostCenter))
            {
                member.CostCenter =
                    GetProperty(
                        entry,
                        "extensionAttribute3");
            }

            if (fields.Contains(UserField.HiringDate))
            {
                member.HiringDate =
                    GetProperty(
                        entry,
                        "extensionattribute5");
            }

            if (fields.Contains(UserField.Gender))
            {
                member.Gender =
                    DetermineGenderFromEntry(entry);
            }

            return member;
        }

        private string BuildUserSearchFilter(
            string escapedIdentifier,
            UserIdentifierType identifierType)
        {
            switch (identifierType)
            {
                case UserIdentifierType.Email:
                    return
                        $"(&(objectClass=user)(|" +
                        $"(mail={escapedIdentifier})" +
                        $"(userPrincipalName={escapedIdentifier})" +
                        $"))";

                case UserIdentifierType.NTAccount:
                    return
                        $"(&(objectClass=user)" +
                        $"(sAMAccountName={escapedIdentifier}))";

                case UserIdentifierType.StaffId:
                    return
                        $"(&(objectClass=user)" +
                        $"(extensionattribute1={escapedIdentifier}))";

                case UserIdentifierType.SapId:
                    return
                        $"(&(objectClass=user)" +
                        $"(extensionAttribute10={escapedIdentifier}))";


                case UserIdentifierType.FullName:
                    return
                        $"(&(objectClass=user)" +
                        $"(fullname={escapedIdentifier}))";

                case UserIdentifierType.DisplayName:
                    return
                        $"(&(objectClass=user)" +
                        $"(displayName={escapedIdentifier}))";

                case UserIdentifierType.Mobile:
                    return
                        $"(&(objectClass=user)" +
                        $"(mobile={escapedIdentifier}))";

                case UserIdentifierType.Auto:
                default:
                    return
                        $"(&(objectClass=user)(|" +
                        $"(sAMAccountName={escapedIdentifier})" +
                        $"(mail={escapedIdentifier})" +
                        $"(userPrincipalName={escapedIdentifier})" +
                        $"(extensionAttribute10={escapedIdentifier})" +
                        $"(displayName={escapedIdentifier})" +
                        $"(extensionattribute1={escapedIdentifier})" +
                        $"(mobile={escapedIdentifier})" +
                        $"(fullname={escapedIdentifier})" +
                        $"))";
            }
        }

        private async Task<string> FindHodNtAsync(string currentUserDn, HashSet<string> visitedDns)
        {
            if (string.IsNullOrWhiteSpace(currentUserDn))
            {
                return null;
            }

            if (!visitedDns.Add(currentUserDn))
            {
                // Prevent circular manager relationships
                return null;
            }

            var entry = await FindSingleEntryByFilterAsync(
                $"(&(objectClass=user)" +
                $"(distinguishedName={EscapeLdapFilter(currentUserDn)}))",
                new[]
                {
            "sAMAccountName",
            "manager",
            "VF-extensionAttribute04"
                });

            if (entry == null)
            {
                return null;
            }

            string managementLevel =
                GetProperty(entry, "VF-extensionAttribute04");

            // Current person is HOD
            if (string.Equals(
                managementLevel?.Trim(),
                "Manager EXCO",
                StringComparison.OrdinalIgnoreCase))
            {
                return GetProperty(
                    entry,
                    "sAMAccountName");
            }

            string managerDn =
                GetProperty(entry, "manager");

            if (string.IsNullOrWhiteSpace(managerDn))
            {
                return null;
            }

            return await FindHodNtAsync(managerDn, visitedDns);
        }
        private string ResolveHodNt(SearchResultEntry entry)
        {
            if (entry == null)
            {
                return null;
            }

            string managementValue =
                GetProperty(entry, "VF-extensionAttribute04")?.Trim();

            if (string.IsNullOrWhiteSpace(managementValue))
            {
                return null;
            }

            string ntAccount =
                GetProperty(entry, "sAMAccountName");

            string managerNt =
                GetProperty(entry, "extensionattribute7");

            // EXCO
            // Reports to CEO, therefore there is no HOD above this user.
            if (string.Equals(
                managementValue,
                "Manager CEO",
                StringComparison.OrdinalIgnoreCase))
            {
                return null;
            }

            // HOD
            // Current user is himself/herself the HOD.
            if (string.Equals(
                managementValue,
                "Manager EXCO",
                StringComparison.OrdinalIgnoreCase))
            {
                return ntAccount;
            }

            // Senior Manager
            // His/her direct manager is the HOD.
            if (string.Equals(
                managementValue,
                "Manager HOD",
                StringComparison.OrdinalIgnoreCase))
            {
                return managerNt;
            }

            // Normal employee:
            // VF-extensionAttribute04 already contains the HOD NT account.
            return managementValue;
        }

        private static async Task<SearchResponse> SendLdapRequestAsync(
         LdapConnection connection,
         SearchRequest request)
        {
            var response = await Task<SearchResponse>.Factory.FromAsync(
                (callback, state) => connection.BeginSendRequest(
                    request,
                    PartialResultProcessing.NoPartialResultSupport,
                    callback,
                    state),
                ar => (SearchResponse)connection.EndSendRequest(ar),
                null
            );

            return response;
        }

        private static string GetRequiredAttribute(
            SearchResultEntry entry,
            string name)
        {
            if (!entry.Attributes.Contains(name) ||
                entry.Attributes[name].Count == 0)
            {
                throw new InvalidOperationException(
                    "Missing AD attribute: " + name);
            }

            object value = entry.Attributes[name][0];

            if (value is byte[])
            {
                return System.Text.Encoding.UTF8.GetString(
                    (byte[])value);
            }

            return Convert.ToString(
                value,
                System.Globalization.CultureInfo.InvariantCulture);
        }



        private async Task CompleteGroupMemberRangesAsync(
      LdapConnection connection,
      List<Dictionary<string, object>> groups)
        {
            int completed = 0;
            int extraRequests = 0;
            int totalMemberValues = 0;
            int rangedGroups = 0;
            string currentGroupGuid = "(none)";
            string currentRange = "(none)";
            var totalWatch = System.Diagnostics.Stopwatch.StartNew();
            const string rangePattern = @"^member;range=(\d+)-(\d+|\*)$";

            Log.Information("[GROUP RANGES][START] InputGroups={Count}", groups.Count);

            try
            {
                foreach (var group in groups)
                {
                    var rangeKey = group.Keys.FirstOrDefault(k =>
                        k.StartsWith("member;range=", StringComparison.OrdinalIgnoreCase));

                    if (rangeKey == null)
                        continue;

                    rangedGroups++;
                    currentGroupGuid = group.TryGetValue("objectGUID", out var rawGuid)
                        ? Convert.ToString(rawGuid) : "(missing GUID)";
                    currentRange = rangeKey;
                    var groupWatch = System.Diagnostics.Stopwatch.StartNew();

                    Log.Information("[GROUP RANGES][GROUP START] GroupGUID={GUID}, InitialRange={Range}",
                        currentGroupGuid, currentRange);

                    var match = System.Text.RegularExpressions.Regex.Match(
                        rangeKey, rangePattern,
                        System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                    if (!match.Success || match.Groups[1].Value != "0")
                        throw new InvalidOperationException("Invalid initial member range: " + rangeKey);

                    var members = group[rangeKey] is string[] memberValues
                        ? memberValues.ToList()
                        : new List<string> { Convert.ToString(group[rangeKey]) };

                    if (members.Any(string.IsNullOrWhiteSpace))
                        throw new InvalidOperationException("Invalid member values: " + rangeKey);

                    if (match.Groups[2].Value == "*")
                    {
                        group.Remove(rangeKey);
                        group["member"] = members.ToArray();
                        completed++;
                        totalMemberValues += members.Count;
                        Log.Information(
                            "[GROUP RANGES][GROUP COMPLETE] GUID={GUID}, Members={Members}, " +
                            "ExtraRequests=0, Seconds={Seconds:F2}",
                            currentGroupGuid, members.Count, groupWatch.Elapsed.TotalSeconds);
                        continue;
                    }

                    if (!int.TryParse(match.Groups[2].Value, out int last))
                        throw new InvalidOperationException("Invalid initial range: " + rangeKey);

                    int next = checked(last + 1);
                    if (members.Count != next)
                        throw new InvalidOperationException("Initial member range count mismatch: " + rangeKey);

                    string dn = Convert.ToString(group["distinguishedName"]);
                    group.TryGetValue("uSNChanged", out var rawUsn);

                    string usnValue;
                    if (rawUsn is string[] usnValues)
                        usnValue = usnValues.FirstOrDefault();
                    else if (rawUsn is byte[] usnBytes)
                        usnValue = System.Text.Encoding.UTF8.GetString(usnBytes);
                    else
                        usnValue = Convert.ToString(rawUsn);

                    // Existing conversion fallback retained; no LDAP request made for this value.
                    if (!long.TryParse(usnValue, out long originalUsn))
                    {
                        try
                        {
                            var decodedBytes = Convert.FromBase64String(usnValue ?? "");
                            usnValue = System.Text.Encoding.UTF8.GetString(decodedBytes);
                        }
                        catch (FormatException)
                        {
                            // Keep original value for validation.
                        }
                    }

                    if (!long.TryParse(usnValue, out originalUsn))
                        throw new InvalidOperationException(
                            $"Invalid uSNChanged for group GUID={currentGroupGuid}. Value={usnValue ?? "null"}");

                    int thisGroupRequests = 0;
                    while (true)
                    {
                        currentRange = $"member;range={next}-*";
                        var request = new SearchRequest(
                            dn, "(objectClass=group)", SearchScope.Base,
                            currentRange, "uSNChanged");

                        var requestWatch = System.Diagnostics.Stopwatch.StartNew();
                        Log.Information(
                            "[GROUP RANGES][LDAP REQUEST START] GUID={GUID}, RequestedRange={Range}, " +
                            "RequestNumber={Number}",
                            currentGroupGuid, currentRange, thisGroupRequests + 1);

                        var response = await SendLdapRequestAsync(connection, request);
                        extraRequests++;
                        thisGroupRequests++;
                        Log.Information(
                            "[GROUP RANGES][LDAP REQUEST DONE] GUID={GUID}, Entries={Entries}, " +
                            "Seconds={Seconds:F2}",
                            currentGroupGuid, response.Entries.Count, requestWatch.Elapsed.TotalSeconds);

                        if (response.Entries.Count != 1)
                            throw new InvalidOperationException("Group not found (or multiple returned): " + currentGroupGuid);

                        var entry = response.Entries[0];
                        var usnAttribute = entry.Attributes["uSNChanged"];
                        if (usnAttribute == null || usnAttribute.Count == 0)
                            throw new InvalidOperationException("Missing uSNChanged for group: " + currentGroupGuid);

                        string currentUsnValue = usnAttribute.GetValues(typeof(string))
                            .Cast<string>().FirstOrDefault();

                        if (!long.TryParse(currentUsnValue, out long currentUsn) ||
                            currentUsn != originalUsn)
                        {
                            throw new InvalidOperationException(
                                "Group changed during range retrieval: " + currentGroupGuid);
                        }

                        var attribute = entry.Attributes.Values
                            .Cast<DirectoryAttribute>()
                            .FirstOrDefault(a => a.Name.StartsWith("member;range=",
                                StringComparison.OrdinalIgnoreCase));

                        if (attribute == null)
                            throw new InvalidOperationException("Missing next member range: " + currentGroupGuid);

                        var returnedRange = System.Text.RegularExpressions.Regex.Match(
                            attribute.Name, rangePattern,
                            System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                        if (!returnedRange.Success ||
                            !int.TryParse(returnedRange.Groups[1].Value, out int returnedStart) ||
                            returnedStart != next)
                        {
                            throw new InvalidOperationException("Unexpected member range: " + attribute.Name);
                        }

                        var chunk = attribute.GetValues(typeof(string)).Cast<string>().ToArray();
                        if (chunk.Length == 0)
                            throw new InvalidOperationException("Empty member range: " + currentGroupGuid);

                        bool isLastRange = returnedRange.Groups[2].Value == "*";
                        if (!isLastRange)
                        {
                            if (!int.TryParse(returnedRange.Groups[2].Value, out int end) ||
                                end < next || chunk.Length != (long)end - next + 1)
                            {
                                throw new InvalidOperationException("Incomplete member range: " + attribute.Name);
                            }
                            next = checked(end + 1);
                        }

                        members.AddRange(chunk);
                        Log.Information(
                            "[GROUP RANGES][CHUNK ADDED] GUID={GUID}, ReturnedRange={Range}, " +
                            "ChunkMembers={ChunkMembers}, MembersSoFar={Members}, Final={Final}",
                            currentGroupGuid, attribute.Name, chunk.Length, members.Count, isLastRange);

                        if (isLastRange)
                            break;
                    }

                    group.Remove(rangeKey);
                    group["member"] = members.ToArray();
                    completed++;
                    totalMemberValues += members.Count;

                    Log.Information(
                        "[GROUP RANGES][GROUP COMPLETE] GUID={GUID}, Members={Members}, " +
                        "ExtraRequests={Requests}, Seconds={Seconds:F2}",
                        currentGroupGuid, members.Count, thisGroupRequests,
                        groupWatch.Elapsed.TotalSeconds);
                }

                Log.Information(
                    "[GROUP RANGES][ALL COMPLETE] Ranged={Ranged}, Completed={Completed}, " +
                    "ExtraRequests={Requests}, TotalMembers={Members}, Seconds={Seconds:F2}",
                    rangedGroups, completed, extraRequests, totalMemberValues,
                    totalWatch.Elapsed.TotalSeconds);
                System.Diagnostics.Debug.WriteLine(
                    $"[GROUP RANGES][ALL COMPLETE] Completed={completed}, " +
                    $"Requests={extraRequests}, Time={totalWatch.Elapsed.TotalSeconds:F2}s");
            }
            catch (Exception ex)
            {
                Log.Error(ex,
                    "[GROUP RANGES][FAILED] GroupGUID={GUID}, Range={Range}, " +
                    "Completed={Completed}, Requests={Requests}, Seconds={Seconds:F2}",
                    currentGroupGuid, currentRange, completed, extraRequests,
                    totalWatch.Elapsed.TotalSeconds);
                throw;
            }
        }


        static Dictionary<string, object> MapAdEntry(
           SearchResultEntry entry)
        {
            var user = new Dictionary<string, object>(
                StringComparer.OrdinalIgnoreCase);

            user["distinguishedName"] = entry.DistinguishedName;

            foreach (DirectoryAttribute attr in entry.Attributes.Values)
            {
                var values = new List<string>();

                for (int i = 0; i < attr.Count; i++)
                {
                    object raw = attr[i];

                    if (raw is byte[])
                    {
                        byte[] bytes = (byte[])raw;

                        if (attr.Name.Equals(
                            "objectGUID",
                            StringComparison.OrdinalIgnoreCase)
                            && bytes.Length == 16)
                        {
                            values.Add(new Guid(bytes).ToString());
                        }
                        else if (attr.Name.Equals(
                            "objectSid",
                            StringComparison.OrdinalIgnoreCase))
                        {
                            values.Add(
                                new System.Security.Principal.SecurityIdentifier(
                                    bytes, 0).Value);
                        }
                        else
                        {
                            values.Add(Convert.ToBase64String(bytes));
                        }
                    }
                    else
                    {
                        values.Add(raw == null
                            ? string.Empty
                            : raw.ToString());
                    }
                }

                user[attr.Name] = values.Count == 1
                    ? (object)values[0]
                    : values.ToArray();
            }

            return user;
        }

    }


}