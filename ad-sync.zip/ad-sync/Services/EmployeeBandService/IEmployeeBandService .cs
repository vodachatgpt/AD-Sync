﻿using ADGlobalService.DependencyInjectionConfigs;
using ADGlobalService.Models;
using System.Threading.Tasks;

namespace ADGlobalService.Services.EmployeeBandService
{
    public interface IEmployeeBandService : IInjectable
    {
        Task<EmployeeBandInfo> FindAsync(
            string staffId,
            string sapId,
            string email,
            string fullName);
    }
}
