﻿using ADGlobalService.Data;
using ADGlobalService.Models;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace ADGlobalService.Services.EmployeeBandService
{

    public class EmployeeBandService : IEmployeeBandService
    {
        public async Task<EmployeeBandInfo> FindAsync(
            string staffId,
            string sapId,
            string email,
            string fullName)
        {
            staffId = Normalize(staffId);
            sapId = Normalize(sapId);
            email = Normalize(email);
            fullName = Normalize(fullName);

            bool hasStaffId = !string.IsNullOrEmpty(staffId);
            bool hasSapId = !string.IsNullOrEmpty(sapId);
            bool hasEmail = !string.IsNullOrEmpty(email);
            bool hasFullName = !string.IsNullOrEmpty(fullName);

            if (!hasStaffId &&
                !hasSapId &&
                !hasEmail &&
                !hasFullName)
            {
                return null;
            }

            using (var ctx = new HREmployeeBandsEntities())
            {
                var query = ctx.HREmployeeBandTBLs
                    .AsNoTracking()
                    .Where(x =>
                        (hasStaffId && x.EmployeeNumber == staffId) ||
                        (hasSapId && x.SapNumber == sapId) ||
                        (hasEmail && x.EmailAddress == email) ||
                        (hasFullName && x.FullName == fullName));

                return await query
                    .OrderBy(x =>
                        hasStaffId && x.EmployeeNumber == staffId ? 0 :
                        hasSapId && x.SapNumber == sapId ? 1 :
                        hasEmail && x.EmailAddress == email ? 2 :
                        3)
                    .ThenByDescending(x => x.ID)
                    .Select(x => new EmployeeBandInfo
                    {
                        ID = x.ID,
                        EmployeeNumber = x.EmployeeNumber,
                        SapNumber = x.SapNumber,
                        EmailAddress = x.EmailAddress,
                        FullName = x.FullName,
                        Grade = x.Grade
                    })
                    .FirstOrDefaultAsync();
            }
        }

        private string Normalize(string value)
        {
            return string.IsNullOrWhiteSpace(value)
                ? null
                : value.Trim();
        }
    }
}
