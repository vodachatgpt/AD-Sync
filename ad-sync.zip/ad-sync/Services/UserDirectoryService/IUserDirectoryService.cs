﻿using ADGlobalService.DependencyInjectionConfigs;
using ADGlobalService.Models;
using System.Threading.Tasks;

namespace ADGlobalService.Services.UserDirectoryService
{
    public interface IUserDirectoryService : IInjectable
    {
        Task<UserV2Dto> FindUserAsync(
            string searchQuery,
            UserIdentifierType identifierType,
            UserQueryOptions options);

        Task<UserV2Dto> FindFirstManagerByGradeAsync(
            string searchQuery,
            UserIdentifierType identifierType,
            string grade,
            UserQueryOptions options);
    }

}
