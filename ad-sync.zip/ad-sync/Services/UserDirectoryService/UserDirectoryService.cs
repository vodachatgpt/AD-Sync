﻿using ADGlobalService.Models;
using ADGlobalService.Services.ActiveDirectoryService;
using ADGlobalService.Services.EmployeeBandService;
using ADGlobalService.Services.ProfileImageService;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace ADGlobalService.Services.UserDirectoryService
{
    public class UserDirectoryService : IUserDirectoryService
    {
        private static readonly int MaxManagerHierarchyDepth =
            int.TryParse(ConfigurationManager.AppSettings["ManagerBandHierarchyDepth"], out var value)
                ? value
                : 20;

        private readonly IActiveDirectoryService _activeDirectoryService;
        private readonly IEmployeeBandService _employeeBandService;
        private readonly IProfileImageService _profileImageService;

        public UserDirectoryService(
            IActiveDirectoryService activeDirectoryService,
            IEmployeeBandService employeeBandService,
            IProfileImageService profileImageService)
        {
            _activeDirectoryService = activeDirectoryService;
            _employeeBandService = employeeBandService;
            _profileImageService = profileImageService;
        }

        public async Task<UserV2Dto> FindUserAsync(
            string searchQuery,
            UserIdentifierType identifierType,
            UserQueryOptions options)
        {
            if (string.IsNullOrWhiteSpace(searchQuery))
                return null;

            options = options ?? UserQueryOptions.CreateDefault();

            var fieldsToLoad =
                BuildFieldsToLoad(options);

            bool includeDls = options.Includes.Contains(UserInclude.Dls);
            bool includeDlEmails = options.Includes.Contains(UserInclude.DlEmails);
            bool includeSubordinates = options.Includes.Contains(UserInclude.Subordinates);

            var member =
                await _activeDirectoryService
                    .GetUserSelectiveAsync(
                        searchQuery,
                        identifierType,
                        fieldsToLoad,
                        includeDls,
                         includeDlEmails,
                        includeSubordinates);

            if (member == null)
                return null;

            var result = MapToDto(member, options);

            await PopulateEnrichmentsAsync(
                member,
                result,
                options);

            return result;
        }

        public async Task<UserV2Dto> FindFirstManagerByGradeAsync(
            string searchQuery,
            UserIdentifierType identifierType,
            string grade,
            UserQueryOptions options)
        {
            if (string.IsNullOrWhiteSpace(searchQuery) ||
                string.IsNullOrWhiteSpace(grade))
            {
                return null;
            }

            grade = grade.Trim();

            //
            // Step 1:
            // Only get the employee's Manager DN.
            //
            var employee =
            await _activeDirectoryService
                .GetUserSelectiveAsync(
                    searchQuery,
                    identifierType,
                    new[]
                    {
                        UserField.Manager
                    });

            if (employee == null ||
                string.IsNullOrWhiteSpace(employee.Manager))
            {
                return null;
            }

            string managerDn = employee.Manager;

            var visited = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            //
            // For hierarchy traversal we ONLY need
            // fields required to:
            //
            // 1. find the next manager
            // 2. query the Band DB
            //
            var hierarchyFields =
                new[]
                {
                    UserField.Manager,
                    UserField.StaffId,
                    UserField.SapId,
                    UserField.Email,
                    UserField.FullName
                };

            for (int depth = 0; depth < MaxManagerHierarchyDepth; depth++)
            {
                if (string.IsNullOrWhiteSpace(managerDn))
                {
                    return null;
                }

                if (!visited.Add(managerDn))
                {
                    // Prevent accidental AD hierarchy loop.
                    return null;
                }

                var manager =
                    await _activeDirectoryService
                        .GetUserSelectiveAsync(
                            managerDn,
                            UserIdentifierType.DistinguishedName,
                            hierarchyFields);

                if (manager == null)
                {
                    return null;
                }

                var band =
                    await _employeeBandService.FindAsync(
                        manager.StaffId,
                        manager.SapId,
                        manager.Email,
                        manager.FullName);

                if (band != null &&
                    string.Equals(
                        band.Grade != null
                            ? band.Grade.Trim()
                            : null,
                        grade,
                        StringComparison.OrdinalIgnoreCase))
                {
                    //
                    // We found the first matching manager.
                    //
                    // Now fetch ONLY the final response fields
                    // requested by the caller.
                    //
                    options =
                        options ??
                        UserQueryOptions.CreateDefault();

                    var finalOptions = options.Clone();

                    // Since this API is based on Grade,
                    // always return the matched Band info.
                    finalOptions.Includes.Add(UserInclude.Band);

                    return await FindUserAsync(
                                 managerDn,
                                 UserIdentifierType.DistinguishedName,
                                 finalOptions);
                }

                //
                // Not matching?
                // Move one level higher.
                //
                managerDn = manager.Manager;
            }

            return null;
        }

        private HashSet<UserField> BuildFieldsToLoad(
            UserQueryOptions options)
        {
            var fields =
                new HashSet<UserField>(
                    options.Fields);

            //
            // Band is not an AD field.
            // But these AD fields are needed
            // internally to find the Band row.
            //
            if (options.Includes.Contains(UserInclude.Band))
            {
                fields.Add(UserField.StaffId);
                fields.Add(UserField.SapId);
                fields.Add(UserField.Email);
                fields.Add(UserField.FullName);
            }

            //
            // Graph image needs email.
            //
            if (options.Includes.Contains(
                UserInclude.ProfileImage))
            {
                fields.Add(UserField.Email);
            }

            return fields;
        }

        private async Task PopulateEnrichmentsAsync(
            ActiveDirectoryMember member,
            UserV2Dto result,
            UserQueryOptions options)
        {
            Task<EmployeeBandInfo> bandTask = null;
            Task<string> photoTask = null;

            var tasks = new List<Task>();

            //
            // SQL Band lookup
            //
            if (options.Includes.Contains(
                UserInclude.Band))
            {
                bandTask =
                    _employeeBandService.FindAsync(
                        member.StaffId,
                        member.SapId,
                        member.Email,
                        member.FullName);

                tasks.Add(bandTask);
            }

            //
            // Microsoft Graph profile image
            //
            if (options.Includes.Contains(
                    UserInclude.ProfileImage) &&
                !string.IsNullOrWhiteSpace(member.Email))
            {
                photoTask =
                    _profileImageService
                        .FetchUserPhotoBase64Async(
                            member.Email,
                            options.ImageResolution);

                tasks.Add(photoTask);
            }

            //
            // Band SQL query + Graph request can execute
            // in parallel because they are independent.
            //
            if (tasks.Count > 0)
            {
                await Task.WhenAll(tasks);
            }

            if (bandTask != null)
            {
                result.Band =
                    await bandTask;
            }

            if (options.Includes.Contains(
                UserInclude.ProfileImage))
            {
                if (photoTask == null)
                {
                    result.HasPhoto = false;
                }
                else
                {
                    result.PhotoBase64 =
                        await photoTask;

                    result.HasPhoto =
                        !string.IsNullOrWhiteSpace(
                            result.PhotoBase64);
                }
            }
        }

        private UserV2Dto MapToDto(ActiveDirectoryMemberV2 member, UserQueryOptions options)
        {
            var result = new UserV2Dto();

            if (options.Fields.Contains(UserField.NTAccount))
                result.NTAccount = member.NTAccount;

            if (options.Fields.Contains(UserField.Email))
                result.Email = member.Email;

            if (options.Fields.Contains(UserField.UserPrincipalName))
                result.UserPrincipalName = member.UserPrincipalName;

            if (options.Fields.Contains(UserField.DisplayName))
                result.DisplayName = member.DisplayName;

            if (options.Fields.Contains(UserField.JobTitle))
                result.JobTitle = member.JobTitle;

            if (options.Fields.Contains(UserField.IsInternalUser))
                result.IsInternalUser = member.IsInternalUser;

            if (options.Fields.Contains(UserField.EmploymentType))
                result.EmploymentType = member.EmploymentType;

            if (options.Fields.Contains(UserField.Department))
                result.Department = member.Department;

            if (options.Fields.Contains(UserField.Manager))
                result.Manager = member.Manager;

            if (options.Fields.Contains(UserField.ManagerNT))
                result.ManagerNT = member.ManagerNT;

            if (options.Fields.Contains(UserField.SubDepartment))
                result.SubDepartment = member.SubDepartment;

            if (options.Fields.Contains(UserField.ReportTo))
                result.ReportTo = member.ReportTo;

            if (options.Fields.Contains(UserField.StaffId))
                result.StaffId = member.StaffId;

            if (options.Fields.Contains(UserField.SapId))
                result.SapId = member.SapId;

            if (options.Fields.Contains(UserField.FullName))
                result.FullName = member.FullName;

            if (options.Fields.Contains(UserField.Mobile))
                result.Mobile = member.Mobile;

            if (options.Fields.Contains(UserField.Company))
                result.Company = member.Company;

            if (options.Fields.Contains(UserField.Office))
                result.Office = member.Office;

            if (options.Fields.Contains(UserField.CostCenter))
                result.CostCenter = member.CostCenter;

            if (options.Fields.Contains(UserField.HiringDate))
                result.HiringDate = member.HiringDate;

            if (options.Fields.Contains(UserField.Gender))
                result.Gender = member.Gender;

            if (options.Includes.Contains(UserInclude.Dls))
            {
                result.DLs =
                    member.DLs != null
                        ? member.DLs.ToList()
                        : new List<string>();
            }
            if (options.Includes.Contains(UserInclude.DlEmails))
            {
                result.DLEmails =
                    member.DLEmails != null
                        ? member.DLEmails.ToList()
                        : new List<string>();
            }
            if (options.Includes.Contains(UserInclude.Subordinates))
            {
                result.SubordinateEmails =
                    member.SubordinateEmails != null
                        ? member.SubordinateEmails.ToList()
                        : new List<string>();

                result.IsManager =
                    member.IsManager;
            }

            return result;
        }
    }
}