USE [ActiveDirectoryDB]
GO
/****** Object:  Table [dbo].[DirectoryGroupMemberships]    Script Date: 11/2/2026 1:15:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DirectoryGroupMemberships](
	[ParentGroupId] [bigint] NOT NULL,
	[ChildGroupId] [bigint] NOT NULL,
 CONSTRAINT [PK_DirectoryGroupMemberships] PRIMARY KEY CLUSTERED 
(
	[ParentGroupId] ASC,
	[ChildGroupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DirectoryGroups]    Script Date: 11/2/2026 1:15:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DirectoryGroups](
	[GroupId] [bigint] IDENTITY(1,1) NOT NULL,
	[DLObjectGuid] [uniqueidentifier] NOT NULL,
	[DLDistinguishedName] [nvarchar](2048) NULL,
	[DLName] [nvarchar](256) NULL,
	[DLDisplayName] [nvarchar](512) NULL,
	[DLEmail] [nvarchar](512) NULL,
	[DLAlias] [nvarchar](256) NULL,
	[DLDescription] [nvarchar](1000) NULL,
	[DLGroupType] [int] NULL,
	[IsDeleted] [bit] NOT NULL,
	[DLNT] [nvarchar](256) NULL,
	[DLObjectSid] [nvarchar](256) NULL,
	[DLManagedBy] [nvarchar](2048) NULL,
	[DLProxyAddresses] [nvarchar](max) NULL,
	[DLIsHiddenFromAddressLists] [bit] NULL,
	[DLExchangeRecipientTypeDetails] [bigint] NULL,
	[DLWhenCreatedUtc] [datetime2](7) NULL,
	[DLWhenChangedUtc] [datetime2](7) NULL,
	[DLUsnChanged] [bigint] NULL,
	[LastSyncedAtUtc] [datetime2](7) NULL,
 CONSTRAINT [PK_DirectoryGroups] PRIMARY KEY CLUSTERED 
(
	[GroupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_DirectoryGroups_ObjectGuid] UNIQUE NONCLUSTERED 
(
	[DLObjectGuid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DirectorySyncState]    Script Date: 11/2/2026 1:15:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DirectorySyncState](
	[SyncName] [nvarchar](100) NOT NULL,
	[TrackingMethod] [varchar](20) NOT NULL,
	[DirSyncCookie] [varbinary](max) NULL,
	[UsnWatermark] [bigint] NULL,
	[DomainControllerName] [nvarchar](256) NULL,
	[InvocationId] [uniqueidentifier] NULL,
	[LeaseOwnerToken] [uniqueidentifier] NULL,
	[LeaseExpiresAtUtc] [datetime2](3) NULL,
	[LastSuccessfulSyncUtc] [datetime2](3) NULL,
 CONSTRAINT [PK_DirectorySyncState] PRIMARY KEY CLUSTERED 
(
	[SyncName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DirectoryUserAccountMetadata]    Script Date: 11/2/2026 1:15:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DirectoryUserAccountMetadata](
	[UserId] [bigint] NOT NULL,
	[PasswordLastSetUtc] [datetime2](3) NULL,
	[MustChangePassword] [bit] NULL,
	[AccountExpiresAtUtc] [datetime2](3) NULL,
	[AccountNeverExpires] [bit] NULL,
	[LockoutTimeUtc] [datetime2](3) NULL,
	[LastLogonApproxUtc] [datetime2](3) NULL,
	[SamAccountType] [int] NULL,
	[LastSyncedAtUtc] [datetime2](3) NULL,
 CONSTRAINT [PK_DirectoryUserAccountMetadata] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DirectoryUserAttributeValues]    Script Date: 11/2/2026 1:15:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DirectoryUserAttributeValues](
	[ValueId] [bigint] IDENTITY(1,1) NOT NULL,
	[UserId] [bigint] NOT NULL,
	[AttributeName] [nvarchar](256) NOT NULL,
	[ValueIndex] [int] NOT NULL,
	[StringValue] [nvarchar](max) NULL,
	[NumberValue] [bigint] NULL,
	[DateValue] [datetime2](3) NULL,
	[BinaryValue] [varbinary](max) NULL,
 CONSTRAINT [PK_DirectoryUserAttributeValues] PRIMARY KEY CLUSTERED 
(
	[ValueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DirectoryUserGroupMemberships]    Script Date: 11/2/2026 1:15:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DirectoryUserGroupMemberships](
	[UserId] [bigint] NOT NULL,
	[GroupId] [bigint] NOT NULL,
 CONSTRAINT [PK_DirectoryUserGroupMemberships] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[GroupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DirectoryUserPhotos]    Script Date: 11/2/2026 1:15:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DirectoryUserPhotos](
	[UserId] [bigint] NOT NULL,
	[Resolution] [varchar](10) NOT NULL,
	[Photo] [varbinary](max) NOT NULL,
	[ContentType] [varchar](50) NOT NULL,
	[PhotoHash] [binary](32) NOT NULL,
	[LastSyncedAt] [datetime2](3) NOT NULL,
 CONSTRAINT [PK_DirectoryUserPhotos] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC,
	[Resolution] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[DirectoryUsers]    Script Date: 11/2/2026 1:15:03 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[DirectoryUsers](
	[UserId] [bigint] IDENTITY(1,1) NOT NULL,
	[ActiveDirectoryObjectGuid] [uniqueidentifier] NOT NULL,
	[ActiveDirectoryObjectSid] [nvarchar](256) NULL,
	[DistinguishedName] [nvarchar](2048) NULL,
	[CommonName] [nvarchar](256) NULL,
	[ObjectName] [nvarchar](256) NULL,
	[NT] [nvarchar](256) NULL,
	[UserPrincipalName] [nvarchar](512) NULL,
	[MailAlias] [nvarchar](256) NULL,
	[DisplayName] [nvarchar](512) NULL,
	[FirstName] [nvarchar](256) NULL,
	[LastName] [nvarchar](256) NULL,
	[MiddleName] [nvarchar](256) NULL,
	[Email] [nvarchar](512) NULL,
	[MobileNumber] [nvarchar](100) NULL,
	[CountryIsoCode] [nvarchar](2) NULL,
	[CountryName] [nvarchar](128) NULL,
	[CountryNumericCode] [int] NULL,
	[Department] [nvarchar](256) NULL,
	[JobTitle] [nvarchar](256) NULL,
	[CompanyName] [nvarchar](256) NULL,
	[StaffId] [nvarchar](128) NULL,
	[Office] [nvarchar](256) NULL,
	[Description] [nvarchar](max) NULL,
	[ManagerUserId] [bigint] NULL,
	[ManagerDistinguishedName] [nvarchar](2048) NULL,
	[UserAccountControl] [int] NULL,
	[PrimaryGroupId] [int] NULL,
	[IsEnabled] [bit] NULL,
	[IsDeleted] [bit] NOT NULL,
	[CreatedInAdAtUtc] [datetime2](3) NULL,
	[ModifiedInAdAtUtc] [datetime2](3) NULL,
	[FullName] [nvarchar](512) NULL,
	[HiringDate] [nvarchar](128) NULL,
	[CostCenter] [nvarchar](256) NULL,
	[ReportTo] [nvarchar](2048) NULL,
	[IsInternal] [nvarchar](256) NULL,
	[SapId] [nvarchar](1024) NULL,
	[UsnChanged] [bigint] NULL,
	[SubDepartment] [nvarchar](250) NULL,
	[Gender] [nvarchar](50) NULL,
	[ManagerNT] [nvarchar](250) NULL,
	[HoDNT] [nvarchar](250) NULL,
 CONSTRAINT [PK_DirectoryUsers] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_DirectoryUsers_ObjectGuid] UNIQUE NONCLUSTERED 
(
	[ActiveDirectoryObjectGuid] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[DirectoryGroups] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [dbo].[DirectoryUserPhotos] ADD  CONSTRAINT [DF_DirectoryUserPhotos_LastSyncedAt]  DEFAULT (sysutcdatetime()) FOR [LastSyncedAt]
GO
ALTER TABLE [dbo].[DirectoryUsers] ADD  DEFAULT ((0)) FOR [IsDeleted]
GO
ALTER TABLE [dbo].[DirectoryGroupMemberships]  WITH CHECK ADD  CONSTRAINT [FK_DirectoryGroupMemberships_Child] FOREIGN KEY([ChildGroupId])
REFERENCES [dbo].[DirectoryGroups] ([GroupId])
GO
ALTER TABLE [dbo].[DirectoryGroupMemberships] CHECK CONSTRAINT [FK_DirectoryGroupMemberships_Child]
GO
ALTER TABLE [dbo].[DirectoryGroupMemberships]  WITH CHECK ADD  CONSTRAINT [FK_DirectoryGroupMemberships_Parent] FOREIGN KEY([ParentGroupId])
REFERENCES [dbo].[DirectoryGroups] ([GroupId])
GO
ALTER TABLE [dbo].[DirectoryGroupMemberships] CHECK CONSTRAINT [FK_DirectoryGroupMemberships_Parent]
GO
ALTER TABLE [dbo].[DirectoryUserAccountMetadata]  WITH CHECK ADD  CONSTRAINT [FK_DirectoryUserAccountMetadata_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[DirectoryUsers] ([UserId])
GO
ALTER TABLE [dbo].[DirectoryUserAccountMetadata] CHECK CONSTRAINT [FK_DirectoryUserAccountMetadata_User]
GO
ALTER TABLE [dbo].[DirectoryUserAttributeValues]  WITH CHECK ADD  CONSTRAINT [FK_DirectoryUserAttributeValues_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[DirectoryUsers] ([UserId])
GO
ALTER TABLE [dbo].[DirectoryUserAttributeValues] CHECK CONSTRAINT [FK_DirectoryUserAttributeValues_User]
GO
ALTER TABLE [dbo].[DirectoryUserGroupMemberships]  WITH CHECK ADD  CONSTRAINT [FK_DirectoryUserGroupMemberships_Group] FOREIGN KEY([GroupId])
REFERENCES [dbo].[DirectoryGroups] ([GroupId])
GO
ALTER TABLE [dbo].[DirectoryUserGroupMemberships] CHECK CONSTRAINT [FK_DirectoryUserGroupMemberships_Group]
GO
ALTER TABLE [dbo].[DirectoryUserGroupMemberships]  WITH CHECK ADD  CONSTRAINT [FK_DirectoryUserGroupMemberships_User] FOREIGN KEY([UserId])
REFERENCES [dbo].[DirectoryUsers] ([UserId])
GO
ALTER TABLE [dbo].[DirectoryUserGroupMemberships] CHECK CONSTRAINT [FK_DirectoryUserGroupMemberships_User]
GO
ALTER TABLE [dbo].[DirectoryUserPhotos]  WITH CHECK ADD  CONSTRAINT [FK_DirectoryUserPhotos_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[DirectoryUsers] ([UserId])
GO
ALTER TABLE [dbo].[DirectoryUserPhotos] CHECK CONSTRAINT [FK_DirectoryUserPhotos_Users]
GO
ALTER TABLE [dbo].[DirectoryUsers]  WITH CHECK ADD  CONSTRAINT [FK_DirectoryUsers_Manager] FOREIGN KEY([ManagerUserId])
REFERENCES [dbo].[DirectoryUsers] ([UserId])
GO
ALTER TABLE [dbo].[DirectoryUsers] CHECK CONSTRAINT [FK_DirectoryUsers_Manager]
GO
ALTER TABLE [dbo].[DirectoryGroupMemberships]  WITH CHECK ADD  CONSTRAINT [CK_DirectoryGroupMemberships_NoSelfMember] CHECK  (([ParentGroupId]<>[ChildGroupId]))
GO
ALTER TABLE [dbo].[DirectoryGroupMemberships] CHECK CONSTRAINT [CK_DirectoryGroupMemberships_NoSelfMember]
GO
ALTER TABLE [dbo].[DirectorySyncState]  WITH CHECK ADD  CONSTRAINT [CK_DirectorySyncState_TrackingMethod] CHECK  (([TrackingMethod]='Full' OR [TrackingMethod]='USN' OR [TrackingMethod]='DirSync'))
GO
ALTER TABLE [dbo].[DirectorySyncState] CHECK CONSTRAINT [CK_DirectorySyncState_TrackingMethod]
GO
ALTER TABLE [dbo].[DirectoryUserAttributeValues]  WITH CHECK ADD  CONSTRAINT [CK_DirectoryUserAttributeValues_ExactlyOneValue] CHECK  (((((case when [StringValue] IS NOT NULL then (1) else (0) end+case when [NumberValue] IS NOT NULL then (1) else (0) end)+case when [DateValue] IS NOT NULL then (1) else (0) end)+case when [BinaryValue] IS NOT NULL then (1) else (0) end)=(1)))
GO
ALTER TABLE [dbo].[DirectoryUserAttributeValues] CHECK CONSTRAINT [CK_DirectoryUserAttributeValues_ExactlyOneValue]
GO
ALTER TABLE [dbo].[DirectoryUserAttributeValues]  WITH CHECK ADD  CONSTRAINT [CK_DirectoryUserAttributeValues_NonNegativeIndex] CHECK  (([ValueIndex]>=(0)))
GO
ALTER TABLE [dbo].[DirectoryUserAttributeValues] CHECK CONSTRAINT [CK_DirectoryUserAttributeValues_NonNegativeIndex]
GO
ALTER TABLE [dbo].[DirectoryUsers]  WITH CHECK ADD  CONSTRAINT [CK_DirectoryUsers_NoSelfManager] CHECK  (([ManagerUserId] IS NULL OR [ManagerUserId]<>[UserId]))
GO
ALTER TABLE [dbo].[DirectoryUsers] CHECK CONSTRAINT [CK_DirectoryUsers_NoSelfManager]
GO
