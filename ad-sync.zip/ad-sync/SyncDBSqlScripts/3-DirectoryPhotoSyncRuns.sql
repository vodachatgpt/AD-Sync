/* Rerunnable, additive schema for a resumable photo synchronization run.
   Review the database/backup before executing. Does not touch photo data.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;
BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.DirectoryPhotoSyncRuns', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.DirectoryPhotoSyncRuns
        (
            RunId UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_DirectoryPhotoSyncRuns PRIMARY KEY,
            Status VARCHAR(20) NOT NULL,
            PageSize INT NOT NULL,
            LastProcessedUserId BIGINT NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_LastId DEFAULT (0),
            TotalEligibleUsers INT NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Total DEFAULT (0),
            ProcessedUsers INT NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Processed DEFAULT (0),
            InsertedPhotos INT NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Inserted DEFAULT (0),
            UpdatedPhotos INT NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Updated DEFAULT (0),
            UnchangedPhotos INT NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Unchanged DEFAULT (0),
            MissingPhotos INT NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Missing DEFAULT (0),
            FailedPhotos INT NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Failed DEFAULT (0),
            StartedAtUtc DATETIME2(3) NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Start DEFAULT SYSUTCDATETIME(),
            UpdatedAtUtc DATETIME2(3) NOT NULL CONSTRAINT DF_DirectoryPhotoSyncRuns_Update DEFAULT SYSUTCDATETIME(),
            FinishedAtUtc DATETIME2(3) NULL,
            ErrorMessage NVARCHAR(1000) NULL,
            ActiveSlot TINYINT NULL,
            CONSTRAINT CK_DirectoryPhotoSyncRuns_Status CHECK (Status IN ('Queued', 'Running', 'Paused', 'Failed', 'Completed')),
            CONSTRAINT CK_DirectoryPhotoSyncRuns_PageSize CHECK (PageSize BETWEEN 1 AND 100),
            CONSTRAINT CK_DirectoryPhotoSyncRuns_Active CHECK (
                (Status IN ('Queued', 'Running') AND ActiveSlot IS NOT NULL AND ActiveSlot = 1) OR
                (Status IN ('Paused', 'Failed', 'Completed') AND ActiveSlot IS NULL)
            )
        );
        PRINT 'Created DirectoryPhotoSyncRuns';
    END
    ELSE
    BEGIN
        IF (SELECT COUNT(*) FROM sys.columns
            WHERE object_id = OBJECT_ID(N'dbo.DirectoryPhotoSyncRuns')
            AND name IN (N'RunId', N'Status', N'PageSize', N'LastProcessedUserId',
                         N'TotalEligibleUsers', N'ProcessedUsers', N'InsertedPhotos',
                         N'UpdatedPhotos', N'UnchangedPhotos', N'MissingPhotos',
                         N'FailedPhotos', N'StartedAtUtc', N'UpdatedAtUtc',
                         N'FinishedAtUtc', N'ErrorMessage', N'ActiveSlot')) <> 16
            THROW 51011, 'Existing DirectoryPhotoSyncRuns table is incompatible; review manually.', 1;
        PRINT 'DirectoryPhotoSyncRuns already exists';
    END;

    IF NOT EXISTS (SELECT 1 FROM sys.indexes
        WHERE object_id=OBJECT_ID(N'dbo.DirectoryPhotoSyncRuns')
        AND name=N'UX_DirectoryPhotoSyncRuns_OneActive')
    BEGIN
        CREATE UNIQUE INDEX UX_DirectoryPhotoSyncRuns_OneActive
            ON dbo.DirectoryPhotoSyncRuns(ActiveSlot)
            WHERE ActiveSlot IS NOT NULL;
        PRINT 'Added one-active-run unique index';
    END;

    COMMIT;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK;
    THROW;
END CATCH;
