/*
  Safe, rerunnable SQL Server script (EF6 / Database-First).
  Does not drop existing tables or data.
  Requires dbo.DirectoryUsers(UserId BIGINT) to already exist.
*/
SET NOCOUNT ON;
SET XACT_ABORT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    IF OBJECT_ID(N'dbo.DirectoryUsers', N'U') IS NULL
        THROW 51000, 'Required table dbo.DirectoryUsers does not exist.', 1;

    IF NOT EXISTS (
        SELECT 1 FROM sys.columns
        WHERE object_id = OBJECT_ID(N'dbo.DirectoryUsers')
          AND name = N'UserId' AND system_type_id = 127 -- BIGINT
    )
        THROW 51001, 'dbo.DirectoryUsers.UserId must exist and be BIGINT.', 1;

    IF OBJECT_ID(N'dbo.DirectoryUserPhotos', N'U') IS NULL
    BEGIN
        CREATE TABLE dbo.DirectoryUserPhotos
        (
            UserId       BIGINT        NOT NULL,
            Resolution   VARCHAR(10)   NOT NULL,
            Photo        VARBINARY(MAX) NOT NULL,
            ContentType  VARCHAR(50)   NOT NULL,
            PhotoHash    BINARY(32)    NOT NULL,
            LastSyncedAt DATETIME2(3)  NOT NULL
                CONSTRAINT DF_DirectoryUserPhotos_LastSyncedAt
                DEFAULT SYSUTCDATETIME(),
            CONSTRAINT PK_DirectoryUserPhotos PRIMARY KEY (UserId, Resolution),
            CONSTRAINT FK_DirectoryUserPhotos_Users FOREIGN KEY (UserId)
                REFERENCES dbo.DirectoryUsers(UserId)
        );
        PRINT 'Created dbo.DirectoryUserPhotos.';
    END
    ELSE
    BEGIN
        /* Fail safely on unexpected existing schema; do not destructively alter it. */
        IF (SELECT COUNT(*) FROM sys.columns
            WHERE object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
              AND name IN (N'UserId', N'Resolution', N'Photo', N'ContentType', N'PhotoHash', N'LastSyncedAt')) <> 6
            THROW 51002, 'Existing dbo.DirectoryUserPhotos has an incompatible schema; review manually.', 1;

        IF NOT EXISTS (
            SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
              AND name = N'UserId' AND system_type_id = 127 AND is_nullable = 0
        ) OR NOT EXISTS (
            SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
              AND name = N'Resolution' AND system_type_id = 167 AND max_length = 10 AND is_nullable = 0
        ) OR NOT EXISTS (
            SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
              AND name = N'Photo' AND system_type_id = 165 AND max_length = -1 AND is_nullable = 0
        ) OR NOT EXISTS (
            SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
              AND name = N'ContentType' AND system_type_id = 167 AND max_length = 50 AND is_nullable = 0
        ) OR NOT EXISTS (
            SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
              AND name = N'PhotoHash' AND system_type_id = 173 AND max_length = 32 AND is_nullable = 0
        ) OR NOT EXISTS (
            SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
              AND name = N'LastSyncedAt' AND system_type_id = 42 AND scale = 3 AND is_nullable = 0
        )
            THROW 51003, 'Existing dbo.DirectoryUserPhotos column types do not match the expected schema.', 1;

        IF NOT EXISTS (
            SELECT 1 FROM sys.key_constraints
            WHERE parent_object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos') AND type = 'PK'
        )
        BEGIN
            ALTER TABLE dbo.DirectoryUserPhotos
                ADD CONSTRAINT PK_DirectoryUserPhotos PRIMARY KEY (UserId, Resolution);
            PRINT 'Created missing primary key.';
        END;

        IF NOT EXISTS (
            SELECT 1 FROM sys.foreign_keys
            WHERE parent_object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
              AND referenced_object_id = OBJECT_ID(N'dbo.DirectoryUsers')
        )
        BEGIN
            ALTER TABLE dbo.DirectoryUserPhotos WITH CHECK
                ADD CONSTRAINT FK_DirectoryUserPhotos_Users FOREIGN KEY (UserId)
                REFERENCES dbo.DirectoryUsers(UserId);
            PRINT 'Created missing foreign key.';
        END;

        PRINT 'dbo.DirectoryUserPhotos already exists; verified schema.';
    END;

    COMMIT TRANSACTION;
END TRY
BEGIN CATCH
    IF XACT_STATE() <> 0 ROLLBACK TRANSACTION;
    THROW;
END CATCH;

--SELECT t.name AS TableName, c.name AS ColumnName,
--       TYPE_NAME(c.user_type_id) AS SqlType,
--       c.max_length AS MaxLength, c.is_nullable AS IsNullable
--FROM sys.tables AS t
--JOIN sys.columns AS c ON c.object_id = t.object_id
--WHERE t.object_id = OBJECT_ID(N'dbo.DirectoryUserPhotos')
--ORDER BY c.column_id;


