﻿using ADGlobalService.Data;
using ADGlobalService.Services.ActiveDirectoryService;
using ADGlobalService.Services.EmailService;
using ADGlobalService.Services.GraphClientFactory;
using ADGlobalService.Services.HangfireService;
using ADGlobalService.Services.ProfileImageService;
using ADGlobalService.Services.SyncAdDB;
using ADGlobalService.Services.SyncAdDB.UserPhotos;
using Autofac;
using Autofac.Integration.WebApi;
using System;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Web.Configuration;
using System.Web.Http;

namespace ADGlobalService.DependencyInjectionConfigs
{
    public static class AutofacWebapiConfig
    {
        public static IContainer Container;
        public static void Register(HttpConfiguration config)
        {
            var builder = new ContainerBuilder();


            // Register Controllers
            builder.RegisterApiControllers(Assembly.GetExecutingAssembly());

            builder.RegisterType<GraphClientFactory>().As<IGraphClientFactory>().SingleInstance();
            builder.RegisterType<ProfileImageService>()
                .As<IProfileImageService>()
                .SingleInstance();


            builder.RegisterType<UserPhotosService>()
                .As<IUserPhotosService>()
                .InstancePerLifetimeScope();

            builder.RegisterType<HttpClient>().InstancePerLifetimeScope();

            // Register  services via assembly scanning.
            builder.RegisterAssemblyTypes(Assembly.GetExecutingAssembly())
              .Where(t => t.IsAssignableTo<IInjectable>())
              .AsImplementedInterfaces()
              .InstancePerRequest();

            builder.RegisterType<EmailService>()
                .As<IEmailService>()
                .InstancePerLifetimeScope();

            builder.RegisterType<SyncEmailNotifier>()
                .InstancePerLifetimeScope();


            builder.RegisterType<AdSyncJobRegistrar>()
                .InstancePerLifetimeScope();

            builder.Register(c => new HangfireService(new HttpClient()))
                   .As<IHangfireService>()
                   .SingleInstance();

            // LDAP Simple Paged Results keeps state on the LDAP connection. Keep this
            // sliding timeout above the time SuccessFactor needs to persist one page.
            builder.Register(_ => new DirectorySyncPager(
                TimeSpan.FromMinutes(ReadDirectorySyncSetting(
                    "DirectorySyncPageIdleTimeoutMinutes", 120, 5, 1440)),
                ReadDirectorySyncSetting("DirectorySyncMaxSessions", 64, 1, 256),
                () => DateTime.UtcNow)).SingleInstance();
            builder.RegisterType<DirectoryIncrementalSyncService>().As<IDirectoryIncrementalSyncService>().SingleInstance();

            builder.RegisterWebApiFilterProvider(config);

            ////  


            // Database
            //builder.RegisterType<ActiveDirectoryDBEntities>()
            //    .InstancePerLifetimeScope();

            builder.RegisterType<ActiveDirectoryDBEntities>()
              .InstancePerRequest();

            // Sync Database Service
            builder.RegisterType<SyncAdDBService>()
                .As<ISyncAdDBService>()
                .InstancePerLifetimeScope();
            
            builder.RegisterType<GroupsService>()
                .As<IGroupsService>()
                .InstancePerRequest();

            Container = builder.Build();


            config.DependencyResolver = new AutofacWebApiDependencyResolver(Container);
        }

        private static int ReadDirectorySyncSetting(string key, int defaultValue, int minimum, int maximum)
        {
            int value;
            string configuredValue = WebConfigurationManager.AppSettings[key];
            return int.TryParse(configuredValue, out value) && value >= minimum && value <= maximum
                ? value
                : defaultValue;
        }
    }
}