﻿namespace ADGlobalService.DependencyInjectionConfigs
{
    public interface IInjectable
    {
    }
}
