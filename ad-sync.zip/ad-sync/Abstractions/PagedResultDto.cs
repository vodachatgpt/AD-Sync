﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ADGlobalService.Abstractions
{
    public class PagedResultDto<T>
    {
        public List<T> Items { get; set; }

        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }

        public int TotalPages
        {
            get
            {
                if (PageSize <= 0)
                    return 0;

                return (int)Math.Ceiling(
                    (double)TotalCount / PageSize);
            }
        }
    }
}