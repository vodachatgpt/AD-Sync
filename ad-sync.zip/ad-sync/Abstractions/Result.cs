﻿using System;

namespace ADGlobalService.Abstractions
{
    public class Result
    {
        public Result(bool isSuccess, Error error)
        {
            if (error == null)
            {
                throw new ArgumentNullException(nameof(error));
            }

            if (isSuccess && error != Error.None)
            {
                throw new InvalidOperationException(
                    "A successful result cannot contain an error.");
            }

            if (!isSuccess && error == Error.None)
            {
                throw new InvalidOperationException(
                    "A failure result must contain an error.");
            }

            IsSuccess = isSuccess;
            Error = error;
        }

        public bool IsSuccess { get; }

        public bool IsFailure
        {
            get { return !IsSuccess; }
        }

        public Error Error { get; }

        public static Result Success()
        {
            return new Result(true, Error.None);
        }

        public static Result Failure(Error error)
        {
            return new Result(false, error);
        }

        public static Result<TValue> Success<TValue>(TValue value)
        {
            return new Result<TValue>(
                value,
                true,
                Error.None
            );
        }

        public static Result<TValue> Failure<TValue>(Error error)
        {
            return new Result<TValue>(
                default(TValue),
                false,
                error
            );
        }
    }

    public class Result<TValue> : Result
    {
        private readonly TValue _value;

        public Result(TValue value, bool isSuccess, Error error)
            : base(isSuccess, error)
        {
            _value = value;
        }

        public TValue Value
        {
            get
            {
                if (IsFailure)
                {
                    throw new InvalidOperationException(
                        "The value of a failure result cannot be accessed.");
                }

                return _value;
            }
        }
    }
}