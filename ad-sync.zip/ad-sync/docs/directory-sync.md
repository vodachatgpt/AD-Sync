## Recommended one-request API

New consumers, including SuccessFactor, must use one request for each Full or Incremental sync:

~~~http
GET /api/v2/AD/GetSyncSnapshot?pageSize=500
GET /api/v2/AD/GetSyncSnapshot?syncToken=<completedSyncToken>&pageSize=500
~~~

The load balancer selects one ADGlobalService node for the request. That node completes LDAP Simple Paged Results internally and returns the complete `items` array with `hasMore=false` and `nextPageToken=null`. `completedSyncToken` is returned after a successful Full or Incremental run when directory incremental sync is configured.

## Deprecated public paging APIs

`/api/AD/GetUsersForSync`, `/api/v2/AD/GetUsersForSync`, and `/api/v2/AD/GetChangedUsers` remain available temporarily for existing consumers. They are not for new integrations and require request affinity when more than one AD node is deployed. Their paging engine remains an internal dependency of `GetSyncSnapshot` and is not removed.
# AD profile synchronization API

This is the AD-facing part of the daily full-sync workflow. The existing Hangfire
service reads this API and sends each batch to the custom application's internal
upsert API. Scheduling, database writes, and application-side reconciliation
remain in those applications.

## Configuration

The endpoint uses the existing AD settings: ADFUrl, ADLoginUser, and ADLoginPass.
It uses Kerberos with LDAP signing and sealing and keeps one LDAP connection for
the lifetime of each export. The account needs read access to the configured
directory scope; the export does not write to AD.

No application-level authorization or API key is required for this endpoint.

## Requests

Start a new full scan:

    GET /api/AD/GetUsersForSync?pageSize=500
    Accept: application/json

Continue using the exact NextPageToken from the preceding response:

    GET /api/AD/GetUsersForSync?pageSize=500&pageToken=<NextPageToken>

pageSize defaults to 500, accepts 1 through 1000, and must stay unchanged for a
scan. The directory may return fewer items than requested. Continue based on
HasMore/NextPageToken, not the number of items.

Example response (property casing shown matches the default Web API formatter):

    {
      "SyncRunId": "00112233-4455-6677-8899-aabbccddeeff",
      "SyncStartedAtUtc": "2026-10-14T00:00:00Z",
      "ExpiresAtUtc": "2026-10-14T00:15:00Z",
      "Items": [
        {
          "AdObjectGuid": "aabbccdd-eeff-0011-2233-445566778899",
          "DistinguishedName": "CN=Example User,OU=People,DC=example,DC=test",
          "IsEnabled": false,
          "AdLastModifiedAtUtc": "2026-10-13T10:30:00Z",
          "Profile": {
            "NTAccount": "example.user",
            "Email": "example.user@example.test",
            "UserPrincipalName": "example.user@example.test",
            "DisplayName": "Example User",
            "Department": "Engineering",
            "StaffId": "12345",
            "JobTitle": "Engineer"
          }
        }
      ],
      "NextPageToken": "opaque-continuation-token",
      "HasMore": true
    }

Profile contains the existing ActiveDirectoryMember fields; the example omits
unused fields. StaffId remains mapped from extensionattribute1, alongside the
existing company-specific profile mappings. Photos, distribution list expansion,
and subordinate lookups are not performed. If mail is empty, the existing UPN
fallback is preserved.

Both enabled and disabled person/user objects are included, even without email.
Computers and contacts are excluded. Missing/invalid objectGUID or account status
fails the scan rather than exporting a misleading identity or enabled state.

## Consumer workflow

1. Start the full scan and associate the returned SyncRunId with an application
   sync run. Scope identity by the configured directory plus AdObjectGuid.
2. Upsert each page into the custom application, updating only AD-owned fields.
   Make batch delivery idempotent.
3. Commit the current batch before requesting the next page. Keep the token used
   to fetch that batch until its application-side transaction succeeds.
4. Continue until HasMore is false and NextPageToken is null.
5. Mark the application run successful only after its final batch commits.
6. Apply the application's missing-user policy only to a complete successful
   run. Never reconcile absence from an individual page, failed scan, or abandoned
   run. Use safeguards for unexpected count drops and consider confirming absence
   on a later scan before deactivation.

The response is a live paged directory scan, not a point-in-time snapshot.
Concurrent directory updates can affect enumeration. There are no tombstone
events in this full-sync API: detect absence through completed full scans.
AdLastModifiedAtUtc is informational and is not an incremental checkpoint.

## Retries, lifetime, and hosting

- The latest page is cached. Retrying its input pageToken returns the same page
  without advancing LDAP; concurrent requests for that token are serialized.
- Once another page has been fetched, older tokens cannot be replayed. Process
  pages sequentially. A retry without a token starts a new scan.
- Sessions expire 15 minutes after the most recently fetched new page. Expiry is
  checked on access, with background cleanup every minute.
- At most 32 sessions, including cached completed scans, are retained per process.
  LDAP connections close immediately on completion or failure.
- Tokens and sessions are process-local. Use one IIS worker process, or instance
  affinity when hosting multiple instances. An app restart loses tokens.
- Tokens are opaque continuation handles, not durable resume cursors or delta
  tokens. Do not log them. The application performance handler omits this
  endpoint's query string; configure IIS/proxy logs to omit it as well.
- LDAP/network/protocol failures invalidate the scan because the cookie may
  already have advanced. Retry by starting a new scan and safely replaying upserts.
- Do not advance or complete the application's sync run after an unsuccessful
  response. Never translate an error into an empty user list.

| HTTP status | Meaning / action |
| --- | --- |
| 200 | Apply the page and follow NextPageToken when present. |
| 400 | Fix invalid pageSize/token or keep the original page size. |
| 410 | Session expired, disappeared, or token is stale; start a new scan. |
| 429 | Session capacity reached; honor Retry-After. |
| 503 | Directory scan failed; fix directory connectivity/configuration and start a new scan. |

The API is pull-only. It does not confirm that batches were saved by the consumer,
and a final page does not by itself prove that the application's sync succeeded.

## Local verification

Build ADGlobalService.csproj with Visual Studio MSBuild, then run:

    .\Tests\Run-DirectorySyncTests.ps1

The test runner accepts `-MSBuildPath` when Visual Studio MSBuild is installed in a
non-default location. It uses a simulated LDAP page reader and covers page-token
scoping, sequential and concurrent duplicate delivery, page-size sequencing,
expiry, and capacity without directory credentials. The v2 guide below includes
the required live-DC checks for LDAP mapping and watermark behaviour.

Before deployment, perform a live test from the domain-connected hosting
environment with a read account. Confirm enabled
and disabled test accounts and enumerate more than one page.

## V2: incremental synchronization

The legacy endpoint above is unchanged. New consumers should use the v2 contract:

    GET /api/v2/AD/GetUsersForSync?pageSize=500
    GET /api/v2/AD/GetChangedUsers?syncToken=<completedSyncToken>&pageSize=500

Continue either run using only its page token:

    GET /api/v2/AD/GetUsersForSync?pageToken=<pageToken>&pageSize=500
    GET /api/v2/AD/GetChangedUsers?pageToken=<pageToken>&pageSize=500

Optionally limit a new v2 run to one employment audience. Omit both parameters
to retain the existing all-users behaviour:

    GET /api/v2/AD/GetUsersForSync?isInternalUser=true&pageSize=500
    GET /api/v2/AD/GetUsersForSync?employmentType=Outsource&pageSize=500
    GET /api/v2/AD/GetChangedUsers?syncToken=<completedSyncToken>&isInternalUser=false&pageSize=500

`isInternalUser` and `employmentType` are aliases: `true`/`Internal` select AD
entries with `gweinternaluser=True`; `false`/`Outsource` select all other values,
including a missing value. `employmentType` accepts only `Internal` or
`Outsource`, case-insensitively. When both are provided they must agree.

Supply an audience parameter only when starting a run. A continuation uses only
`pageToken`; adding either audience parameter to it is invalid. The selected
audience is also bound to `completedSyncToken`, so an incremental call must use
a checkpoint produced by the same audience; a mismatch returns `409`
`resync_required` and needs a new full import for that audience.

All v2 JSON uses camelCase and has this shape:

    {
      "syncRunId": "00112233-4455-6677-8899-aabbccddeeff",
      "syncStartedAtUtc": "2026-10-14T00:00:00Z",
      "expiresAtUtc": "2026-10-14T00:15:00Z",
      "items": [
        {
          "directoryObjectId": "aabbccdd-eeff-0011-2233-445566778899",
          "userName": "example.user",
          "userPrincipalName": "example.user@example.test",
          "email": "example.user@example.test",
          "displayName": "Example User",
          "adFullName": "Example User",
          "department": "Engineering",
          "jobTitle": "Engineer",
          "mobile": null,
          "staffId": "12345",
          "sapId": null,
          "employmentType": "Internal",
          "isInternalUser": true,
          "isEnabled": false,
          "modifiedAt": "2026-10-13T10:30:00Z"
        }
      ],
      "nextPageToken": "opaque-page-token",
      "hasMore": true,
      "completedSyncToken": null
    }

`directoryObjectId` and `isEnabled` are required. A malformed value for either
fails the request instead of producing a misleading record. `isEnabled` only
reflects the AD account-disable bit; it does not represent lockout or password
expiry. The selected fields are complete current values, not patches. A `null`
therefore clears that AD-owned field at the consumer. Email falls back to UPN.
Photos, groups, managers, and all other profile data are intentionally omitted.

### Required configuration and checkpoint behaviour

Set `DirectorySyncDomainController` to one specific writable domain controller.
V2 uses the existing `ADFUrl` exactly as its search scope and the existing read
credentials. It reads `highestCommittedUSN` and `dsServiceName` from RootDSE,
then reads `invocationID` from the referenced NTDS Settings object. Do not place
a `machineKey` secret in source control. Production instances must share a stable
ASP.NET `machineKey`; otherwise a saved `completedSyncToken` becomes invalid
after a restart or on another instance.
When `DirectorySyncDomainController` is not configured, only
`GET /api/v2/AD/GetUsersForSync` falls back to the established legacy LDAP reader.
It still returns the v2 response shape, but is an all-users full import only:
`completedSyncToken` is always `null`, and `GetChangedUsers`, `isInternalUser`,
and `employmentType` are unavailable. Configure a specific writable DC, then
start a new v2 full import before using incremental synchronization or an
employment audience.

A full import captures a USN watermark before scanning, but enumerates every
matching user without an upper-USN filter. This prevents an object modified during
the scan from being omitted from the completed import. Its final page alone
contains `completedSyncToken`. The following incremental run queries
`uSNChanged >= savedWatermark + 1` and `<=` a newly captured watermark. An object
changed during the full import can therefore be delivered again in the next delta;
consumer upserts must be idempotent. A no-change incremental run returns an empty
`items` array and a valid final token.

The checkpoint is protected with ASP.NET MachineKey protection and is bound to
the contract version, selected audience, configured DC, DC invocation ID, and `ADFUrl` search scope.
If any of these is incompatible, the API returns `409` with
`code: "resync_required"`; run a new full import. A malformed token is `400`.
Tokens are opaque and must never be logged.

### Consumer rules

1. Persist each returned batch before requesting the next page. Repeating the
   latest request safely returns the same page; requests are serialized.
2. Save `completedSyncToken` only after the final batch is committed. It is the
   durable checkpoint for the next incremental run, not a page-resume token.
3. Keep `pageSize` fixed within a run (default 500; valid range 1--1000).
   Paging sessions have a 15-minute idle lifetime and the process admits 32.
4. On `410`, retry from the last successfully saved `completedSyncToken`; start
   a full import if there is no saved checkpoint. On `429`, honour `Retry-After`.
   On `503`, treat the directory read as failed, never as an empty delta.
5. V2 deliberately emits no deletion event. Do not infer deletions from an
   incremental result; a deleted user or one moved out of `ADFUrl` is silent in
   this release.
   This also applies to an audience change: an account moving between Internal
   and Outsource is not emitted as a removal from its previous filtered stream.
   Consumers of filtered streams must not treat absence from an incremental
   result as deletion.

Responses (including errors) send `Cache-Control: no-store`. Application and
proxy logging must continue to omit `pageToken` and `syncToken`. Hangfire,
consumer persistence, and checkpoint storage remain outside ADGlobalService.

### Live deployment checklist

- Configure a specific reachable DC and a stable production `machineKey`.
- Verify a multi-page full import containing enabled, disabled, no-mail, and
  service accounts; check UPN email fallback and null clearing.
- Change, add, disable, and re-enable a test account during/after a full import,
  then verify the import contains its current state and the next incremental run
  can safely replay its post-watermark change through an idempotent upsert.
- Verify a no-change delta, token tampering (`400`), scope/DC/invocation changes
  (`409 resync_required`), session expiry (`410`), and LDAP failure (`503`).
- Confirm that the legacy `/api/AD/GetUsersForSync` contract remains unchanged.
