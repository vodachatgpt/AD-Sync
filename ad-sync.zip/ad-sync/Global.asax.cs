﻿using ADGlobalService.DependencyInjectionConfigs;
using ADGlobalService.Filters;
using ADGlobalService.Services.HangfireService;
using Autofac;
using Serilog;
using Serilog.Debugging;
using Serilog.Events;
using System;
using System.Configuration;
using System.IO;
using System.Net;
using System.Threading.Tasks;
using System.Web.Hosting;
using System.Web.Http;
using System.Web.Http.ExceptionHandling;

namespace ADGlobalService
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        private TextWriter _selfLogWriter;
        protected void Application_Start()
        {
            ServicePointManager.SecurityProtocol |= SecurityProtocolType.Tls12;

            ConfigureLogging();

            var config = GlobalConfiguration.Configuration;
            AutofacWebapiConfig.Register(GlobalConfiguration.Configuration);

            GlobalConfiguration.Configure(WebApiConfig.Register);

            GlobalConfiguration.Configuration.Services.Add(typeof(IExceptionLogger), new GlobalExceptionLogger());
            config.MessageHandlers.Add(new PerformanceHandler());


            HostingEnvironment.QueueBackgroundWorkItem(async ct =>
            {
                try
                {
                    await Task.Delay(2000, ct);

                    ct.ThrowIfCancellationRequested();

                    using (var scope =
                        AutofacWebapiConfig.Container.BeginLifetimeScope())
                    {
                        var registrar = scope.Resolve<AdSyncJobRegistrar>();

                        await registrar.EnsureAdSyncJobsRegisteredAsync();
                    }
                }
                catch (OperationCanceledException)
                {
                    Log.Information("AD Sync job registration cancelled.");
                }
                catch (Exception ex)
                {
                    Log.Error(ex, "AD Sync job registration failed.");
                }
            });
        }


        protected void Application_Error()
        {
            var exception = Server.GetLastError();
            if (exception != null)
            {
                Log.Error(exception, "CRITICAL: Unhandled Exception in Application Pipeline");
            }
        }
        protected void Application_End()
        {
            Log.CloseAndFlush();
            if (_selfLogWriter != null)
            {
                _selfLogWriter.Dispose();
            }
        }
        private void ConfigureLogging()
        {
            int fileSizeLimitMB = GetConfigValueOrDefault("LogFileSizeLimitMB", 10);
            int retainedFiles = GetConfigValueOrDefault("LogRetainedFileCount", 30);

            // Ensure the logs folder exists
            string logPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "logs");
            Directory.CreateDirectory(logPath);

            string selfLogPath = Path.Combine(logPath, "serilog-self-log.txt");
            // Enable Serilog self-logging to capture issues
            SelfLog.Enable(message => File.AppendAllText(selfLogPath, $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {message}{Environment.NewLine}"));


            Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Information()
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                .MinimumLevel.Override("System", LogEventLevel.Warning)
                .Enrich.FromLogContext()
                .Enrich.WithMachineName()
                //      .Enrich.WithThreadId()
                .Enrich.WithEnvironmentUserName()

                // Main application logs with enhanced formatting
                .WriteTo.File(
                    path: Path.Combine(logPath, "AD-app-.txt"),
                    rollingInterval: RollingInterval.Day,
                    retainedFileCountLimit: retainedFiles,
                    fileSizeLimitBytes: fileSizeLimitMB * 1024 * 1024,
                    rollOnFileSizeLimit: true,
                    shared: true,
                    flushToDiskInterval: TimeSpan.FromSeconds(1),
                    outputTemplate: CreateAdvancedTemplate())
                .CreateLogger();
        }
        private string CreateAdvancedTemplate()
        {
            return @"
╔═══════════════════════════════════════════════════════════════════════════════════╗
║ {Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} │ {Level:u3} │ User: {EnvironmentUserName} 
╠═══════════════════════════════════════════════════════════════════════════════════╣
║ {Message:lj}
║ {Exception}
╚═══════════════════════════════════════════════════════════════════════════════════╝
";
        }

        private int GetConfigValueOrDefault(string key, int defaultValue)
        {
            var val = ConfigurationManager.AppSettings[key];
            return int.TryParse(val, out var parsed) ? parsed : defaultValue;
        }
    }
}
