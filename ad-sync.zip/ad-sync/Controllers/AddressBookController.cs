﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web.Configuration;
using System.Web.Http;

namespace ADGlobalService.Controllers
{
    public class AddressBookController : ApiController
    {
        string ADFUrl = WebConfigurationManager.AppSettings["ADFUrl"];
        string ADLoginUser = WebConfigurationManager.AppSettings["ADLoginUser"];
        string ADLoginPass = WebConfigurationManager.AppSettings["ADLoginPass"];

        public class AddressBookPros
        {
            public string propvarADfullName { get; set; }
            public string propvarADdisplayName { get; set; }
            public string propvarADemployeeID { get; set; }
            public string propvarNTaccount { get; set; }
            public string propvarADManagerName { get; set; }
            public string propvarADdepartment { get; set; }
            public string propvarADJobtitle { get; set; }
            public string propvarADMobile { get; set; }
            public string propvarADCompanyname { get; set; }
            public string propvarADOffice { get; set; }
            public string propvarADemail { get; set; }
            public string propvarADManagerNT { get; set; }
            public string propvarADSubdepartment { get; set; }
            public string propvarADCostcenter { get; set; }
            public string propvarADHiringdate { get; set; }
            public string propvarUserSapID { get; set; }
        }
        string ADemployeeID = "employeeID";
        string ADsAMAccountName = "sAMAccountName";
        string ADfullName = "fullName";
        string ADdisplayName = "DisplayName";
        string ADManagerName = "gweReportingTo";
        string ADdepartment = "extensionAttribute9";
        string ADJobtitle = "extensionAttribute4";
        string ADMobile = "mobile";
        string ADemail = "mail";
        string ADSubdepartment = "extensionAttribute6";
        string ADCostcenter = "extensionAttribute3";
        string ADCompanyname = "company";
        string ADOffice = "physicalDeliveryOfficeName";
        string ADHiringdate = "extensionAttribute5";
        string ADSAPID = "extensionAttribute10";
        string ADManagerNT = "extensionAttribute7";
        string ADUserSapID = "extensionAttribute10";



        //https://localhost:44352/api/AddressBook/ADBookSearch?SearchQuery=01024877494
        [HttpGet]
        public IHttpActionResult ADBookSearch(string SearchQuery)
        {
            AddressBookPros values;
            string RegNumberpattern = @"^-?\d*\.?\d+$";

            if (Regex.IsMatch(SearchQuery, RegNumberpattern))
            {
                values = SearchByMobile(SearchQuery);
                if (values == null)
                {
                    values = SearchByStaffID(SearchQuery);
                }
            }
            else
            {
                if (SearchQuery.ToLower().Contains(".com"))
                {
                    values = SearchByEmail(SearchQuery);
                }
                else
                {
                    values = SearchByNT(SearchQuery);
                }
            }
            return Ok(values);
        }
        public AddressBookPros SearchByMobile(string mobileNum)
        {
            AddressBookPros responseData;
            SearchResult SPN = ADProperty(ADMobile, mobileNum);

            if (SPN != null)
            {
                string varADfullName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADfullName].Value);
                string varADdisplayName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADdisplayName].Value);
                string varADemployeeID = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADemployeeID].Value);
                string varNTaccount = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADsAMAccountName].Value);
                string varADManagerName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADManagerName].Value);
                string varADdepartment = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADdepartment].Value);
                string varADJobtitle = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADJobtitle].Value);
                string varADMobile = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADMobile].Value);
                string varADCompanyname = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADCompanyname].Value);
                string varADOffice = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADOffice].Value);
                string varADemail = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADemail].Value);
                string varADManagerNT = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADManagerNT].Value);
                string varADSubdepartment = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADSubdepartment].Value);
                string varADCostcenter = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADCostcenter].Value);
                string varADHiringdate = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADHiringdate].Value);
                string varUserSapID = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADUserSapID].Value);

                responseData = new AddressBookPros
                {
                    propvarADfullName = varADfullName,
                    propvarADdisplayName = varADdisplayName,
                    propvarADemployeeID = varADemployeeID,
                    propvarNTaccount = varNTaccount,
                    propvarADManagerName = varADManagerName,
                    propvarADdepartment = varADdepartment,
                    propvarADJobtitle = varADJobtitle,
                    propvarADMobile = varADMobile,
                    propvarADCompanyname = varADCompanyname,
                    propvarADOffice = varADOffice,
                    propvarADemail = varADemail,
                    propvarADManagerNT = varADManagerNT,
                    propvarADSubdepartment = varADSubdepartment,
                    propvarADCostcenter = varADCostcenter,
                    propvarADHiringdate = varADHiringdate,
                    propvarUserSapID = varUserSapID
                };
            }
            else
            {
                responseData = null;
            }

            return responseData;
        }
        public AddressBookPros SearchByNT(string NTAcc)
        {
            AddressBookPros responseData;
            SearchResult SPN = ADProperty(ADsAMAccountName, NTAcc);
            if (SPN != null)
            {
                string varADfullName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADfullName].Value);
                string varADdisplayName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADdisplayName].Value);
                string varADemployeeID = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADemployeeID].Value);
                string varNTaccount = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADsAMAccountName].Value);
                string varADManagerName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADManagerName].Value);
                string varADdepartment = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADdepartment].Value);
                string varADJobtitle = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADJobtitle].Value);
                string varADMobile = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADMobile].Value);
                string varADCompanyname = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADCompanyname].Value);
                string varADOffice = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADOffice].Value);
                string varADemail = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADemail].Value);
                string varADManagerNT = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADManagerNT].Value);
                string varADSubdepartment = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADSubdepartment].Value);
                string varADCostcenter = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADCostcenter].Value);
                string varADHiringdate = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADHiringdate].Value);
                string varUserSapID = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADUserSapID].Value);

                responseData = new AddressBookPros
                {
                    propvarADfullName = varADfullName,
                    propvarADdisplayName = varADdisplayName,
                    propvarADemployeeID = varADemployeeID,
                    propvarNTaccount = varNTaccount,
                    propvarADManagerName = varADManagerName,
                    propvarADdepartment = varADdepartment,
                    propvarADJobtitle = varADJobtitle,
                    propvarADMobile = varADMobile,
                    propvarADCompanyname = varADCompanyname,
                    propvarADOffice = varADOffice,
                    propvarADemail = varADemail,
                    propvarADManagerNT = varADManagerNT,
                    propvarADSubdepartment = varADSubdepartment,
                    propvarADCostcenter = varADCostcenter,
                    propvarADHiringdate = varADHiringdate,
                    propvarUserSapID = varUserSapID
                };
            }
            else
            {
                responseData = null;
            }

            return responseData;

        }
        public AddressBookPros SearchByStaffID(string sttID)
        {
            AddressBookPros responseData;
            SearchResult SPN = ADProperty(ADemployeeID, sttID);

            if (SPN != null)
            {
                string varADfullName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADfullName].Value);
                string varADdisplayName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADdisplayName].Value);
                string varADemployeeID = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADemployeeID].Value);
                string varNTaccount = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADsAMAccountName].Value);
                string varADManagerName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADManagerName].Value);
                string varADdepartment = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADdepartment].Value);
                string varADJobtitle = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADJobtitle].Value);
                string varADMobile = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADMobile].Value);
                string varADCompanyname = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADCompanyname].Value);
                string varADOffice = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADOffice].Value);
                string varADemail = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADemail].Value);
                string varADManagerNT = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADManagerNT].Value);
                string varADSubdepartment = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADSubdepartment].Value);
                string varADCostcenter = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADCostcenter].Value);
                string varADHiringdate = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADHiringdate].Value);
                string varUserSapID = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADUserSapID].Value);

                responseData = new AddressBookPros
                {
                    propvarADfullName = varADfullName,
                    propvarADdisplayName = varADdisplayName,
                    propvarADemployeeID = varADemployeeID,
                    propvarNTaccount = varNTaccount,
                    propvarADManagerName = varADManagerName,
                    propvarADdepartment = varADdepartment,
                    propvarADJobtitle = varADJobtitle,
                    propvarADMobile = varADMobile,
                    propvarADCompanyname = varADCompanyname,
                    propvarADOffice = varADOffice,
                    propvarADemail = varADemail,
                    propvarADManagerNT = varADManagerNT,
                    propvarADSubdepartment = varADSubdepartment,
                    propvarADCostcenter = varADCostcenter,
                    propvarADHiringdate = varADHiringdate,
                    propvarUserSapID = varUserSapID
                };
            }
            else
            {
                responseData = null;
            }

            return responseData;

        }
        public AddressBookPros SearchByEmail(string Semail)
        {
            AddressBookPros responseData;
            SearchResult SPN = ADProperty(ADemail, Semail);

            if (SPN != null)
            {
                string varADfullName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADfullName].Value);
                string varADdisplayName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADdisplayName].Value);
                string varADemployeeID = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADemployeeID].Value);
                string varNTaccount = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADsAMAccountName].Value);
                string varADManagerName = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADManagerName].Value);
                string varADdepartment = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADdepartment].Value);
                string varADJobtitle = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADJobtitle].Value);
                string varADMobile = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADMobile].Value);
                string varADCompanyname = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADCompanyname].Value);
                string varADOffice = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADOffice].Value);
                string varADemail = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADemail].Value);
                string varADManagerNT = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADManagerNT].Value);
                string varADSubdepartment = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADSubdepartment].Value);
                string varADCostcenter = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADCostcenter].Value);
                string varADHiringdate = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADHiringdate].Value);
                string varUserSapID = Convert.ToString(SPN.GetDirectoryEntry().Properties[ADUserSapID].Value);

                responseData = new AddressBookPros
                {
                    propvarADfullName = varADfullName,
                    propvarADdisplayName = varADdisplayName,
                    propvarADemployeeID = varADemployeeID,
                    propvarNTaccount = varNTaccount,
                    propvarADManagerName = varADManagerName,
                    propvarADdepartment = varADdepartment,
                    propvarADJobtitle = varADJobtitle,
                    propvarADMobile = varADMobile,
                    propvarADCompanyname = varADCompanyname,
                    propvarADOffice = varADOffice,
                    propvarADemail = varADemail,
                    propvarADManagerNT = varADManagerNT,
                    propvarADSubdepartment = varADSubdepartment,
                    propvarADCostcenter = varADCostcenter,
                    propvarADHiringdate = varADHiringdate,
                    propvarUserSapID = varUserSapID
                };
            }
            else
            {
                responseData = null;
            }

            return responseData;
        }
        private SearchResult ADProperty(string searchProperty, string searchValue)
        {
            try
            {
                SearchResult result = null;

                string AdUrl = ADFUrl;
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                string query = string.Format("(&(objectClass=User)({0}={1}))", searchProperty, searchValue);
                search.Filter = query;
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add(ADsAMAccountName);
                search.PropertiesToLoad.Add(ADMobile);
                search.PropertiesToLoad.Add(ADdisplayName);
                search.PropertiesToLoad.Add(ADJobtitle);
                search.PropertiesToLoad.Add(ADdepartment);
                search.PropertiesToLoad.Add(ADemployeeID);
                search.PropertiesToLoad.Add(ADfullName);
                search.PropertiesToLoad.Add(ADManagerNT);
                search.PropertiesToLoad.Add(ADSAPID);
                search.PropertiesToLoad.Add(ADHiringdate);
                search.PropertiesToLoad.Add(ADOffice);
                search.PropertiesToLoad.Add(ADCostcenter);
                search.PropertiesToLoad.Add(ADSubdepartment);
                search.PropertiesToLoad.Add(ADemail);
                search.PropertiesToLoad.Add(ADManagerName);
                search.PropertiesToLoad.Add(ADCompanyname);
                search.PropertiesToLoad.Add(ADUserSapID);
                result = search.FindOne();
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
    }
}
