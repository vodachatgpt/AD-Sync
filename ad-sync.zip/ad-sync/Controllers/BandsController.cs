﻿using ADGlobalService.Data;
using System;
using System.Linq;
using System.Web.Http;

namespace ADGlobalService.Controllers
{
    public class BandsController : ApiController
    {
        // Example: https://localhost:44352/api/Bands/BandsSearch?SearchQuery=01024877494
        [HttpGet]
        public IHttpActionResult BandsSearch(string SearchQuery)
        {
            if (string.IsNullOrWhiteSpace(SearchQuery))
                return BadRequest("SearchQuery is required.");

            HREmployeeBandTBL result = null;

            // Check if SearchQuery is numeric
            if (IsNumeric(SearchQuery))
            {
                // First try StaffID
                result = SearchByStaffID(SearchQuery);
                if (result == null)
                {
                    // If not found, try SAPID
                    result = SearchBySapID(SearchQuery);
                }
            }
            else
            {
                // Check if it's an email
                if (SearchQuery.Contains("@"))
                {
                    result = SearchByEmail(SearchQuery);
                }
                else
                {
                    result = SearchByFullName(SearchQuery);
                }
            }

            if (result == null)
                return NotFound();

            return Ok(result);
        }

        #region Private Helpers

        private bool IsNumeric(string input)
        {
            return long.TryParse(input, out _); // Accepts both int and long numeric formats
        }

        private HREmployeeBandTBL SearchByStaffID(string searchQuery)
        {
            using (var ctx = new HREmployeeBandsEntities())
            {
                return ctx.HREmployeeBandTBLs
                    .Where(c => c.EmployeeNumber == searchQuery)
                    .OrderByDescending(c => c.ID)
                    .FirstOrDefault();
            }
        }

        private HREmployeeBandTBL SearchBySapID(string searchQuery)
        {
            using (var ctx = new HREmployeeBandsEntities())
            {
                return ctx.HREmployeeBandTBLs
                    .Where(c => c.SapNumber == searchQuery)
                    .OrderByDescending(c => c.ID)
                    .FirstOrDefault();
            }
        }

        private HREmployeeBandTBL SearchByEmail(string searchQuery)
        {
            using (var ctx = new HREmployeeBandsEntities())
            {
                return ctx.HREmployeeBandTBLs
                    .Where(c => c.EmailAddress == searchQuery)
                    .OrderByDescending(c => c.ID)
                    .FirstOrDefault();
            }
        }

        private HREmployeeBandTBL SearchByFullName(string searchQuery)
        {
            using (var ctx = new HREmployeeBandsEntities())
            {
                return ctx.HREmployeeBandTBLs
                    .Where(c => c.FullName == searchQuery)
                    .OrderByDescending(c => c.ID)
                    .FirstOrDefault();
            }
        }

        #endregion
    }
}
