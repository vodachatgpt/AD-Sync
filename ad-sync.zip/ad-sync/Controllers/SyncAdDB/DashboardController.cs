﻿using ADGlobalService.Data;
using ADGlobalService.Models.SyncAdDBDtos.Dashborad;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace ADGlobalService.Controllers.SyncAdDB
{
    [RoutePrefix("api/dashboard")]
    public class DashboardController : ApiController
    {
        private readonly ActiveDirectoryDBEntities _db;

        public DashboardController() : this(new ActiveDirectoryDBEntities()) { }
        public DashboardController(ActiveDirectoryDBEntities db)
        {
            _db = db ?? throw new ArgumentNullException(nameof(db));
            _db.Configuration.LazyLoadingEnabled = false;
            _db.Configuration.ProxyCreationEnabled = false;
            _db.Database.CommandTimeout = 120;
        }

        [HttpGet]
        [Route("summary")]
        public async Task<IHttpActionResult> GetSummary()
        {
            // Only read aggregate data. Nothing in this endpoint changes SQL.
            // All categories below count non-deleted users, except TotalUsers/DeletedUsers.
            var all = _db.DirectoryUsers.AsNoTracking();
            var current = all.Where(x => !x.IsDeleted);
            var cutoff = DateTime.UtcNow.AddDays(-30);

            var status = await all.GroupBy(x => 1).Select(g => new
            {
                Total = g.Count(),
                Deleted = g.Count(x => x.IsDeleted),
                Current = g.Count(x => !x.IsDeleted),
                Active = g.Count(x => !x.IsDeleted && x.IsEnabled == true),
                Disabled = g.Count(x => !x.IsDeleted && x.IsEnabled == false),
                Unknown = g.Count(x => !x.IsDeleted && x.IsEnabled == null)
            }).FirstOrDefaultAsync();

            var summary = new DashboardSummaryDto();
            if (status != null)
            {
                summary.TotalUsers = status.Total;
                summary.DeletedUsers = status.Deleted;
                summary.CurrentUsers = status.Current;
                summary.ActiveUsers = status.Active;
                summary.DisabledUsers = status.Disabled;
                summary.UnknownStatusUsers = status.Unknown;
            }

            // Avoid loading 27k entities for data-quality KPIs.
            var quality = await current.GroupBy(x => 1).Select(g => new
            {
                WithEmail = g.Count(x => x.Email != null && x.Email != ""),
                NoEmail = g.Count(x => x.Email == null || x.Email == ""),
                NoNt = g.Count(x => x.NT == null || x.NT == ""),
                NoDisplayName = g.Count(x => x.DisplayName == null || x.DisplayName == ""),
                NoDepartment = g.Count(x => x.Department == null || x.Department == ""),
                NoSubDepartment = g.Count(x => x.SubDepartment == null || x.SubDepartment == ""),
                NoStaffId = g.Count(x => x.StaffId == null || x.StaffId == ""),
                NoOffice = g.Count(x => x.Office == null || x.Office == ""),
                NoJobTitle = g.Count(x => x.JobTitle == null || x.JobTitle == ""),
                NoGender = g.Count(x => x.Gender == null || x.Gender == ""),
                NoManagerDn = g.Count(x => x.ManagerDistinguishedName == null || x.ManagerDistinguishedName == ""),
                Linked = g.Count(x => x.ManagerUserId.HasValue),
                MissingManager = g.Count(x => !x.ManagerUserId.HasValue),
                UnresolvedManager = g.Count(x => !x.ManagerUserId.HasValue &&
                    x.ManagerDistinguishedName != null && x.ManagerDistinguishedName != ""),
                CreatedRecently = g.Count(x => x.CreatedInAdAtUtc >= cutoff),
                ModifiedRecently = g.Count(x => x.ModifiedInAdAtUtc >= cutoff)
            }).FirstOrDefaultAsync();

            if (quality != null)
            {
                summary.WithEmailCount = quality.WithEmail;
                summary.MissingEmailCount = quality.NoEmail;
                summary.MissingNtCount = quality.NoNt;
                summary.MissingDisplayNameCount = quality.NoDisplayName;
                summary.MissingDepartmentCount = quality.NoDepartment;
                summary.MissingSubDepartmentCount = quality.NoSubDepartment;
                summary.MissingStaffIdCount = quality.NoStaffId;
                summary.MissingOfficeCount = quality.NoOffice;
                summary.MissingJobTitleCount = quality.NoJobTitle;
                summary.MissingGenderCount = quality.NoGender;
                summary.MissingManagerDnCount = quality.NoManagerDn;
                summary.LinkedUsers = quality.Linked;
                summary.MissingManagerCount = quality.MissingManager;
                summary.UnresolvedManagerCount = quality.UnresolvedManager;
                summary.CreatedInAdLast30Days = quality.CreatedRecently;
                summary.ModifiedInAdLast30Days = quality.ModifiedRecently;
            }

            // Returned after SQL grouping (few rows), then merged for whitespace/case.
            var deptRows = await current
                .Where(x => x.Department != null && x.Department != "")
                .GroupBy(x => x.Department)
                .Select(g => new { Name = g.Key, Count = g.Count() }).ToListAsync();
            summary.UsersByDepartment = Merge(deptRows.Select(x => new DashboardBreakdownDto
            {
                Name = x.Name,
                Count = x.Count
            }));
            summary.DepartmentsCount = summary.UsersByDepartment.Count;

            var subRows = await current
                .Where(x => x.Department != null && x.Department != "" &&
                            x.SubDepartment != null && x.SubDepartment != "")
                .GroupBy(x => new { x.Department, x.SubDepartment })
                .Select(g => new { g.Key.Department, g.Key.SubDepartment, Count = g.Count() })
                .ToListAsync();
            summary.UsersBySubDepartment = subRows
                .GroupBy(x => (x.Department.Trim() + "\u001f" + x.SubDepartment.Trim()),
                    StringComparer.OrdinalIgnoreCase)
                .Select(g => new DashboardSubDepartmentDto
                {
                    Department = g.First().Department.Trim(),
                    Name = g.First().SubDepartment.Trim(),
                    Count = g.Sum(x => x.Count)
                })
                .OrderBy(x => x.Department).ThenBy(x => x.Name).ToList();
            summary.SubDepartmentsCount = summary.UsersBySubDepartment.Count;

            // IsInternal is a string from AD (gweinternalUser), NOT a SQL bit.
            // Missing/unrecognized values are NOT counted as outsourced.
            var employmentRows = await current
                .GroupBy(x => x.IsInternal)
                .Select(g => new { RawValue = g.Key, Count = g.Count() })
                .ToListAsync();
            foreach (var row in employmentRows)
            {
                switch (ClassifyInternal(row.RawValue))
                {
                    case 1: summary.InternalUsersCount += row.Count; break;
                    case 2: summary.OutsourceUsersCount += row.Count; break;
                    default: summary.UnknownInternalStatusCount += row.Count; break;
                }
            }
            // Show all distinct raw values including blanks for validation.
            summary.UsersByInternalStatus = Merge(employmentRows.Select(row => new DashboardBreakdownDto
            {
                Name = string.IsNullOrWhiteSpace(row.RawValue) ? "(missing)" : row.RawValue,
                Count = row.Count
            }));

            // Breakdown of internal/external per department (aggregate in SQL).
            var departmentStaffingRows = await current
                .Where(x => x.Department != null && x.Department != "")
                .GroupBy(x => new { x.Department, x.IsInternal })
                .Select(g => new { g.Key.Department, g.Key.IsInternal, Count = g.Count() })
                .ToListAsync();
            foreach (var group in departmentStaffingRows
                .Where(x => !string.IsNullOrWhiteSpace(x.Department))
                .GroupBy(x => x.Department.Trim(), StringComparer.OrdinalIgnoreCase))
            {
                var breakdown = new DashboardDepartmentStaffingDto { Department = group.Key };
                foreach (var item in group)
                {
                    switch (ClassifyInternal(item.IsInternal))
                    {
                        case 1: breakdown.InternalCount += item.Count; break;
                        case 2: breakdown.OutsourceCount += item.Count; break;
                        default: breakdown.UnknownCount += item.Count; break;
                    }
                }
                summary.StaffingByDepartment.Add(breakdown);
            }
            summary.StaffingByDepartment = summary.StaffingByDepartment
                .OrderBy(x => x.Department).ToList();

            // Long-tail distributions are limited to top 25 categories to keep response light.
            summary.UsersByJobTitle = await TopBreakdownAsync(current.Select(x => x.JobTitle), 25);
            summary.UsersByOffice = await TopBreakdownAsync(current.Select(x => x.Office), 25);
            summary.UsersByCompany = await TopBreakdownAsync(current.Select(x => x.CompanyName), 25);
            summary.UsersByCountry = await TopBreakdownAsync(current.Select(x => x.CountryName), 25);
            summary.UsersByGender = await TopBreakdownAsync(current.Select(x => x.Gender), 25);

            // Count distinct managers who actually have non-deleted direct reports.
            var managerRows = await current
                .Where(x => x.ManagerUserId.HasValue)
                .GroupBy(x => x.ManagerUserId.Value)
                .Select(g => new { UserId = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .ToListAsync();
            summary.ManagersCount = managerRows.Count;
            var top = managerRows.Take(15).ToList();
            var topIds = top.Select(x => x.UserId).ToList();
            var topPeople = await current.Where(x => topIds.Contains(x.UserId))
                .Select(x => new { x.UserId, x.DisplayName, x.FullName, x.NT, x.Department })
                .ToListAsync();
            var byId = topPeople.ToDictionary(x => x.UserId);
            foreach (var item in top)
            {
                if (!byId.ContainsKey(item.UserId)) continue;
                var user = byId[item.UserId];
                summary.TopManagers.Add(new DashboardManagerDto
                {
                    UserId = item.UserId,
                    Name = user.DisplayName ?? user.FullName ?? user.NT ?? "Unknown",
                    Department = user.Department,
                    DirectReports = item.Count
                });
            }

            // Account metadata and key/value attributes, independently aggregated in SQL.
            var metadata = _db.Set<DirectoryUserAccountMetadata>().AsNoTracking();
            summary.AccountMetadataRecords = await metadata.CountAsync();
            summary.MustChangePasswordCount = await metadata.CountAsync(x => x.MustChangePassword == true);
            summary.NeverExpiresCount = await metadata.CountAsync(x => x.AccountNeverExpires == true);
            summary.AccountsWithLockoutTimeCount = await metadata.CountAsync(x => x.LockoutTimeUtc.HasValue);

            var attributes = _db.Set<DirectoryUserAttributeValue>().AsNoTracking();
            summary.AttributeValueRows = await attributes.CountAsync();
            var attributeRows = await attributes.GroupBy(x => x.AttributeName)
                .Select(g => new { Name = g.Key, Count = g.Count() }).ToListAsync();
            summary.AttributeTypes = Merge(attributeRows.Select(x => new DashboardBreakdownDto
            {
                Name = x.Name,
                Count = x.Count
            }));
            summary.AttributeTypesCount = summary.AttributeTypes.Count;

            //summary.SyncStates = await _db.Set<DirectorySyncState>().AsNoTracking()
            //    .OrderByDescending(x => x.LastSuccessfulSyncUtc)
            //    .Select(x => new DashboardSyncStateDto
            //    {
            //        SyncName = x.SyncName,
            //        TrackingMethod = x.TrackingMethod,
            //        UsnWatermark = x.UsnWatermark,
            //        LastSuccessfulSyncUtc = x.LastSuccessfulSyncUtc,
            //        DomainControllerName = x.DomainControllerName
            //    }).ToListAsync();

            //var adSync = summary.SyncStates.FirstOrDefault(x => x.SyncName == "AD-Users");
            //if (adSync != null)
            //{
            //    summary.LastSyncUtc = adSync.LastSuccessfulSyncUtc;
            //    summary.UsnWatermark = adSync.UsnWatermark;
            //    summary.DomainControllerName = adSync.DomainControllerName;
            //}

            // Optional tables: safe even when group sync schema is not deployed.
            // Dynamic SQL avoids referencing a missing table during SQL compilation.
            var counts = await _db.Database.SqlQuery<DashboardGroupCountsRow>(@"
                DECLARE @g int = 0, @ug int = 0, @gg int = 0;
                IF OBJECT_ID(N'dbo.DirectoryGroups', N'U') IS NOT NULL
                    EXEC sp_executesql N'SELECT @count = COUNT(*) FROM dbo.DirectoryGroups',
                        N'@count int OUTPUT', @count = @g OUTPUT;
                IF OBJECT_ID(N'dbo.DirectoryUserGroupMemberships', N'U') IS NOT NULL
                    EXEC sp_executesql N'SELECT @count = COUNT(*) FROM dbo.DirectoryUserGroupMemberships',
                        N'@count int OUTPUT', @count = @ug OUTPUT;
                IF OBJECT_ID(N'dbo.DirectoryGroupMemberships', N'U') IS NOT NULL
                    EXEC sp_executesql N'SELECT @count = COUNT(*) FROM dbo.DirectoryGroupMemberships',
                        N'@count int OUTPUT', @count = @gg OUTPUT;
                SELECT @g AS GroupsCount, @ug AS UserGroupMembershipsCount,
                       @gg AS NestedGroupMembershipsCount;
            ").SingleAsync();
            summary.GroupsCount = counts.GroupsCount;
            summary.UserGroupMembershipsCount = counts.UserGroupMembershipsCount;
            summary.NestedGroupMembershipsCount = counts.NestedGroupMembershipsCount;

            return Ok(summary);
        }

        // 1 = Internal, 2 = External/Outsource, 0 = Unknown.
        // Verify these source values against your actual AD data/business definition.
        private static int ClassifyInternal(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return 0;
            switch (raw.Trim().ToLowerInvariant())
            {
                case "true":
                case "1":
                case "yes":
                case "y":
                case "internal":
                case "insource":
                case "in-source":
                case "inhouse": return 1;
                case "false":
                case "0":
                case "no":
                case "n":
                case "external":
                case "outsourced":
                case "outsource": return 2;
                default: return 0;
            }
        }

        // IQueryable<string> is still a SQL query; execution happens at ToListAsync.
        private static async Task<List<DashboardBreakdownDto>> TopBreakdownAsync(
            IQueryable<string> values, int top)
        {
            var rows = await values.Where(x => x != null && x != "")
                .GroupBy(x => x)
                .Select(g => new DashboardBreakdownDto { Name = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .Take(top)
                .ToListAsync();
            return Merge(rows);
        }

        private static List<DashboardBreakdownDto> Merge(IEnumerable<DashboardBreakdownDto> values)
        {
            return values.Where(x => !string.IsNullOrWhiteSpace(x.Name))
                .GroupBy(x => x.Name.Trim(), StringComparer.OrdinalIgnoreCase)
                .Select(g => new DashboardBreakdownDto
                {
                    Name = g.Key,
                    Count = g.Sum(x => x.Count)
                })
                .OrderByDescending(x => x.Count).ThenBy(x => x.Name).ToList();
        }



        protected override void Dispose(bool disposing)
        {
            if (disposing) _db.Dispose();
            base.Dispose(disposing);
        }
    }


}

