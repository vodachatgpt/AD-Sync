﻿using ADGlobalService.Data;
using ADGlobalService.Services.SyncAdDB;
using System;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;
using System.Web.Http;

namespace ADGlobalService.Controllers.SyncAdDB
{
    [RoutePrefix("api/groups")]
    public class GroupsController : ApiController
    {
        private readonly IGroupsService _groupsService;

        public GroupsController(IGroupsService groupsService)
        {
            _groupsService = groupsService
                ?? throw new ArgumentNullException(nameof(groupsService));
        }


        // ============================================
        // GET GROUPS
        // ============================================

        [HttpGet]
        [Route("")]
        public async Task<IHttpActionResult> GetGroups(
            string search = null,
            string searchField = "all",
            int page = 1,
            int pageSize = 50)
        {
            var result = await _groupsService.GetGroupsAsync(
                search,
                searchField,
                page,
                pageSize);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }


        // ============================================
        // GET GROUP MEMBERS
        // ============================================

        [HttpGet]
        [Route("{groupId:long}/members")]
        public async Task<IHttpActionResult> GetGroupMembers(
            long groupId,
            int page = 1,
            int pageSize = 50,
            string search = null,
            string searchField = "email")
        {
            var result = await _groupsService.GetGroupMembersAsync(
                groupId,
                page,
                pageSize,
                search,
                searchField);

            if (result.IsFailure)
            {
                if (result.Error.Code == "Groups.NotFound")
                    return NotFound();

                return BadRequest(result.Error.Description);
            }

            return Ok(result.Value);
        }
    }
}