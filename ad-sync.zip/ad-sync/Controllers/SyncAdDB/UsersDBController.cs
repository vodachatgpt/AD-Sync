﻿using ADGlobalService.Abstractions;
using ADGlobalService.Models.SyncAdDBDtos;
using ADGlobalService.Services.ActiveDirectoryService;
using ADGlobalService.Services.SyncAdDB;
using Newtonsoft.Json.Linq;
using System;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace ADGlobalService.Controllers
{
    [RoutePrefix("api/users")]
    public sealed class UsersDBController : ApiController
    {
        private readonly ISyncAdDBService _dBService;

        public UsersDBController(ISyncAdDBService dBService)
        {
            _dBService = dBService
                ?? throw new ArgumentNullException(nameof(dBService));
        }


        [HttpGet]
        [Route("ad/members")]

        public async Task<IHttpActionResult> GetMembersFromAd(string department)
        {
            if (string.IsNullOrWhiteSpace(department))
            {
                return BadRequest("Department is required.");
            }

            Result<JArray> result =
                await _dBService.GetMembersFromAdAsync(department);

            if (result.IsFailure)
            {
                return Content(HttpStatusCode.BadGateway, result.Error);
            }

            return Ok(result.Value);
        }


        [HttpPost]
        [Route("sync")]
        public async Task<IHttpActionResult> SyncDirectoryChanges()
        {

            Result<DirectorySyncSummaryDto> result = await _dBService.SyncDirectoryChangesAsync();

            if (result.IsFailure)
            {
                return Content(HttpStatusCode.BadRequest, result.Error);
            }

            return Ok(result.Value);

        }




        [HttpGet]
        [Route("by-department")]
        public async Task<IHttpActionResult> GetUsersByDepartment(
            string department = null,
            bool hierarchical = false)
        {
            var result = await _dBService.GetUsersByDepartmentAsync(
                department,
                hierarchical);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }



        [HttpGet]
        [Route("changes/by-department")]
        public async Task<IHttpActionResult> GetDepartmentChanges(
            string department)
        {
            var result = await _dBService.GetDepartmentChangesAsync(department);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }



        // =====================================================
        // 1. SEARCH EMPLOYEES
        // =====================================================

        [HttpGet]
        [Route("search")]
        public async Task<IHttpActionResult> SearchUsers(
            string search,
            string searchField,
            string department = null,
            int page = 1,
            int pageSize = 20)
        {
            var result = await _dBService.SearchUsersAsync(
                search,
                searchField,
                department,
                page,
                pageSize);


            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }


        // =====================================================
        // 2. GET USER ANCESTORS
        // =====================================================

        [HttpGet]
        [Route("{userId:long}/ancestors")]
        public async Task<IHttpActionResult> GetUserAncestors(
            long userId)
        {
            var result = await _dBService.GetUserAncestorsAsync(userId);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }


        // =====================================================
        // 3. GET DIRECT REPORTS
        // =====================================================


        [HttpGet]
        [Route("{userId:long}/reports")]
        public async Task<IHttpActionResult> GetDirectReports(
            long userId,
            int page = 1,
            int pageSize = 20,
            string department = null)
        {
            var result = await _dBService.GetDirectReportsAsync(
                userId,
                page,
                pageSize,
                department);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }



        // =====================================================
        // 4. GET ROOT EMPLOYEES
        // =====================================================

        [HttpGet]
        [Route("roots")]
        public async Task<IHttpActionResult> GetRootUsers(
            string department = null,
            int page = 1,
            int pageSize = 20)
        {
            var result = await _dBService.GetRootUsersAsync(
                department,
                page,
                pageSize);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }


        // =====================================================
        // 5. GET DEPARTMENTS
        // =====================================================

        [HttpGet]
        [Route("departments")]
        public async Task<IHttpActionResult> GetDepartments()
        {
            var result = await _dBService.GetDepartmentsAsync();

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }


        // =====================================================
        // 6. GET USER PROFILE
        // =====================================================

        [HttpGet]
        [Route("{userId:long}")]
        public async Task<IHttpActionResult> GetUserById(
            long userId)
        {
            var result = await _dBService.GetUserByIdAsync(userId);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }




        [HttpPost]
        [Route("upsert")]
        public async Task<IHttpActionResult> UpsertDirectoryUsers(
            [FromBody] JArray users)
        {



            var result = await _dBService
                .UpsertDirectoryUsersAsync(users);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }




        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _dBService.Dispose();
            }

            base.Dispose(disposing);
        }



        [HttpGet]
        [Route("hierarchy/root")]
        public async Task<IHttpActionResult> GetHierarchyRoot()
        {
            Result<DirectoryUserItemDto> result = await _dBService.GetHierarchyRootAsync();

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }


        [HttpGet]
        [Route("DirectoryUsers")]
        public async Task<IHttpActionResult> GetDirectoryUsers(
            string search = null,
            string department = null,
            string subDepartment = null,
            bool? isEnabled = null,
            int page = 1,
            int pageSize = 50,
            string searchField = "all")
        {
            Result<PagedResultDto<DirectoryUserItemDto>> result = await _dBService.GetDirectoryUsersAsync(
                search,
                department,
                subDepartment,
                isEnabled,
                page,
                pageSize,
                searchField);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }


        [HttpGet]
        [Route("departments/subdepartments")]
        public async Task<IHttpActionResult> GetDepartmentsWithSubDepartments(
           string department = null)
        {
            var result = await _dBService
                .GetDepartmentsWithSubDepartmentsAsync(department);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }



        [HttpGet]
        [Route("{userId:long}/children")]
        public async Task<IHttpActionResult> GetHierarchyChildren(long userId)
        {
            var result = await _dBService.GetHierarchyChildrenAsync(userId);

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }




        [HttpPost]
        [Route("sync-groups")]
        public async Task<IHttpActionResult> SyncGroups()
        {
            var result = await _dBService.SyncGroupsAsync();

            if (result.IsFailure)
                return BadRequest(result.Error.Description);

            return Ok(result.Value);
        }


        [HttpPost]
        [Route("sync-deleted")]
        public async Task<IHttpActionResult> SyncDeletedObjects(
         [FromUri] bool dryRun = false)
        {
            var result = await _dBService
                .SyncDeletedObjectsAsync(dryRun);

            if (result.IsFailure)
                return Content(
                    System.Net.HttpStatusCode.BadRequest,
                    result.Error.Description);

            return Ok(result.Value);
        }
    }

}