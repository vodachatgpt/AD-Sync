﻿using ADGlobalService.Abstractions;
using ADGlobalService.Services.SyncAdDB.UserPhotos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;
using System.Web.Http;

namespace ADGlobalService.Controllers.SyncAdDB
{
    [RoutePrefix("api/photos")]
    public sealed class UserPhotosController : ApiController
    {
        private readonly IUserPhotosService _service;

        public UserPhotosController(IUserPhotosService service)
        {
            _service = service
                ?? throw new ArgumentNullException(nameof(service));
        }

        [HttpPost]
        [Route("sync")]
        public async Task<IHttpActionResult> SyncAll(int pageSize = 100)
        {
            var result = await _service.SyncAllAsync(pageSize);

            if (result.IsFailure)
                return ErrorResult(result.Error);

            return Ok(result.Value);
        }

      
        [HttpGet]
        [Route("{userId:long}")]
        public async Task<IHttpActionResult> GetPhoto(long userId, string resolution = "96x96")
        {
            var result = await _service.GetPhotoAsync(userId, resolution);
            if (result.IsFailure)
                return ErrorResult(result.Error);

            var photo = result.Value;
            var response = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(photo.Photo)
            };
            response.Content.Headers.ContentType = new MediaTypeHeaderValue(photo.ContentType);
            return ResponseMessage(response);
        }

        private IHttpActionResult ErrorResult(Error error)
        {
            switch (error.Code)
            {
                case "Photos.InvalidRequest":
                case "Photos.InvalidResolution":
                    return BadRequest(error.Description);
                case "Photos.UserNotFound":
                case "Photos.NotFound":
                    return NotFound();
                default:
                    // Do not expose exception internals to API consumers.
                    return Content(HttpStatusCode.InternalServerError, error.Description);
            }
        }
    }
}

