﻿using ADGlobalService.Data;
using Microsoft.Graph.Models.Security;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Entity;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Net.Http;
using System.Web.Configuration;
using System.Web.Http;

namespace ADGlobalService.Controllers
{
    [RoutePrefix("api/ADGroups")]
    public class ADDLController : ApiController
    {
        private readonly string ADFUrl = WebConfigurationManager.AppSettings["ADFUrl"];
        private readonly string ADLoginUser = WebConfigurationManager.AppSettings["ADLoginUser"];
        private readonly string ADLoginPass = WebConfigurationManager.AppSettings["ADLoginPass"];

        public class GroupProps
        {
            public string GroupName { get; set; }
            public string CurrentUserEmail { get; set; }
        }
        public class GroupMemberProps
        {
            public string GroupName { get; set; }
            public string NTAccount { get; set; }
            public string CurrentUserEmail { get; set; }
        }
        public class GroupMemberResult
        {
            public string MemberDisplayName { get; set; }
            public string NTAccount { get; set; }
        }

        [HttpPost]
        [Route("GetGroupOwner")]
        public IHttpActionResult GetGroupOwner(GroupProps groupProps)
        {
            if (string.IsNullOrEmpty(groupProps.GroupName))
                return BadRequest("Group name is required.");

            bool groupExist = CheckIFGroupNameExist(groupProps.GroupName);
            string groupOwner = groupExist ? GetGroupOwnerFullName(groupProps.GroupName) : "No Group With this Name";
            AddSPLog("GetGroupOwner", groupProps.GroupName, "NOUserAffectedByAction", groupProps.CurrentUserEmail);
            return Ok(groupOwner);
        }
        [HttpPost]
        [Route("GetGroupMembers")]
        public IHttpActionResult GetGroupMembers(GroupProps groupProps)
        {
            if (string.IsNullOrEmpty(groupProps.GroupName))
                return BadRequest("Group name is required.");

            AddSPLog("GetGroupMembers", groupProps.GroupName, "NOUserAffectedByAction", groupProps.CurrentUserEmail);
            bool groupExist = CheckIFGroupNameExist(groupProps.GroupName);
            if (!groupExist)
                return NotFound();

            List<GroupMemberResult> AllMemberEmails = ReturnAllFullNamesAndNT(groupProps.GroupName);
            return Ok(AllMemberEmails);
        }
        [HttpPost]
        [Route("AddMemberToGroup")]
        public IHttpActionResult AddMemberToGroup(GroupMemberProps groupMemberProps)
        {
            if (string.IsNullOrEmpty(groupMemberProps.GroupName) || string.IsNullOrEmpty(groupMemberProps.NTAccount) || string.IsNullOrEmpty(groupMemberProps.CurrentUserEmail))
                return BadRequest("All parameters are required.");

            if (!CheckIFGroupNameExist(groupMemberProps.GroupName))
                return Content(System.Net.HttpStatusCode.NotFound, "No Group with this Name.");

            if (!ValidateGroupOwner(groupMemberProps.GroupName.Trim(), groupMemberProps.CurrentUserEmail))
                return Content(System.Net.HttpStatusCode.Unauthorized, "You are not the owner of the group.");


            string email = getEmailFromNTAccount(groupMemberProps.NTAccount.Trim());
            if (string.IsNullOrEmpty(email))
                return BadRequest("NT Account does not exist.");

            AddUserToGroup(email, groupMemberProps.GroupName.Trim());
            AddSPLog("AddUserToGroup", groupMemberProps.GroupName.Trim(), email, groupMemberProps.CurrentUserEmail);
            return Ok("User added successfully.");
        }
        [HttpPost]
        [Route("RemoveMemberFromGroup")]
        public IHttpActionResult RemoveMemberFromGroup(GroupMemberProps groupMemberProps)
        {
            if (string.IsNullOrEmpty(groupMemberProps.GroupName) || string.IsNullOrEmpty(groupMemberProps.NTAccount) || string.IsNullOrEmpty(groupMemberProps.CurrentUserEmail))
                return BadRequest("All parameters are required.");

            if (!CheckIFGroupNameExist(groupMemberProps.GroupName.Trim()))
                return Content(System.Net.HttpStatusCode.NotFound, "No Group with this Name.");

            if (!ValidateGroupOwner(groupMemberProps.GroupName.Trim(), groupMemberProps.CurrentUserEmail))
                return Content(System.Net.HttpStatusCode.Unauthorized, "You are not the owner of the group.");

            string email = getEmailFromNTAccount(groupMemberProps.NTAccount.Trim());
            if (string.IsNullOrEmpty(email))
                return BadRequest("NT Account does not exist.");

            RemoveUserFromGroup(email, groupMemberProps.GroupName.Trim());
            AddSPLog("RemoveUserFromGroup", groupMemberProps.GroupName.Trim(), email, groupMemberProps.CurrentUserEmail);
            return Ok("User removed successfully.");
        }
        [HttpGet]
        [Route("GetAuditLogs")]
        public IHttpActionResult GetAuditLogs()
        {
            List<DLLogsTBL> AllMemberEmails = GetAllLogs();
            return Ok(AllMemberEmails);
        }

        private bool CheckIFGroupNameExist(string groupname)
        {
            try
            {
                SearchResult result = null;
                string AdUrl = "LDAP://DC=internal,DC=eg,DC=vodafone,DC=com";
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                string query = string.Format("(&(objectClass=group)({0}={1}))", "cn", groupname);
                search.Filter = query;
                search.PropertiesToLoad.Add("name");
                result = search.FindOne();
                if (result != null)
                {
                    return true;
                }
                else
                {
                    return false;
                }


            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return false;
            }
        }
        private string getEmailFromNTAccount(string ntAccount)
        {
            try
            {
                SearchResult result = null;



                string AdUrl = "LDAP://OU=DPT,DC=internal,DC=eg,DC=vodafone,DC=com";
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                string query = string.Format("(&(objectClass=User)({0}={1}))", "sAMAccountName", ntAccount);
                search.Filter = query;
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add("mail");
                result = search.FindOne();
                if (result != null)
                {
                    string ntEmail = Convert.ToString(result.GetDirectoryEntry().Properties["mail"].Value);
                    return ntEmail;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        public void AddUserToGroup(string userEmail, string groupName)
        {
            try
            {
                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, "internal.eg.vodafone.com", ADLoginUser, ADLoginPass))
                {
                    GroupPrincipal group = GroupPrincipal.FindByIdentity(pc, groupName);
                    group.Members.Add(pc, IdentityType.UserPrincipalName, userEmail);
                    group.Save();
                }
            }
            catch (System.DirectoryServices.DirectoryServicesCOMException E)
            {
                //doSomething with E.Message.ToString(); 

            }
        }
        public void RemoveUserFromGroup(string userEmail, string groupName)
        {
            try
            {
                using (PrincipalContext pc = new PrincipalContext(ContextType.Domain, "internal.eg.vodafone.com", ADLoginUser, ADLoginPass))
                {
                    GroupPrincipal group = GroupPrincipal.FindByIdentity(pc, groupName);
                    group.Members.Remove(pc, IdentityType.UserPrincipalName, userEmail);
                    group.Save();
                }
            }
            catch (System.DirectoryServices.DirectoryServicesCOMException E)
            {
                //doSomething with E.Message.ToString(); 

            }
        }
        private SearchResult GetGroupManager(string groupname)
        {
            try
            {
                SearchResult result = null;
                string AdUrl = "LDAP://DC=internal,DC=eg,DC=vodafone,DC=com";
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                string query = string.Format("(&(objectClass=group)({0}={1}))", "cn", groupname);
                search.Filter = query;
                search.PropertiesToLoad.Add("managedby");
                result = search.FindOne();
                return result;

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private string GetManagerFullPath(string groupname)
        {
            try
            {
                // SearchResult SPN = GetGroupManager("cn", "IT-OP FE Microsoft Support"); sampleCode
                SearchResult SPN = GetGroupManager(groupname);
                string Vmanagedby = Convert.ToString(SPN.GetDirectoryEntry().Properties["managedby"].Value);
                return Vmanagedby;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private string GetManagerEmail(string groupname)
        {
            try
            {
                SearchResult result = null;

                string AdUrl = "LDAP://" + GetManagerFullPath(groupname);
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add("mail");
                result = search.FindOne();
                string VownerEmail = Convert.ToString(result.GetDirectoryEntry().Properties["mail"].Value);
                return VownerEmail;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private bool ValidateGroupOwner(string groupname, string OwnerEmail)
        {
            // SearchResult SPN = GetGroupManager("cn", "IT-OP FE Microsoft Support"); sampleCode
            string adMangerEmail = GetManagerEmail(groupname);
            if (adMangerEmail != null || !string.IsNullOrEmpty(adMangerEmail))
            {
                if (adMangerEmail.ToLower() == OwnerEmail.ToLower())
                {
                    return true;

                }
                else
                {
                    return false;
                }
            }
            else
            {
                return false;
            }



        }
        private object[] GetGroupMembers(string groupname)
        {
            try
            {
                SearchResult result = null;
                string AdUrl = "LDAP://DC=internal,DC=eg,DC=vodafone,DC=com";
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                string query = string.Format("(&(objectClass=group)({0}={1}))", "cn", groupname);
                search.Filter = query;
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add("member");
                result = search.FindOne();
                var AllMembers = (object[])result.GetDirectoryEntry().Properties["member"].Value;
                return AllMembers;

            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private string GetMemberEmail(string Path)
        {
            try
            {
                SearchResult result = null;

                string AdUrl = "LDAP://" + Path;
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                //string query = string.Format("(&(objectClass=User)({0}={1}))", searchProperty, searchValue);
                //search.Filter = query;
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add("mail");
                result = search.FindOne();
                string VmemberEmail = Convert.ToString(result.GetDirectoryEntry().Properties["mail"].Value);
                return VmemberEmail;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private string GetMemberFullName(string Path)
        {
            try
            {
                SearchResult result = null;

                string AdUrl = "LDAP://" + Path;
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                //string query = string.Format("(&(objectClass=User)({0}={1}))", searchProperty, searchValue);
                //search.Filter = query;
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add("DisplayName");
                result = search.FindOne();
                string VmemberEmail = Convert.ToString(result.GetDirectoryEntry().Properties["DisplayName"].Value);
                return VmemberEmail;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private GroupMemberResult GetMemberFullNameandNT(string Path)
        {
            try
            {
                GroupMemberResult AllMemberEmails = new GroupMemberResult();
                SearchResult result = null;
                string AdUrl = "LDAP://" + Path;
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                //string query = string.Format("(&(objectClass=User)({0}={1}))", searchProperty, searchValue);
                //search.Filter = query;
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add("DisplayName");
                search.PropertiesToLoad.Add("sAMAccountName");
                result = search.FindOne();
                string VmemberEmail = Convert.ToString(result.GetDirectoryEntry().Properties["DisplayName"].Value);
                string VmemberNT = Convert.ToString(result.GetDirectoryEntry().Properties["sAMAccountName"].Value);

                AllMemberEmails.MemberDisplayName = VmemberEmail;
                AllMemberEmails.NTAccount = VmemberNT;


                return AllMemberEmails;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private ArrayList ReturnAllEmails(string groupname)
        {
            ArrayList AllMemberEmails = new ArrayList();
            object[] members = GetGroupMembers(groupname);
            for (int i = 0; i < members.Length; i++)
            {
                var member = members[i];
                string memberEmail = GetMemberEmail(member.ToString());
                AllMemberEmails.Add(memberEmail);

            }
            return AllMemberEmails;
        }
        private ArrayList ReturnAllFullNames(string groupname)
        {
            ArrayList AllMemberEmails = new ArrayList();
            object[] members = GetGroupMembers(groupname);
            for (int i = 0; i < members.Length; i++)
            {
                var member = members[i];
                string memberEmail = GetMemberFullName(member.ToString());
                AllMemberEmails.Add(memberEmail);

            }
            return AllMemberEmails;
        }
        private List<GroupMemberResult> ReturnAllFullNamesAndNT(string groupname)
        {
            List<GroupMemberResult> AllMemberEmails = new List<GroupMemberResult>();
            object[] members = GetGroupMembers(groupname);
            for (int i = 0; i < members.Length; i++)
            {
                var member = members[i];
                GroupMemberResult memberEmail = GetMemberFullNameandNT(member.ToString());
                AllMemberEmails.Add(memberEmail);

            }
            return AllMemberEmails;
        }
        private object[] GetLoginUsersAllGroups(string loggedinEmail)
        {
            try
            {
                SearchResult result = null;
                string AdUrl = "LDAP://DC=internal,DC=eg,DC=vodafone,DC=com";
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                string query = string.Format("(&(objectClass=User)({0}={1}))", "mail", loggedinEmail);
                search.Filter = query;
                search.SearchScope = SearchScope.Subtree;
                //search.PropertiesToLoad.Add("cn");
                search.PropertiesToLoad.Add("memberof");
                result = search.FindOne();
                var groupPath = (object[])result.GetDirectoryEntry().Properties["memberof"].Value;
                return groupPath;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private ArrayList GetGroupsOwnedbyLoginUser(string loggedinEmail)
        {
            try
            {
                ArrayList AllOwnedGroups = new ArrayList();
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                object[] Allgroups = GetLoginUsersAllGroups(loggedinEmail);
                for (int i = 0; i < Allgroups.Length; i++)
                {
                    var grouppath = Allgroups[i];
                    string stringPath = grouppath.ToString();

                    string AdUrl = "LDAP://" + stringPath;
                    SearchResult result = null;
                    DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                    DirectorySearcher search = new DirectorySearcher(entry);
                    search.SearchScope = SearchScope.Subtree;
                    search.PropertiesToLoad.Add("cn");
                    result = search.FindOne();
                    string groupName = Convert.ToString(result.GetDirectoryEntry().Properties["cn"].Value);
                    bool isOwner = ValidateGroupOwner(groupName, loggedinEmail);
                    if (isOwner)
                    {
                        AllOwnedGroups.Add(groupName);

                    }
                    else
                    {

                    }
                }
                return AllOwnedGroups;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private string GetGroupOwnerFullName(string groupname)
        {
            try
            {
                SearchResult result = null;

                string AdUrl = "LDAP://" + GetManagerFullPath(groupname);
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                //string query = string.Format("(&(objectClass=User)({0}={1}))", searchProperty, searchValue);
                //search.Filter = query;
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add("DisplayName");
                result = search.FindOne();
                string VownerEmail = Convert.ToString(result.GetDirectoryEntry().Properties["DisplayName"].Value);
                return VownerEmail;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private ArrayList GetAllADGroupNames()
        {
            try
            {
                ArrayList AllGroupNames = new ArrayList();
                SearchResultCollection results = null;
                string AdUrl = "LDAP://DC=internal,DC=eg,DC=vodafone,DC=com";
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                string query = string.Format("(&(objectClass=group))");
                search.Filter = query;
                search.SizeLimit = System.Int32.MaxValue;
                search.PageSize = System.Int32.MaxValue;
                search.PropertiesToLoad.Add("name");
                using (results = search.FindAll())
                {
                    foreach (SearchResult result in results)
                    {
                        //var groupPath = result.Path;
                        //AllGroupNames.Add(GetGroupName(groupPath));
                        AllGroupNames.Add(result.GetDirectoryEntry().Properties["name"].Value);
                    }
                }
                return AllGroupNames;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private string GetGroupName(string GroupPath)
        {
            try
            {
                SearchResult result = null;

                string AdUrl = GroupPath;
                string AdUserName = ADLoginUser;
                string AdPassword = ADLoginPass;
                DirectoryEntry entry = new DirectoryEntry(AdUrl, AdUserName, AdPassword);
                DirectorySearcher search = new DirectorySearcher(entry);
                search.SearchScope = SearchScope.Subtree;
                search.PropertiesToLoad.Add("name");
                result = search.FindOne();
                string groupName = Convert.ToString(result.GetDirectoryEntry().Properties["name"].Value);
                return groupName;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception caught: {0}", ex);
                return null;
            }
        }
        private ArrayList GetLoginUserGroups(string loginEmail)
        {
            ArrayList OwnedGroups = new ArrayList();
            ArrayList allGroupNames = GetAllADGroupNames();
            foreach (var groupName in allGroupNames)
            {
                string reEmail = GetManagerEmail(groupName.ToString());
                if (loginEmail == reEmail)
                {
                    OwnedGroups.Add(groupName);
                }
            }

            return OwnedGroups;
        }

        public static void AddSPLog(string Action,string GroupName,string UserAffectedByAction,string ActionTaker)
        {
            try
            {
                using (var context = new MailDLLogsEntities())
                {
                    var log = new DLLogsTBL
                    {
                        Action = Action,
                        GroupName = GroupName,
                        UserAffectedByAction = UserAffectedByAction,
                        ActionTaker = ActionTaker,
                        CreationDate = DateTime.UtcNow,
                        ModifiedDate = null
                    };

                    context.DLLogsTBLs.Add(log);
                    context.SaveChanges();
                }
            }
            catch
            {
                // IMPORTANT:
                // Logging must NEVER break business logic
                // (same behavior as SharePoint logging)
            }
        }
        public static List<DLLogsTBL> GetAllLogs()
        {
            using (var context = new MailDLLogsEntities())
            {
                return context.DLLogsTBLs.OrderByDescending(x => x.CreationDate).ToList();
            }
        }

    }
}
