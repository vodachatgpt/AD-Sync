using ADGlobalService.Models;
using ADGlobalService.Services.ActiveDirectoryService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Http;

namespace ADGlobalService.Controllers
{
    public class ADController : ApiController
    {
        private readonly IActiveDirectoryService _activeDirectoryService;

        /// <summary>Read one page of human accounts, including disabled accounts.</summary>
        [HttpGet]
        [System.Obsolete("Deprecated public paging endpoint. Use api/v2/AD/GetSyncSnapshot for one-request synchronization.")]
        public async Task<IHttpActionResult> GetUsersForSync(int pageSize = 500, string pageToken = null)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            try
            {
                var page = await _activeDirectoryService.GetUsersForSyncAsync(pageSize, pageToken);
                var response = Request.CreateResponse(HttpStatusCode.OK, page);
                response.Headers.CacheControl = new CacheControlHeaderValue { NoStore = true, Private = true };
                return ResponseMessage(response);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (DirectorySyncExpiredException ex)
            {
                return Content(HttpStatusCode.Gone, new { Message = ex.Message });
            }
            catch (DirectorySyncCapacityException ex)
            {
                var response = Request.CreateErrorResponse((HttpStatusCode)429, ex.Message);
                response.Headers.RetryAfter = new RetryConditionHeaderValue(TimeSpan.FromSeconds(60));
                return ResponseMessage(response);
            }
            catch (Exception ex)
            {
                Serilog.Log.Error(ex, "AD directory synchronization page failed.");
                return Content(HttpStatusCode.ServiceUnavailable,
                    new { Message = "Directory synchronization failed. Restart from the first page." });
            }
        }
        public ADController(IActiveDirectoryService activeDirectoryService)
        {
            _activeDirectoryService = activeDirectoryService;
        }

        //  https://localhost:44359/api/AD/GetUserData?email=ayman.elqassas@vodafone.com.eg
        [HttpGet]
        public async Task<IHttpActionResult> GetUserData(string email, bool includeProfileImage = false, string imageResolution = null, bool includeGroubMail = false)
        {
            bool includeExtendedData = true;
            var user = await _activeDirectoryService.GetUserAsync(email, FilterType.Email, includeExtendedData, includeProfileImage, imageResolution, includeGroubMail);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }



        //  https://localhost:44359/api/AD/ADBookSearch?SearchQuery=hassana9
        [HttpGet]
        public async Task<IHttpActionResult> ADBookSearch(string SearchQuery, bool includeProfileImage = false, string imageResolution = null, bool includeGroubMail = false)
        {
            bool includeExtendedData = true;
            var user = await _activeDirectoryService.FindUserAsync(SearchQuery, includeExtendedData, includeProfileImage, imageResolution, includeGroubMail);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }



        //https://localhost:44359/api/AD/GetDlMembers?DLName=Tech-IT MS SharePoint Solutions
        [HttpGet]
        public async Task<IHttpActionResult> GetDlMembers(string DLName, bool includeProfileImage = false, string imageResolution = "96x96")
        {
            IdentifierType identifierType = IdentifierType.GroupName;
            var members = await _activeDirectoryService.GetGroupMembers(DLName, identifierType, includeProfileImage, imageResolution);
            if (!members.Any())
            {
                return Ok("No Members In this Group");
            }
            return Ok(members);
        }



        //https://localhost:44359/api/AD/CheckIfUserExistInGroupByNT?DLName=Tech-IT MS SharePoint Solutions&NTAccount=Tarek-Badrm1
        [HttpPost]
        public async Task<IHttpActionResult> CheckIfUserExistInGroupByNT(string DLName, string NTAccount)
        {
            var isMember = await _activeDirectoryService.IsUserInGroupAsync(DLName, NTAccount, IdentifierType.NtAccount);
            if (isMember)
            {
                return Ok(true);
            }
            else
            {
                return Ok(false);
            }
        }



        //https://localhost:44359/api/AD/CheckIfUserExistInGroupByEmail?DLName=Tech-IT MS SharePoint Solutions&Email=mohamed.tarek-badr@vodafone.com.eg
        [HttpPost]
        public async Task<IHttpActionResult> CheckIfUserExistInGroupByEmail(string DLName, string Email)
        {
            var isMember = await _activeDirectoryService.IsUserInGroupAsync(DLName, Email, IdentifierType.Email);
            if (isMember)
            {
                return Ok(true);
            }
            else
            {
                return Ok(false);
            }
        }



        //https://localhost:44359/api/AD/GetAllDepartments
        [HttpGet]
        public async Task<IHttpActionResult> GetAllDepartments()
        {
            return Ok(await _activeDirectoryService.GetAllDepartmentsAsync());
        }



        // https://localhost:44359/api/AD/GetDlNameByEmail?email=Tech-ITMSSharePointSolutions@Vodafone.com.eg
        [HttpGet]
        public async Task<IHttpActionResult> GetDlNameByEmail(string email)
        {
            var dlName = await _activeDirectoryService.GetGroupNameByEmailAsync(email);
            if (dlName == null)
            {
                return NotFound();
            }
            return Ok(dlName);
        }
        [HttpGet]
        public async Task<IHttpActionResult> GetEmailByDlName(string dlName)
        {
            var email = await _activeDirectoryService
                .GetEmailByGroupNameAsync(dlName);

            if (email == null)
            {
                return NotFound();
            }

            return Ok(email);
        }
        // https://localhost:44359/api/AD/GetUserDistributionListEmails?userIdentifier=Thassana9@Vodafone.com.eg
        [HttpGet]
        public async Task<IHttpActionResult> GetUserDistributionListEmails(string userIdentifier)
        {
            var result = await _activeDirectoryService.GetUserDistributionListEmailsAsync(userIdentifier);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }


        // https://localhost:44359/api/AD/GetUserDirectDistributionListEmails?userIdentifier=Thassana9@Vodafone.com.eg
        [HttpGet]
        public async Task<IHttpActionResult> GetUserDirectDistributionListEmails(string userIdentifier)
        {
            var result = await _activeDirectoryService.GetUserDirectDistributionListEmailsAsync(userIdentifier);
            if (result == null)
            {
                return NotFound();
            }
            return Ok(result);
        }


        [HttpGet]
        public async Task<IHttpActionResult> GetSubDepartments(string parentDepartment)
        {
            return Ok(await _activeDirectoryService.GetSubDepartmentsAsync(parentDepartment));
        }



        [HttpGet]
        public async Task<IHttpActionResult> GetDlMembersByEmail(string dlEmail, bool includeProfileImage = false, string imageResolution = "96x96")
        {
            IdentifierType identifierType = IdentifierType.Email;
            var members = await _activeDirectoryService.GetGroupMembers(dlEmail, identifierType, includeProfileImage, imageResolution);
            if (!members.Any())
            {
                return Ok("No Members In this Group");
            }
            return Ok(members);
        }



        [HttpGet]
        public async Task<IHttpActionResult> GetMembersByDepartment(string department)
        {
            return Ok(await _activeDirectoryService.GetMembersByDepartmentAsync(department));
        }



        [HttpGet]
        public async Task<IHttpActionResult> NewHires(DateTime? date = null)
        {
            return Ok(await _activeDirectoryService.GetNewHiresAsync(date));
        }



        #region Legacy
        [HttpPost]
        public async Task<IHttpActionResult> OBJGetDlMembers(ServiceBody serviceBody)
        {
            var members = await _activeDirectoryService.GetGroupMembers(serviceBody.DlName, IdentifierType.GroupName);
            if (!members.Any())
            {
                return Ok("No Members In this Group");
            }
            return Ok(members);
        }

        [HttpPost]
        public async Task<IHttpActionResult> OBJCheckIfUserExistInGroupByNT(ServiceBody serviceBody)
        {
            var isMember = await _activeDirectoryService.IsUserInGroupAsync(serviceBody.DlName, serviceBody.NTAccount, IdentifierType.NtAccount);
            if (isMember)
            {
                return Ok(true);
            }
            else
            {
                return Ok(false);
            }
        }
        [HttpPost]
        public async Task<IHttpActionResult> OBJCheckIfUserExistInGroupByEmail(ServiceBody serviceBody)
        {
            var isMember = await _activeDirectoryService.IsUserInGroupAsync(serviceBody.DlName, serviceBody.Email, IdentifierType.Email);
            if (isMember)
            {
                return Ok(true);
            }
            else
            {
                return Ok(false);
            }
        }

        [HttpGet]
        public async Task<IHttpActionResult> GetAllOUs()
        {
            return Ok(await _activeDirectoryService.GetAllOUsAsync());
        }



        [HttpGet]
        public async Task<IHttpActionResult> AutocompleteUsers(
            string query, int limit = 5,
            bool includeProfileImage = false,
            string imageResolution = "96x96")
        {
            if (string.IsNullOrWhiteSpace(query) || query.Length < 2)
            {
                return Ok(new List<ActiveDirectoryMember>());
            }
            try
            {
                var users = await _activeDirectoryService.SearchUsersForAutocompleteAsync(query, limit, includeProfileImage, imageResolution);

                if (users == null || users.Count == 0)
                {
                    return Ok(new List<ActiveDirectoryMember>());
                }

                return Ok(users);
            }
            catch (Exception ex)
            {

                return InternalServerError();
            }
        }
        [HttpGet]
        public async Task<IHttpActionResult> AutocompleteGroups(
            string query, int limit = 5)
        {
            if (string.IsNullOrWhiteSpace(query) || query.Length < 2)
            {
                return Ok(new List<ActiveDirectoryGroup>());
            }
            try
            {
                var groups = await _activeDirectoryService.SearchGroupsAsync(query, limit);

                if (groups == null || groups.Count == 0)
                {
                    return Ok(new List<ActiveDirectoryGroup>());
                }

                return Ok(groups);
            }
            catch (Exception ex)
            {

                return InternalServerError();
            }
        }
        [HttpGet]
        public async Task<IHttpActionResult> GetUserGenderAsync(string query)
        {

            try
            {
                var result = await _activeDirectoryService.GetUserGenderAsync(query);


                return Ok(result);
            }
            catch (Exception ex)
            {

                return InternalServerError();
            }
        }

        [HttpPost]
        public async Task<IHttpActionResult> GetManagersByEmails(List<string> employeeEmails, bool includeProfileImage = false, string imageResolution = "96x96")
        {
            try
            {
                var managers = await _activeDirectoryService.GetManagersByEmailsAsync(employeeEmails, includeProfileImage, imageResolution);

                return Ok(managers);
            }
            catch (Exception ex)
            {

                return InternalServerError();
            }
        }
        [HttpPost]
        public async Task<IHttpActionResult> GetHodsByEmails(List<string> employeeEmails, bool includeProfileImage = false, string imageResolution = "96x96")
        {
            try
            {
                var managers = await _activeDirectoryService.GetHodsByEmailsAsync(employeeEmails, includeProfileImage, imageResolution);

                return Ok(managers);
            }
            catch (Exception ex)
            {

                return InternalServerError();
            }
        }


        [HttpGet]
        public async Task<IHttpActionResult> GetHods(
            string department = null,
            string subDepartment = null,
            string company = null,
            string office = null,
            string costCenter = null,
            string jobTitle = null,
            string ntAccount = null,
            string email = null,
            string search = null,
            bool? isInternalUser = null,
            bool includeDisabledUsers = false,
            bool includeProfileImage = false,
            string imageResolution = "96x96")
        {
            var filter = new HodFilter
            {
                Department = department,
                SubDepartment = subDepartment,
                Company = company,
                Office = office,
                CostCenter = costCenter,
                JobTitle = jobTitle,
                NTAccount = ntAccount,
                Email = email,
                Search = search,
                IsInternalUser = isInternalUser,
                IncludeDisabledUsers = includeDisabledUsers
            };

            var result =
                await _activeDirectoryService.GetAllHodsAsync(
                    filter,
                    includeProfileImage,
                    imageResolution);

            return Ok(result);
        }
        [HttpGet]
        public async Task<IHttpActionResult> GetExco(
    string department = null,
    string subDepartment = null,
    string company = null,
    string office = null,
    string costCenter = null,
    string jobTitle = null,
    string ntAccount = null,
    string email = null,
    string search = null,
    bool? isInternalUser = null,
    bool includeDisabledUsers = false,
    bool includeProfileImage = false,
    string imageResolution = "96x96")
        {
            var filter = new HodFilter
            {
                Department = department,
                SubDepartment = subDepartment,
                Company = company,
                Office = office,
                CostCenter = costCenter,
                JobTitle = jobTitle,
                NTAccount = ntAccount,
                Email = email,
                Search = search,
                IsInternalUser = isInternalUser,
                IncludeDisabledUsers = includeDisabledUsers
            };

            var result =
                await _activeDirectoryService.GetAllExcoAsync(
                    filter,
                    includeProfileImage,
                    imageResolution);

            return Ok(result);
        }
        // GET: api/AD/GetAccountStatus?userIdentifier=alaa.hassan6@vodafone.com.eg
        [HttpGet]
        public async Task<IHttpActionResult> GetAccountStatus(string userIdentifier)
        {
            var status = await _activeDirectoryService.GetAccountStatusAsync(userIdentifier);

            if (status == null)
            {
                return NotFound();
            }

            return Ok(status);
        }



        [HttpPost]
        public async Task<IHttpActionResult> AddUserToGroup([FromBody] GroupMembershipRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.UserIdentifier) || string.IsNullOrWhiteSpace(request.GroupIdentifier))
            {
                return BadRequest("UserIdentifier and GroupIdentifier are required.");
            }

            bool success = await _activeDirectoryService.AddUserToGroupAsync(request.UserIdentifier, request.GroupIdentifier
            );

            return Ok(success);
        }

        [HttpDelete]
        public async Task<IHttpActionResult> RemoveUserFromGroup([FromBody] GroupMembershipRequest request)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.UserIdentifier) || string.IsNullOrWhiteSpace(request.GroupIdentifier))
            {
                return BadRequest("UserIdentifier and GroupIdentifier are required.");
            }

            bool success = await _activeDirectoryService.RemoveUserFromGroupAsync(request.UserIdentifier, request.GroupIdentifier);

            return Ok(success);
        }
        #endregion


        //  https://localhost:44359/api/AD/GetAllUserAttributesAsync?SearchQuery=hassana9
        [HttpGet]
        public async Task<IHttpActionResult> GetAllUserAttributesAsync(string SearchQuery)
        {
            var user = await _activeDirectoryService.GetUserRawAttributesAsync(SearchQuery);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }


        //  https://localhost:44359/api/AD/UnlockUserAccount?SearchQuery=hassana9
        [HttpGet]
        public async Task<IHttpActionResult> UnlockUserAccount(string SearchQuery)
        {
            var result = await _activeDirectoryService.UnlockUserAccountAsync(SearchQuery);

            return Ok(result);
        }
        //  https://localhost:44359/api/AD/EnableUserAccount?SearchQuery=hassana9
        [HttpGet]
        public async Task<IHttpActionResult> EnableUserAccount(string SearchQuery)
        {
            var result = await _activeDirectoryService.EnableUserAccountAsync(SearchQuery);

            return Ok(result);
        }

        [HttpGet]
        public async Task<IHttpActionResult> GetAllUserAttributesByDepartmentAsync(
          string department)
        {
            if (string.IsNullOrWhiteSpace(department))
                return BadRequest("Department is required.");

            var users = await _activeDirectoryService
                .GetUsersRawAttributesByDepartmentAsync(department);

            return Ok(users);
        }


        [HttpGet]
        public async Task<IHttpActionResult> GetUsnInfo()
        {
            try
            {
                // Replace _adRepository with the existing
                // injected object containing GetAdUsnInfoAsync.

                AdUsnInfoDto result =
                    await _activeDirectoryService.GetAdUsnInfoAsync();

                return Ok(result);
            }
            catch (Exception ex)
            {
                // Log the exception server-side.
                // Do not expose LDAP details to API consumers.
                System.Diagnostics.Trace.TraceError(ex.ToString());

                return InternalServerError();
            }
        }


        //[HttpGet]
        //public async Task<IHttpActionResult> GetGroups()
        //{
        //    List<Dictionary<string, object>> result = await _activeDirectoryService.GetGroupsRawAttributesAsync();


        //    return Ok(result);
        //}

        [HttpGet]
        public async Task<IHttpActionResult> GetChangedUsersCount()
        {
            try
            {
                var result =  await _activeDirectoryService.GetChangedUsersAsync(0);

                return Ok(new
                {
                    TotalUsers = result.Users.Count,
                    ChangedUsersCount = result.ChangedUsersCount,
                    FromUsn = result.FromUsn,
                    ToUsn = result.ToUsn,
                    DomainController = result.DomainControllerName
                });
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.ToString());
                return InternalServerError();
            }
        }

        [HttpGet]
        public async Task<IHttpActionResult> GetChangedUsers(
            long? fromUsn = null,
            string domainControllerName = null)
        {
            if (!fromUsn.HasValue || fromUsn.Value < 0)
                return BadRequest("Valid fromUsn is required.");

            try
            {
                var result = await _activeDirectoryService.GetChangedUsersAsync(
                    fromUsn.Value,
                    domainControllerName);

                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Trace.TraceError(ex.ToString());
                return InternalServerError();
            }
        }
    }
}
