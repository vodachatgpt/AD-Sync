﻿using ADGlobalService.Models;
using ADGlobalService.Services.UserDirectoryService;
using System;
using System.Threading.Tasks;
using System.Web.Http;

namespace ADGlobalService.Controllers.v2.AD
{
    [RoutePrefix("api/v2/AD")]
    public class UsersController : ApiController
    {
        private readonly IUserDirectoryService _userDirectoryService;

        public UsersController(
            IUserDirectoryService userDirectoryService)
        {
            _userDirectoryService =
                userDirectoryService;
        }

        /// <summary>
        /// Flexible V2 user search.
        ///
        /// Examples:
        ///
        /// /api/v2/AD/Users?searchQuery=alaa
        ///
        /// /api/v2/AD/Users
        /// ?searchQuery=alaa
        /// &fields=displayName,email,managerNT
        ///
        /// /api/v2/AD/Users
        /// ?searchQuery=alaa
        /// &fields=displayName,email,costCenter
        /// &include=band
        ///
        /// /api/v2/AD/Users
        /// ?searchQuery=alaa
        /// &fields=displayName,email
        /// &include=band,profileImage
        ///
        /// /api/v2/AD/Users
        /// ?searchQuery=alaa
        /// &fields=displayName,email
        /// &include=none
        /// </summary>
        [HttpGet]
        [Route("Users")]
        public async Task<IHttpActionResult> GetUser(
            string searchQuery,
            UserIdentifierType identifierType = UserIdentifierType.Auto,
            string fields = null,
            string include = null,
            string imageResolution = null)
        {
            if (string.IsNullOrWhiteSpace(searchQuery))
            {
                return BadRequest("searchQuery is required.");
            }
            if (!Enum.IsDefined(typeof(UserIdentifierType), identifierType))
            {
                return BadRequest("Invalid identifierType.");
            }

            UserQueryOptions options;
            string error;

            if (!UserQueryOptions.TryCreate(
                fields,
                include,
                imageResolution,
                out options,
                out error))
            {
                return BadRequest(error);
            }

            var user =
                await _userDirectoryService.FindUserAsync(
                    searchQuery,
                    identifierType,
                    options);

            if (user == null)
            {
                return NotFound();
            }

            return Ok(user);
        }

        /// <summary>
        /// Walks upward through AD manager hierarchy and
        /// returns the first manager whose Band Grade matches.
        ///
        /// Example:
        ///
        /// /api/v2/AD/Users/FirstManagerByGrade
        /// ?searchQuery=alaa
        /// &grade=13
        ///
        /// Lightweight response:
        ///
        /// /api/v2/AD/Users/FirstManagerByGrade
        /// ?searchQuery=alaa
        /// &grade=13
        /// &fields=displayName,email,managerNT
        /// </summary>
        [HttpGet]
        [Route("Users/FirstManagerByGrade")]
        public async Task<IHttpActionResult>
            GetFirstManagerByGrade(
                string searchQuery,
                string grade,
                UserIdentifierType identifierType = UserIdentifierType.Auto,
                string fields = null,
                string include = null,
                string imageResolution = null)
        {
            if (string.IsNullOrWhiteSpace(searchQuery))
            {
                return BadRequest(
                    "searchQuery is required.");
            }

            if (string.IsNullOrWhiteSpace(grade))
            {
                return BadRequest(
                    "grade is required.");
            }

            if (!Enum.IsDefined(typeof(UserIdentifierType), identifierType))
            {
                return BadRequest("Invalid identifierType.");
            }
            UserQueryOptions options;
            string error;

            if (!UserQueryOptions.TryCreate(
                fields,
                include,
                imageResolution,
                out options,
                out error))
            {
                return BadRequest(error);
            }

            var manager =
                await _userDirectoryService
                    .FindFirstManagerByGradeAsync(
                        searchQuery,
                        identifierType,
                        grade,
                        options);

            if (manager == null)
            {
                return NotFound();
            }

            return Ok(manager);
        }
    }
}
