using ADGlobalService.Models;
using ADGlobalService.Services.ActiveDirectoryService;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web.Http;

namespace ADGlobalService.Controllers.v2.AD
{
    [RoutePrefix("api/v2/AD")]
    public sealed class DirectorySyncController : ApiController
    {
        private readonly IDirectoryIncrementalSyncService _syncService;
        private readonly IDirectoryFullOnlyFallbackService _fullOnlyFallbackService;

        public DirectorySyncController(
            IDirectoryIncrementalSyncService syncService,
            IDirectoryFullOnlyFallbackService fullOnlyFallbackService)
        {
            _syncService = syncService;
            _fullOnlyFallbackService = fullOnlyFallbackService;
        }

        [HttpGet]
        [System.Obsolete("Deprecated public paging endpoint. Use GetSyncSnapshot for one-request synchronization.")]
        [Route("GetUsersForSync")]
        public Task<IHttpActionResult> GetUsersForSync(
            int pageSize = 500, string pageToken = null, bool? isInternalUser = null,
            string employmentType = null)
        {
            return ExecuteAsync(() => GetUsersForSyncAsync(pageSize, pageToken,
                isInternalUser, employmentType));
        }

        [HttpGet]
        [Route("GetSyncSnapshot")]
        public Task<IHttpActionResult> GetSyncSnapshot(
            string syncToken = null, int pageSize = 500, bool? isInternalUser = null,
            string employmentType = null)
        {
            return ExecuteAsync(() => GetSyncSnapshotAsync(syncToken, pageSize,
                isInternalUser, employmentType));
        }
        [HttpGet]
        [System.Obsolete("Deprecated public paging endpoint. Use GetSyncSnapshot for one-request synchronization.")]
        [Route("GetChangedUsers")]
        public Task<IHttpActionResult> GetChangedUsers(
            string syncToken = null, int pageSize = 500, string pageToken = null,
            bool? isInternalUser = null, string employmentType = null)
        {
            return ExecuteAsync(() => _syncService.GetChangedUsersAsync(syncToken, pageSize, pageToken,
                GetAudience(pageToken, isInternalUser, employmentType)));
        }

        private async Task<DirectoryIncrementalSyncPage> GetSyncSnapshotAsync(
            string syncToken, int pageSize, bool? isInternalUser, string employmentType)
        {
            var stopwatch = Stopwatch.StartNew();
            bool fullImport = string.IsNullOrWhiteSpace(syncToken);
            DirectorySyncAudience audience = GetAudience(null, isInternalUser, employmentType);
            int pageNumber = 1;
            int totalUsers = 0;

            Log.Information(
                "Directory sync snapshot started. FullImport: {FullImport}, PageSize: {PageSize}, Audience: {Audience}",
                fullImport, pageSize, audience);

            DirectoryIncrementalSyncPage page = fullImport
                ? await GetUsersForSyncAsync(pageSize, null, isInternalUser, employmentType).ConfigureAwait(false)
                : await _syncService.GetChangedUsersAsync(syncToken, pageSize, null, audience).ConfigureAwait(false);

            var users = new List<DirectoryIncrementalSyncUser>();
            while (true)
            {
                if (page.Items != null)
                {
                    users.AddRange(page.Items);
                    totalUsers += page.Items.Count;
                }

                Log.Information(
                    "Directory sync snapshot page loaded. PageNumber: {PageNumber}, Items: {Items}, TotalItems: {TotalItems}, HasMore: {HasMore}, ElapsedSeconds: {ElapsedSeconds}",
                    pageNumber, page.Items?.Count ?? 0, totalUsers, page.HasMore, stopwatch.Elapsed.TotalSeconds);

                if (!page.HasMore)
                {
                    page.Items = users;
                    page.NextPageToken = null;
                    Log.Information(
                        "Directory sync snapshot completed. Pages: {Pages}, TotalItems: {TotalItems}, ElapsedSeconds: {ElapsedSeconds}",
                        pageNumber, totalUsers, stopwatch.Elapsed.TotalSeconds);
                    return page;
                }

                string pageToken = page.NextPageToken;
                pageNumber++;
                page = fullImport
                    ? await GetUsersForSyncAsync(pageSize, pageToken, null, null).ConfigureAwait(false)
                    : await _syncService.GetChangedUsersAsync(null, pageSize, pageToken,
                        DirectorySyncAudience.All).ConfigureAwait(false);
            }
        }
        private async Task<ADGlobalService.Models.DirectoryIncrementalSyncPage> GetUsersForSyncAsync(
            int pageSize, string pageToken, bool? isInternalUser, string employmentType)
        {
            DirectorySyncAudience audience = GetAudience(pageToken, isInternalUser, employmentType);
            if (_fullOnlyFallbackService.IsEnabled)
            {
                if (audience != DirectorySyncAudience.All)
                {
                    throw new ArgumentException(
                        "isInternalUser and employmentType require DirectorySyncDomainController to be configured.");
                }

                return await _fullOnlyFallbackService
                    .GetUsersForSyncAsync(pageSize, pageToken).ConfigureAwait(false);
            }

            return await _syncService.GetUsersForSyncAsync(pageSize, pageToken, audience)
                .ConfigureAwait(false);
        }
        private static DirectorySyncAudience GetAudience(
            string pageToken, bool? isInternalUser, string employmentType)
        {
            if (pageToken != null && (isInternalUser.HasValue || !string.IsNullOrWhiteSpace(employmentType)))
            {
                throw new ArgumentException(
                    "isInternalUser and employmentType cannot be supplied when continuing with pageToken.");
            }
            return DirectorySyncAudienceParser.Parse(isInternalUser, employmentType);
        }

        private async Task<IHttpActionResult> ExecuteAsync<T>(Func<Task<T>> operation)
        {
            try
            {
                var page = await operation().ConfigureAwait(false);
                return NoStore(HttpStatusCode.OK, page);
            }
            catch (ArgumentOutOfRangeException ex)
            {
                return NoStore(HttpStatusCode.BadRequest, new { message = ex.Message });
            }
            catch (ArgumentException ex)
            {
                return NoStore(HttpStatusCode.BadRequest, new { message = ex.Message });
            }
            catch (DirectorySyncResyncRequiredException ex)
            {
                return NoStore(HttpStatusCode.Conflict, new { code = "resync_required", message = ex.Message });
            }
            catch (DirectorySyncExpiredException ex)
            {
                return NoStore(HttpStatusCode.Gone, new { message = ex.Message });
            }
            catch (DirectorySyncCapacityException ex)
            {
                var response = Request.CreateErrorResponse((HttpStatusCode)429, ex.Message);
                response.Headers.RetryAfter = new RetryConditionHeaderValue(TimeSpan.FromSeconds(60));
                response.Headers.CacheControl = NoStoreHeader();
                AddServerHeader(response);
                return ResponseMessage(response);
            }
            catch (Exception ex)
            {
                Log.Error(ex, "V2 AD directory synchronization page failed.");
                return NoStore(HttpStatusCode.ServiceUnavailable,
                    new
                    {
                        message = ex.Message,
                        details = ex.ToString()
                    });
            }
        }

        private IHttpActionResult NoStore(HttpStatusCode statusCode, object body)
        {
            var response = Request.CreateResponse(statusCode, body);
            response.Headers.CacheControl = NoStoreHeader();
            AddServerHeader(response);
            return ResponseMessage(response);
        }

        private static void AddServerHeader(HttpResponseMessage response)
        {
            response.Headers.Add("X-Directory-Sync-Server", Environment.MachineName);
        }

        private static CacheControlHeaderValue NoStoreHeader()
        {
            return new CacheControlHeaderValue { NoStore = true, Private = true };
        }
    }
}
