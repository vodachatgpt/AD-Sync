﻿using System.Web.Http.ExceptionHandling;

using serlogLogger = Serilog.Log;
namespace ADGlobalService
{
    public class GlobalExceptionLogger : ExceptionLogger
    {
        public override void Log(ExceptionLoggerContext context)
        {
            var ex = context.Exception;

            serlogLogger.Error(ex, "❌ API Error | Method: {Method} | URI: {RequestUri} | Error: {Message}",
                context.Request.Method,
                context.Request.RequestUri,
                ex.Message);

            base.Log(context);
        }
    }
}